#pragma once
typedef struct dq* dispatch_queue_t;
#define DISPATCH_QUEUE_PRIORITY_DEFAULT 0
dispatch_queue_t dispatch_get_global_queue(long, unsigned long);
void dispatch_async_f(dispatch_queue_t, void*, void (*)(void*));
