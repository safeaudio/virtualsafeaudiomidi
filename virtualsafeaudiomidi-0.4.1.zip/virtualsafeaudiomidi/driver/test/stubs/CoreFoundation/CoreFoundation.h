#pragma once
#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>
typedef uint8_t UInt8; typedef uint32_t UInt32; typedef int32_t SInt32; typedef uint64_t UInt64; typedef int64_t SInt64;
typedef float Float32; typedef double Float64; typedef SInt32 OSStatus; typedef unsigned char Boolean;
typedef const void* CFTypeRef; typedef const struct __CFString* CFStringRef; typedef const void* CFPropertyListRef;
typedef const struct __CFAllocator* CFAllocatorRef; typedef const struct __CFUUID* CFUUIDRef; typedef const struct __CFDict* CFDictionaryRef;
typedef unsigned long CFTypeID; typedef long CFIndex; typedef UInt32 CFStringEncoding; typedef long CFComparisonResult;
typedef struct { UInt8 b[16]; } CFUUIDBytes;
enum { kCFStringEncodingUTF8 = 0x08000100, kCFCompareEqualTo = 0 };
CFStringRef __stub_cfstr(const char*);
#define CFSTR(s) __stub_cfstr(s)
CFStringRef CFStringCreateWithCString(CFAllocatorRef, const char*, CFStringEncoding);
Boolean CFStringGetCString(CFStringRef, char*, CFIndex, CFStringEncoding);
CFComparisonResult CFStringCompare(CFStringRef, CFStringRef, unsigned long);
CFTypeID CFGetTypeID(CFTypeRef); CFTypeID CFStringGetTypeID(void);
void CFRelease(CFTypeRef); Boolean CFEqual(CFTypeRef, CFTypeRef);
CFUUIDRef CFUUIDCreateFromUUIDBytes(CFAllocatorRef, CFUUIDBytes);
