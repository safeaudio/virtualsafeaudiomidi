#pragma once
#include <CoreFoundation/CoreFoundation.h>
typedef SInt32 HRESULT; typedef UInt32 ULONG; typedef void* LPVOID; typedef CFUUIDBytes REFIID;
#define S_OK 0
#define E_NOINTERFACE ((HRESULT)0x80000004)
extern CFUUIDRef __stub_uuid; 
#define IUnknownUUID __stub_uuid
