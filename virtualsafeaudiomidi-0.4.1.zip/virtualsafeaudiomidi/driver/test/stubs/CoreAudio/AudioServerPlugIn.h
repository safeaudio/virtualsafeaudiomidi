#pragma once
#include <CoreFoundation/CoreFoundation.h>
#include <CoreFoundation/CFPlugInCOM.h>
typedef UInt32 AudioObjectID, AudioClassID, AudioObjectPropertySelector, AudioObjectPropertyScope, AudioObjectPropertyElement;
typedef struct { AudioObjectPropertySelector mSelector; AudioObjectPropertyScope mScope; AudioObjectPropertyElement mElement; } AudioObjectPropertyAddress;
typedef struct { Float64 mSampleRate; UInt32 mFormatID, mFormatFlags, mBytesPerPacket, mFramesPerPacket, mBytesPerFrame, mChannelsPerFrame, mBitsPerChannel, mReserved; } AudioStreamBasicDescription;
typedef struct { Float64 mMinimum, mMaximum; } AudioValueRange;
typedef struct { AudioStreamBasicDescription mFormat; AudioValueRange mSampleRateRange; } AudioStreamRangedDescription;
typedef struct { UInt32 mChannelLabel, mChannelFlags; Float32 mCoordinates[3]; } AudioChannelDescription;
typedef struct { UInt32 mChannelLayoutTag, mChannelBitmap, mNumberChannelDescriptions; AudioChannelDescription mChannelDescriptions[1]; } AudioChannelLayout;
typedef struct { Float64 mSampleTime; UInt64 mHostTime; Float64 mRateScalar; UInt64 mWordClockTime; char smpte[24]; UInt32 mFlags, mReserved; } AudioTimeStamp;
typedef struct { UInt64 mIOCycleCounter; UInt32 mNominalIOBufferFrameSize; AudioTimeStamp mCurrentTime, mInputTime, mOutputTime; UInt64 mMainHostTicksPerFrame, mDeviceHostTicksPerFrame; } AudioServerPlugInIOCycleInfo;
typedef struct { UInt32 mClientID; pid_t mProcessID; Boolean mIsNativeEndian; CFStringRef mBundleID; } AudioServerPlugInClientInfo;
typedef UInt32 AudioServerPlugInCustomPropertyDataType;
typedef struct { AudioObjectPropertySelector mSelector; AudioServerPlugInCustomPropertyDataType mPropertyDataType, mQualifierDataType; } AudioServerPlugInCustomPropertyInfo;
enum { kAudioObjectPlugInObject = 1, kAudioObjectUnknown = 0,
 kAudioHardwareNoError = 0, kAudioHardwareBadPropertySizeError, kAudioHardwareUnknownPropertyError, kAudioHardwareBadObjectError, kAudioHardwareIllegalOperationError, kAudioHardwareUnsupportedOperationError, kAudioDeviceUnsupportedFormatError,
 kAudioObjectPropertyScopeGlobal=100, kAudioObjectPropertyScopeInput, kAudioObjectPropertyScopeOutput, kAudioObjectPropertyElementMain = 0,
 kAudioObjectClassID=200, kAudioPlugInClassID, kAudioDeviceClassID, kAudioStreamClassID,
 kAudioObjectPropertyBaseClass=300, kAudioObjectPropertyClass, kAudioObjectPropertyOwner, kAudioObjectPropertyName, kAudioObjectPropertyManufacturer, kAudioObjectPropertyOwnedObjects, kAudioObjectPropertyCustomPropertyInfoList, kAudioObjectPropertyControlList,
 kAudioPlugInPropertyBoxList, kAudioPlugInPropertyTranslateUIDToBox, kAudioPlugInPropertyDeviceList, kAudioPlugInPropertyTranslateUIDToDevice, kAudioPlugInPropertyResourceBundle,
 kAudioDevicePropertyDeviceUID, kAudioDevicePropertyModelUID, kAudioDevicePropertyTransportType, kAudioDevicePropertyRelatedDevices, kAudioDevicePropertyClockDomain, kAudioDevicePropertyDeviceIsAlive, kAudioDevicePropertyDeviceIsRunning, kAudioDevicePropertyDeviceCanBeDefaultDevice, kAudioDevicePropertyDeviceCanBeDefaultSystemDevice, kAudioDevicePropertyLatency, kAudioDevicePropertyStreams, kAudioDevicePropertySafetyOffset, kAudioDevicePropertyNominalSampleRate, kAudioDevicePropertyAvailableNominalSampleRates, kAudioDevicePropertyIsHidden, kAudioDevicePropertyPreferredChannelsForStereo, kAudioDevicePropertyPreferredChannelLayout, kAudioDevicePropertyZeroTimeStampPeriod,
 kAudioStreamPropertyIsActive, kAudioStreamPropertyDirection, kAudioStreamPropertyTerminalType, kAudioStreamPropertyStartingChannel, kAudioStreamPropertyLatency, kAudioStreamPropertyVirtualFormat, kAudioStreamPropertyAvailableVirtualFormats, kAudioStreamPropertyPhysicalFormat, kAudioStreamPropertyAvailablePhysicalFormats,
 kAudioDeviceTransportTypeVirtual, kAudioStreamTerminalTypeMicrophone, kAudioStreamTerminalTypeSpeaker,
 kAudioFormatLinearPCM, kAudioFormatFlagIsFloat = 1, kAudioFormatFlagsNativeEndian = 0, kAudioFormatFlagIsPacked = 8,
 kAudioChannelLayoutTag_UseChannelDescriptions = 0, kAudioChannelLabel_Left = 1,
 kAudioServerPlugInCustomPropertyDataTypeNone = 0, kAudioServerPlugInCustomPropertyDataTypeCFString, 
 kAudioServerPlugInIOOperationReadInput, kAudioServerPlugInIOOperationWriteMix };
typedef struct AudioServerPlugInHostInterface AudioServerPlugInHostInterface;
typedef const AudioServerPlugInHostInterface* AudioServerPlugInHostRef;
struct AudioServerPlugInHostInterface {
 OSStatus (*PropertiesChanged)(AudioServerPlugInHostRef, AudioObjectID, UInt32, const AudioObjectPropertyAddress[]);
 OSStatus (*CopyFromStorage)(AudioServerPlugInHostRef, CFStringRef, CFPropertyListRef*);
 OSStatus (*WriteToStorage)(AudioServerPlugInHostRef, CFStringRef, CFPropertyListRef);
 OSStatus (*DeleteFromStorage)(AudioServerPlugInHostRef, CFStringRef);
 OSStatus (*RequestDeviceConfigurationChange)(AudioServerPlugInHostRef, AudioObjectID, UInt64, void*);
};
typedef struct AudioServerPlugInDriverInterface AudioServerPlugInDriverInterface;
typedef AudioServerPlugInDriverInterface** AudioServerPlugInDriverRef;
struct AudioServerPlugInDriverInterface {
 void* _reserved;
 HRESULT (*QueryInterface)(void*, REFIID, LPVOID*); ULONG (*AddRef)(void*); ULONG (*Release)(void*);
 OSStatus (*Initialize)(AudioServerPlugInDriverRef, AudioServerPlugInHostRef);
 OSStatus (*CreateDevice)(AudioServerPlugInDriverRef, CFDictionaryRef, const AudioServerPlugInClientInfo*, AudioObjectID*);
 OSStatus (*DestroyDevice)(AudioServerPlugInDriverRef, AudioObjectID);
 OSStatus (*AddDeviceClient)(AudioServerPlugInDriverRef, AudioObjectID, const AudioServerPlugInClientInfo*);
 OSStatus (*RemoveDeviceClient)(AudioServerPlugInDriverRef, AudioObjectID, const AudioServerPlugInClientInfo*);
 OSStatus (*PerformDeviceConfigurationChange)(AudioServerPlugInDriverRef, AudioObjectID, UInt64, void*);
 OSStatus (*AbortDeviceConfigurationChange)(AudioServerPlugInDriverRef, AudioObjectID, UInt64, void*);
 Boolean (*HasProperty)(AudioServerPlugInDriverRef, AudioObjectID, pid_t, const AudioObjectPropertyAddress*);
 OSStatus (*IsPropertySettable)(AudioServerPlugInDriverRef, AudioObjectID, pid_t, const AudioObjectPropertyAddress*, Boolean*);
 OSStatus (*GetPropertyDataSize)(AudioServerPlugInDriverRef, AudioObjectID, pid_t, const AudioObjectPropertyAddress*, UInt32, const void*, UInt32*);
 OSStatus (*GetPropertyData)(AudioServerPlugInDriverRef, AudioObjectID, pid_t, const AudioObjectPropertyAddress*, UInt32, const void*, UInt32, UInt32*, void*);
 OSStatus (*SetPropertyData)(AudioServerPlugInDriverRef, AudioObjectID, pid_t, const AudioObjectPropertyAddress*, UInt32, const void*, UInt32, const void*);
 OSStatus (*StartIO)(AudioServerPlugInDriverRef, AudioObjectID, UInt32);
 OSStatus (*StopIO)(AudioServerPlugInDriverRef, AudioObjectID, UInt32);
 OSStatus (*GetZeroTimeStamp)(AudioServerPlugInDriverRef, AudioObjectID, UInt32, Float64*, UInt64*, UInt64*);
 OSStatus (*WillDoIOOperation)(AudioServerPlugInDriverRef, AudioObjectID, UInt32, UInt32, Boolean*, Boolean*);
 OSStatus (*BeginIOOperation)(AudioServerPlugInDriverRef, AudioObjectID, UInt32, UInt32, UInt32, const AudioServerPlugInIOCycleInfo*);
 OSStatus (*DoIOOperation)(AudioServerPlugInDriverRef, AudioObjectID, AudioObjectID, UInt32, UInt32, UInt32, const AudioServerPlugInIOCycleInfo*, void*, void*);
 OSStatus (*EndIOOperation)(AudioServerPlugInDriverRef, AudioObjectID, UInt32, UInt32, UInt32, const AudioServerPlugInIOCycleInfo*);
};
extern CFUUIDRef kAudioServerPlugInDriverInterfaceUUID, kAudioServerPlugInTypeUUID;
