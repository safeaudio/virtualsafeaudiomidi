// Off-Mac logic test for the VirtualSafeAudio driver. Compiles virtualsafeaudio.c against tiny stand-ins
// for CoreAudio/CoreFoundation (./stubs) and drives it the way coreaudiod would.
// It checks config handling, the loopback ring and the meters. It cannot check what only
// the real HAL can: loading, signing, and how apps react to the device list changing.
//
//   gcc -std=c11 -D_GNU_SOURCE -Wno-multichar -Istubs test_driver.c -lm -lpthread -o test_driver && ./test_driver

#include "../virtualsafeaudio.c"
#include <assert.h>

// ---- mock CoreFoundation
struct __CFString { char* s; };
CFStringRef __stub_cfstr(const char* s) { struct __CFString* r = malloc(sizeof *r); r->s = strdup(s); return r; }
CFStringRef CFStringCreateWithCString(CFAllocatorRef a, const char* s, CFStringEncoding e) { (void)a; (void)e; return __stub_cfstr(s); }
Boolean CFStringGetCString(CFStringRef s, char* buf, CFIndex n, CFStringEncoding e) { (void)e; if ((CFIndex)strlen(s->s) >= n) return 0; strcpy(buf, s->s); return 1; }
CFComparisonResult CFStringCompare(CFStringRef a, CFStringRef b, unsigned long o) { (void)o; return strcmp(a->s, b->s); }
CFTypeID CFGetTypeID(CFTypeRef r) { (void)r; return 7; }
CFTypeID CFStringGetTypeID(void) { return 7; }
void CFRelease(CFTypeRef r) { (void)r; }
Boolean CFEqual(CFTypeRef a, CFTypeRef b) { return a == b; }
CFUUIDRef CFUUIDCreateFromUUIDBytes(CFAllocatorRef a, CFUUIDBytes b) { (void)a; (void)b; return NULL; }
CFUUIDRef __stub_uuid, kAudioServerPlugInDriverInterfaceUUID, kAudioServerPlugInTypeUUID;

// ---- mock mach / dispatch
static uint64_t gNow = 1000;
uint64_t mach_absolute_time(void) { return gNow; }
int mach_timebase_info(mach_timebase_info_data_t* t) { t->numer = 1; t->denom = 1; return 0; }
dispatch_queue_t dispatch_get_global_queue(long a, unsigned long b) { (void)a; (void)b; return NULL; }
void dispatch_async_f(dispatch_queue_t q, void* ctx, void (*fn)(void*)) { (void)q; fn(ctx); }

// ---- mock host
static char gStored[4096]; static int gHasStored = 0, gListChanges = 0, gRenames = 0, gRateRequests = 0;
static OSStatus H_Changed(AudioServerPlugInHostRef h, AudioObjectID o, UInt32 n, const AudioObjectPropertyAddress a[]) {
    (void)h; (void)o; for (UInt32 i = 0; i < n; i++) { if (a[i].mSelector == kAudioPlugInPropertyDeviceList) gListChanges++; if (a[i].mSelector == kAudioObjectPropertyName) gRenames++; } return 0; }
static OSStatus H_Copy(AudioServerPlugInHostRef h, CFStringRef k, CFPropertyListRef* out) { (void)h; (void)k; if (!gHasStored) return 1; *out = __stub_cfstr(gStored); return 0; }
static OSStatus H_Write(AudioServerPlugInHostRef h, CFStringRef k, CFPropertyListRef d) { (void)h; (void)k; strcpy(gStored, ((CFStringRef)d)->s); gHasStored = 1; return 0; }
static OSStatus H_Delete(AudioServerPlugInHostRef h, CFStringRef k) { (void)h; (void)k; return 0; }
static OSStatus H_Request(AudioServerPlugInHostRef h, AudioObjectID dev, UInt64 action, void* info) { (void)h; gRateRequests++; return VirtualSafeAudio_PerformDeviceConfigurationChange(gDriverRef, dev, action, info); }
static AudioServerPlugInHostInterface gMockHost = { H_Changed, H_Copy, H_Write, H_Delete, H_Request };

// ---- helpers
// Every CASE is one test in the STP. Output is one "PASS <id> <title>" line per case; the
// first failed check prints "FAIL <id> ..." and stops the run.
static int gChecks = 0;
static const char* gCase = NULL;
static const char* gTitle = NULL;
static void EndCase(void) { if (gCase) printf("PASS %s %s\n", gCase, gTitle); }
#define CASE(id, title) do { EndCase(); gCase = id; gTitle = title; } while (0)
#define CHECK(cond) do { gChecks++; if (!(cond)) { printf("FAIL %s %s (line %d: %s)\n", gCase ? gCase : "?", gTitle ? gTitle : "", __LINE__, #cond); exit(1); } } while (0)
static const AudioObjectPropertyAddress kCfg = { kSelConfig, kAudioObjectPropertyScopeGlobal, 0 };
static const AudioObjectPropertyAddress kMtr = { kSelMeters, kAudioObjectPropertyScopeGlobal, 0 };

static const char* GetStr(const AudioObjectPropertyAddress* a) {
    CFStringRef s = NULL; UInt32 size = 0;
    CHECK(VirtualSafeAudio_GetPropertyData(gDriverRef, kAudioObjectPlugInObject, 0, a, 0, NULL, sizeof s, &size, &s) == 0);
    return s->s;
}
static OSStatus SetCfg(const char* text) { CFStringRef s = __stub_cfstr(text); return VirtualSafeAudio_SetPropertyData(gDriverRef, kAudioObjectPlugInObject, 0, &kCfg, 0, NULL, sizeof s, &s); }
static AudioObjectID DeviceByUID(const char* uid) {
    AudioObjectPropertyAddress a = { kAudioPlugInPropertyTranslateUIDToDevice, kAudioObjectPropertyScopeGlobal, 0 };
    CFStringRef q = __stub_cfstr(uid); AudioObjectID id = 99999; UInt32 size = 0;
    CHECK(VirtualSafeAudio_GetPropertyData(gDriverRef, kAudioObjectPlugInObject, 0, &a, sizeof q, &q, sizeof id, &size, &id) == 0);
    return id;
}
static OSStatus IO(AudioObjectID dev, UInt32 op, SInt64 t, Float32* buf, UInt32 frames) {
    AudioServerPlugInIOCycleInfo c; memset(&c, 0, sizeof c);
    c.mInputTime.mSampleTime = (Float64)t; c.mOutputTime.mSampleTime = (Float64)t;
    return VirtualSafeAudio_DoIOOperation(gDriverRef, dev, dev + (op == kAudioServerPlugInIOOperationReadInput ? 1 : 2), 0, op, frames, &c, buf, NULL);
}
#define W kAudioServerPlugInIOOperationWriteMix
#define R kAudioServerPlugInIOOperationReadInput
static void Fill(Float32* b, UInt32 frames, UInt32 ch, SInt64 t) { for (UInt32 i = 0; i < frames; i++) for (UInt32 c = 0; c < ch; c++) b[i * ch + c] = (Float32)((t + i) % 1000) / 1000.0f + (Float32)c; }
static int AllZero(const Float32* b, UInt32 n) { for (UInt32 i = 0; i < n; i++) if (b[i] != 0) return 0; return 1; }

int main(void)
{
    AudioObjectPropertyAddress a = { 0, kAudioObjectPropertyScopeGlobal, 0 };
    UInt32 size = 0;
    enum { N = 512 };
    Float32 w[N * 2], r[N * 2];

    CASE("CFG-001", "First start with nothing stored creates one stereo device");
    CHECK(VirtualSafeAudio_Initialize(gDriverRef, &gMockHost) == 0);
    CHECK(strcmp(GetStr(&kCfg), "virtualsafeaudio-main\t2\t48000\tVirtualSafeAudio\n") == 0);

    CASE("CFG-002", "A device is found by its UID; an unknown UID finds nothing");
    AudioObjectID main0 = DeviceByUID("virtualsafeaudio-main");
    CHECK(main0 != kAudioObjectUnknown);
    CHECK(DeviceByUID("nope") == kAudioObjectUnknown);

    CASE("CFG-003", "Property sizes are reported correctly (formats, streams per scope)");
    a.mSelector = kAudioStreamPropertyAvailableVirtualFormats;
    CHECK(VirtualSafeAudio_GetPropertyDataSize(gDriverRef, main0 + 1, 0, &a, 0, NULL, &size) == 0 && size == kNumRates * sizeof(AudioStreamRangedDescription));
    a.mSelector = kAudioDevicePropertyStreams; a.mScope = kAudioObjectPropertyScopeInput;
    CHECK(VirtualSafeAudio_GetPropertyDataSize(gDriverRef, main0, 0, &a, 0, NULL, &size) == 0 && size == sizeof(AudioObjectID));
    a.mScope = kAudioObjectPropertyScopeGlobal;
    CHECK(VirtualSafeAudio_GetPropertyDataSize(gDriverRef, main0, 0, &a, 0, NULL, &size) == 0 && size == 2 * sizeof(AudioObjectID));

    CASE("CFG-004", "Unknown properties and unknown objects are refused");
    a.mSelector = 0xDEAD;
    CHECK(!VirtualSafeAudio_HasProperty(gDriverRef, main0, 0, &a));
    a.mSelector = kAudioDevicePropertyDeviceUID;
    CHECK(VirtualSafeAudio_HasProperty(gDriverRef, main0, 0, &a));
    CHECK(!VirtualSafeAudio_HasProperty(gDriverRef, 4242, 0, &a));

    CASE("CFG-005", "Device list is writable, meters are read-only");
    Boolean settable = 0;
    CHECK(VirtualSafeAudio_IsPropertySettable(gDriverRef, kAudioObjectPlugInObject, 0, &kCfg, &settable) == 0 && settable);
    CHECK(VirtualSafeAudio_IsPropertySettable(gDriverRef, kAudioObjectPlugInObject, 0, &kMtr, &settable) == 0 && !settable);

    CASE("AUD-001", "Recording before anything has played returns silence");
    CHECK(VirtualSafeAudio_StartIO(gDriverRef, main0, 1) == 0);
    Fill(w, N, 2, 0);
    CHECK(IO(main0, R, 0, r, N) == 0 && AllZero(r, N * 2));

    CASE("AUD-002", "Audio played into a device is recorded back sample-exact");
    CHECK(IO(main0, W, 0, w, N) == 0);
    CHECK(IO(main0, R, 0, r, N) == 0 && memcmp(w, r, sizeof w) == 0);

    CASE("AUD-003", "Recording ahead of playback, or across a half-played span, returns silence");
    CHECK(IO(main0, R, N, r, N) == 0 && AllZero(r, N * 2));
    CHECK(IO(main0, R, N / 2, r, N) == 0 && AllZero(r, N * 2));

    CASE("AUD-004", "Continuous stream over five buffer wrap-arounds stays sample-exact");
    for (SInt64 t = N; t < 5 * kRingFrames; t += N) {
        Fill(w, N, 2, t);
        CHECK(IO(main0, W, t, w, N) == 0);
        Fill(w, N, 2, t - N);
        CHECK(IO(main0, R, t - N, r, N) == 0);
        CHECK(memcmp(w, r, sizeof w) == 0);
    }

    CASE("AUD-005", "Audio older than the buffer holds is returned as silence, not stale data");
    SInt64 end = 5 * kRingFrames;
    CHECK(IO(main0, R, end - kRingFrames - N, r, N) == 0 && AllZero(r, N * 2));

    CASE("AUD-006", "A short playback dropout reads as silence; audio on both sides survives");
    Fill(w, N, 2, end + N);
    CHECK(IO(main0, W, end + N, w, N) == 0);
    CHECK(IO(main0, R, end, r, N) == 0 && AllZero(r, N * 2));
    CHECK(IO(main0, R, end + N, r, N) == 0 && memcmp(w, r, sizeof w) == 0);
    Fill(w, N, 2, end - N);
    CHECK(IO(main0, R, end - N, r, N) == 0 && memcmp(w, r, sizeof w) == 0);

    CASE("AUD-007", "After the timeline restarts, earlier audio does not leak through");
    Fill(w, N, 2, 0);
    CHECK(IO(main0, W, 0, w, N) == 0);
    CHECK(IO(main0, R, N, r, N) == 0 && AllZero(r, N * 2));
    CHECK(IO(main0, R, 0, r, N) == 0 && memcmp(w, r, sizeof w) == 0);

    // 1 kHz full-scale sine on channel 1, silence on channel 2, for about two seconds
    SInt64 t = N;
    for (int k = 0; k < 200; k++, t += N) {
        for (int i = 0; i < N; i++) { w[i * 2] = sinf(2.0f * (Float32)M_PI * 1000.0f * (Float32)(t + i) / 48000.0f); w[i * 2 + 1] = 0; }
        if (IO(main0, W, t, w, N) != 0) { printf("FAIL MTR-001 could not write the test tone\n"); return 1; }
    }
    float p0 = 0, r0 = 0, p1 = 0, r1 = 0; char uid[64];

    CASE("MTR-001", "Full-scale sine reads a peak of 1.0 (0 dBFS)");
    CHECK(sscanf(GetStr(&kMtr), "%63s\t%f,%f,%f,%f", uid, &p0, &r0, &p1, &r1) == 5);
    CHECK(strcmp(uid, "virtualsafeaudio-main") == 0);
    CHECK(p0 > 0.99f && p0 <= 1.0001f);

    CASE("MTR-002", "Full-scale sine reads an RMS of 0.707 (-3 dBFS) within 0.01");
    CHECK(fabsf(r0 - 0.7071f) < 0.01f);

    CASE("MTR-003", "A silent channel falls back while its neighbour is loud");
    CHECK(p1 < 0.1f && r1 < 0.001f);

    CASE("MTR-004", "Meters read zero once playback has stopped");
    gNow += 1000000000ull;
    CHECK(sscanf(GetStr(&kMtr), "%63s\t%f,%f", uid, &p0, &r0) == 3 && p0 == 0 && r0 == 0);
    gNow += 5; CHECK(IO(main0, W, t, w, N) == 0);

    CASE("CFG-006", "Rename keeps the device running: same object, name change announced, saved");
    gListChanges = gRenames = 0;
    CHECK(SetCfg("virtualsafeaudio-main\t2\t48000\tDesk return\n") == 0);
    CHECK(DeviceByUID("virtualsafeaudio-main") == main0 && gRenames == 1 && gListChanges == 0);
    CHECK(strcmp(gStored, "virtualsafeaudio-main\t2\t48000\tDesk return\n") == 0);

    CASE("CFG-007", "Adding a device leaves existing devices untouched; new one has the requested format");
    CHECK(SetCfg("virtualsafeaudio-main\t2\t48000\tDesk return\nbus-b\t8\t44100\tBus B\n") == 0);
    AudioObjectID busB = DeviceByUID("bus-b");
    CHECK(DeviceByUID("virtualsafeaudio-main") == main0 && busB != kAudioObjectUnknown && busB != main0 && gListChanges == 1);
    a.mSelector = kAudioDevicePropertyNominalSampleRate; Float64 rate = 0;
    CHECK(VirtualSafeAudio_GetPropertyData(gDriverRef, busB, 0, &a, 0, NULL, sizeof rate, &size, &rate) == 0 && rate == 44100);
    a.mSelector = kAudioStreamPropertyVirtualFormat; AudioStreamBasicDescription f;
    CHECK(VirtualSafeAudio_GetPropertyData(gDriverRef, busB + 2, 0, &a, 0, NULL, sizeof f, &size, &f) == 0 && f.mChannelsPerFrame == 8 && f.mBytesPerFrame == 32);

    CASE("AUD-008", "Eight-channel loopback keeps every channel in its own lane");
    Float32 w8[64 * 8], r8[64 * 8];
    CHECK(VirtualSafeAudio_StartIO(gDriverRef, busB, 1) == 0);
    Fill(w8, 64, 8, 0);
    CHECK(IO(busB, W, 0, w8, 64) == 0 && IO(busB, R, 0, r8, 64) == 0 && memcmp(w8, r8, sizeof w8) == 0);

    CASE("CFG-008", "Channel-count change republishes the device; the old object stops answering");
    CHECK(SetCfg("virtualsafeaudio-main\t16\t48000\tDesk return\nbus-b\t8\t44100\tBus B\n") == 0);
    AudioObjectID main1 = DeviceByUID("virtualsafeaudio-main");
    CHECK(main1 != main0 && main1 != kAudioObjectUnknown && DeviceByUID("bus-b") == busB);
    CHECK(IO(main0, W, 0, w, N) == kAudioHardwareBadObjectError);
    CHECK(VirtualSafeAudio_StopIO(gDriverRef, main0, 1) == kAudioHardwareBadObjectError);
    a.mSelector = kAudioDevicePropertyPreferredChannelLayout;
    CHECK(VirtualSafeAudio_GetPropertyDataSize(gDriverRef, main1, 0, &a, 0, NULL, &size) == 0 &&
          size == offsetof(AudioChannelLayout, mChannelDescriptions) + 16 * sizeof(AudioChannelDescription));

    CASE("CFG-009", "Sample-rate change is requested through Core Audio and saved");
    a.mSelector = kAudioDevicePropertyNominalSampleRate; rate = 96000;
    CHECK(VirtualSafeAudio_SetPropertyData(gDriverRef, busB, 0, &a, 0, NULL, sizeof rate, &rate) == 0 && gRateRequests == 1);
    CHECK(strstr(gStored, "bus-b\t8\t96000\tBus B\n") != NULL);

    CASE("CFG-010", "An unsupported sample rate is rejected");
    rate = 12345;
    CHECK(VirtualSafeAudio_SetPropertyData(gDriverRef, busB, 0, &a, 0, NULL, sizeof rate, &rate) != 0);
    CHECK(strstr(gStored, "bus-b\t8\t96000\tBus B\n") != NULL);

    CASE("ROB-001", "Malformed device list is cleaned up: channels clamped, bad rate defaulted, duplicates and junk dropped");
    CHECK(SetCfg("x\t999\tabc\tBig\nx\t2\t48000\tDup\ngarbage line\n\ty\t2\t48000\n") == 0);
    CHECK(strcmp(GetStr(&kCfg), "x\t64\t48000\tBig\n") == 0);

    CASE("ROB-002", "A list of more than 16 devices is capped at 16");
    char many[4096] = ""; for (int i = 0; i < 20; i++) sprintf(many + strlen(many), "d%d\t2\t48000\tD%d\n", i, i);
    CHECK(SetCfg(many) == 0);
    int lines = 0; for (const char* p = GetStr(&kCfg); *p; p++) if (*p == '\n') lines++;
    CHECK(lines == kMaxDevices);

    CASE("CFG-011", "An empty device list is accepted (no devices published)");
    CHECK(SetCfg("") == 0 && strcmp(GetStr(&kCfg), "") == 0);

    CASE("CFG-012", "The saved device list comes back after Core Audio restarts");
    CHECK(SetCfg("keep\t4\t88200\tKeeper\n") == 0);
    for (int i = 0; i < kMaxDevices; i++) gDev[i].alive = false;
    CHECK(VirtualSafeAudio_Initialize(gDriverRef, &gMockHost) == 0);
    CHECK(strcmp(GetStr(&kCfg), "keep\t4\t88200\tKeeper\n") == 0);

    CASE("AUD-009", "Device clock advances exactly one period per period of host time");
    AudioObjectID keep = DeviceByUID("keep");
    CHECK(VirtualSafeAudio_StartIO(gDriverRef, keep, 1) == 0);
    Float64 st; UInt64 ht, seed; UInt64 anchor = gNow;
    CHECK(VirtualSafeAudio_GetZeroTimeStamp(gDriverRef, keep, 1, &st, &ht, &seed) == 0 && st == 0 && ht == anchor);
    gNow += (UInt64)(1e9 * kRingFrames / 88200.0) + 10;
    CHECK(VirtualSafeAudio_GetZeroTimeStamp(gDriverRef, keep, 1, &st, &ht, &seed) == 0 && st == kRingFrames && ht > anchor && ht <= gNow);

    EndCase();
    printf("driver logic: %d checks passed\n", gChecks);
    return 0;
}
