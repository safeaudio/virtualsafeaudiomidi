// VirtualSafeAudio — virtual audio loopback driver for macOS
//
// WHAT THIS FILE IS
//   The whole driver, in one file. It is compiled into a bundle that macOS's audio server
//   (the process called coreaudiod) loads when it starts. Apple's name for this kind of
//   driver is "AudioServerPlugIn"; the layer it plugs into is the HAL (hardware abstraction
//   layer). There is no hardware behind it: the driver invents its audio devices in software.
//
// WHAT IT DOES
//   * Publishes 0..16 virtual devices. Each has N channels in and N channels out. Whatever
//     an app plays into a device's output comes back out of the same device's input.
//   * The list of devices can be changed while everything is running, through a custom
//     property on the plug-in ('vscf'). No restart of Core Audio, the driver or any app.
//     coreaudiod stores the list, so it survives reboots with no helper process running.
//   * Measures the level of every channel (peak and VU-style RMS) and exposes the numbers
//     through a second custom property ('vsmt'). A control panel can read meters without
//     opening the device for recording: no microphone permission, no orange recording dot.
//
// HOW macOS TALKS TO A DRIVER (the model behind everything below)
//   1. Objects.    Everything is an "audio object" with a numeric ID. We have one plug-in
//                  object (always ID 1) and, per device, three objects: the device itself,
//                  its input stream (the side apps record from) and its output stream (the
//                  side apps play into).
//   2. Properties. macOS knows nothing about an object except what it asks: "object 5, what
//                  is your name?", "object 5, which streams do you own?", "object 6, what
//                  audio format?". Each question is a property, identified by a four-letter
//                  code called a selector. Most of this file is answering such questions;
//                  all the answers are in one function, GetProp.
//   3. IO.         When an app starts playing or recording, macOS calls StartIO. Then, many
//                  times a second, it calls DoIOOperation with a buffer of samples: either
//                  "here is what is being played" or "fill this with what should be
//                  recorded". When the app stops, StopIO.
//   4. Clock.      A sound card has a crystal that sets the pace of its samples. We have
//                  none, so the driver states an ideal clock derived from the Mac's own
//                  high-resolution timer (GetZeroTimeStamp).
//
// THREADS AND LOCKS
//   Property questions arrive on ordinary threads. Audio arrives on real-time threads that
//   must never be kept waiting. So there are two levels of lock:
//     gStateMutex        the device table as a whole; held while answering any property.
//     Device.ioMutex     one per device; held while that device's audio is being handled.
//   When both are needed, gStateMutex is always taken first. Meter values are shared
//   through atomics, with no lock at all.
//
// MAP OF THIS FILE, TOP TO BOTTOM
//   constants            limits, timing, the custom property codes
//   state                the Device record and the global device table
//   helpers              small lookups used everywhere
//   config               parsing the device list, applying it live, saving it
//   ring buffer + meters the loopback itself and the level measurement
//   properties (read)    GetProp: every question macOS can ask, and the answers
//   properties (write)   changing the device list or a sample rate
//   device lifecycle     Initialize and the configuration-change callbacks
//   IO                   StartIO / StopIO, the clock, and the audio path
//   plumbing             the function table macOS calls us through, and the factory
//
// TEXT FORMATS (shared with gui/virtualsafeaudiomidi_gui.py, which must agree with them)
//   Config, UTF-8, one device per line:
//       uid <TAB> channels <TAB> sampleRate <TAB> display name
//   Meters, one device per line, values linear where 1.0 is full scale (0 dBFS):
//       uid <TAB> peak0,rms0,peak1,rms1,...
//
// NAMING
//   Functions called VirtualSafeAudio_Something are the entry points macOS calls. Everything
//   else is internal. "Copy" in a function name follows Apple's convention: the caller
//   receives an object it now owns and must release.

#include <CoreAudio/AudioServerPlugIn.h>
#include <CoreFoundation/CoreFoundation.h>
#include <CoreFoundation/CFPlugInCOM.h>
#include <dispatch/dispatch.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ---------------------------------------------------------------- constants

// Hard limits. The driver keeps a fixed table of device slots, so these are ceilings, not
// defaults. The control panel enforces the same two numbers.
#define kMaxDevices   16
#define kMaxChannels  64
// Length of each device's loopback buffer, in frames. One frame is one sample for every
// channel. 16384 frames is about a third of a second at 48 kHz.
#define kRingFrames   16384          // ring buffer length, also the zero-timestamp period
#define kDefaultRate  48000.0
// The driver's two own ("custom") properties. A selector is four characters packed into a
// 32-bit number. These two are invented for this driver; macOS attaches no meaning to them.
// The control panel uses exactly the same codes to reach them.
#define kSelConfig    'vscf'         // plug-in custom property: config string (read/write)
#define kSelMeters    'vsmt'         // plug-in custom property: meter string (read only)
// The name under which coreaudiod keeps our device list between restarts.
#define kStorageKey   CFSTR("config")
// Shown next to each device in Audio MIDI Setup. The test runner also finds our devices by
// this manufacturer name.
#define kManufacturer CFSTR("VirtualSafeAudio")
#define kModelUID     CFSTR("VirtualSafeAudio_Model")
// Meter timing. A "tau" is a time constant in seconds: how quickly a smoothed value follows
// its input. Smaller is faster.
#define kVUTau        0.065f         // ~300 ms to 99 %, classic VU integration
#define kPeakTau      0.65f          // peak falls ~20 dB in 1.5 s
#define kStaleSeconds 0.25           // meters read zero this long after output stops

// The sample rates every device offers. The app using the device (or Audio MIDI Setup)
// chooses one of them.
static const Float64 kRates[] = { 44100, 48000, 88200, 96000, 176400, 192000 };
#define kNumRates ((UInt32)(sizeof(kRates) / sizeof(kRates[0])))

// ---------------------------------------------------------------- state

// One virtual device. There are kMaxDevices of these in a fixed table (gDev, below). A slot
// is either alive (published to macOS) or free.
//
// Object IDs: a live device uses three consecutive IDs: `id` is the device, `id + 1` its
// input stream, `id + 2` its output stream. IDs are never reused. A device that is taken
// down and published again gets three new ones, which is how macOS can tell that it is a
// different object with possibly a different shape.
typedef struct {
    pthread_mutex_t ioMutex;         // guards everything the IO threads touch
    bool            alive;
    AudioObjectID   id;              // device; id+1 = input stream, id+2 = output stream
    char            uid[128];
    char            name[128];
    UInt32          channels;
    Float64         sampleRate;
    Float32*        ring;            // kRingFrames * channels, interleaved
    // How many clients (apps) currently have audio running on this device.
    UInt64          ioRunning;
    // The device clock (see GetZeroTimeStamp). "Host ticks" are the units of
    // mach_absolute_time(), the Mac's high-resolution timer.
    Float64         hostTicksPerFrame;
    UInt64          anchorHostTime;
    UInt64          numberTimeStamps;
    SInt64          writeStart;      // [writeStart, writeEnd) is the contiguous run of
    SInt64          writeEnd;        //   sample times the ring holds valid output for
    // Meter state. Written by the audio thread, read by whoever asks for the meters.
    // "Atomic" lets two threads share a value without a lock, so reading the meters can
    // never hold up audio.
    _Atomic UInt64  lastWriteHostTime;
    _Atomic Float32 peak[kMaxChannels];
    _Atomic Float32 meanSquare[kMaxChannels];
} Device;

// One parsed line of config text: a device somebody wants to exist.
typedef struct { char uid[128]; char name[128]; UInt32 channels; Float64 rate; } Entry;

// What macOS has to be told after a config change (see NotifyWorker).
typedef struct { bool listChanged; UInt32 nRenamed; AudioObjectID renamed[kMaxDevices]; } Notify;
// A sample-rate change waiting to be requested from macOS (see RateChangeWorker).
typedef struct { AudioObjectID device; Float64 rate; } RateChange;

// What kind of object an ID refers to.
typedef enum { kObjNone, kObjPlugIn, kObjDevice, kObjStreamIn, kObjStreamOut } ObjKind;

// Global state. gStateMutex guards the device table as a whole: which slots are alive, their
// names, IDs, channel counts. It is held while any property question is answered.
static pthread_mutex_t          gStateMutex = PTHREAD_MUTEX_INITIALIZER;
static Device                   gDev[kMaxDevices];
// The next unused object ID. Only ever counts up.
static AudioObjectID            gNextID = 2;   // 1 is the plug-in object
// Our line back to coreaudiod: used to send notifications, to store settings and to request
// configuration changes. Set in Initialize.
static AudioServerPlugInHostRef gHost = NULL;
// How many mach_absolute_time() ticks make one second on this Mac. It differs between Intel
// and Apple silicon, so it is measured in Initialize rather than assumed.
static Float64                  gHostTicksPerSecond = 1e9;
static _Atomic UInt32           gRefCount = 0;

// ---------------------------------------------------------------- helpers

// True if `rate` is one of the sample rates in kRates.
static bool RateSupported(Float64 rate)
{
    for (UInt32 i = 0; i < kNumRates; i++) if (kRates[i] == rate) return true;
    return false;
}

// Turns a C string into the CFString type Core Audio works with. The caller owns the result.
// When such a string is handed to macOS as a property value, macOS does the releasing.
static CFStringRef CopyCFString(const char* s)
{
    CFStringRef r = CFStringCreateWithCString(NULL, s, kCFStringEncodingUTF8);
    return r ? r : CFSTR("?");
}

// Caller holds gStateMutex.
// Looks up an object ID. Returns what kind of object it is and, for a device or a stream,
// which device slot it belongs to. An ID we never issued, or one whose device has been
// removed, returns kObjNone.
static ObjKind Find(AudioObjectID obj, Device** outDev)
{
    if (obj == kAudioObjectPlugInObject) return kObjPlugIn;
    for (int i = 0; i < kMaxDevices; i++) {
        Device* d = &gDev[i];
        if (!d->alive) continue;
        if (obj == d->id)     { *outDev = d; return kObjDevice; }
        if (obj == d->id + 1) { *outDev = d; return kObjStreamIn; }
        if (obj == d->id + 2) { *outDev = d; return kObjStreamOut; }
    }
    return kObjNone;
}

// For IO-thread entry points. Returns the device with its ioMutex held, or NULL.
// The audio threads must not wait on gStateMutex: a slow property question would then stall
// audio. So they find their device without it: scan the table, lock the candidate's own
// mutex, then check again that it is still the same live device. The second check matters
// because the device may have been removed between the scan and the lock.
// The caller must unlock d->ioMutex when it is done.
static Device* LockDeviceForIO(AudioObjectID deviceID)
{
    for (int i = 0; i < kMaxDevices; i++) {
        Device* d = &gDev[i];
        if (d->id != deviceID || !d->alive) continue;
        pthread_mutex_lock(&d->ioMutex);
        if (d->alive && d->id == deviceID) return d;
        pthread_mutex_unlock(&d->ioMutex);
    }
    return NULL;
}

// Describes our audio format to macOS: uncompressed (linear PCM) 32-bit floating point, with
// all channels interleaved in one buffer (frame 0: ch1 ch2 .. chN, frame 1: ch1 ch2 ..).
// This is Core Audio's own native format, so samples pass through without any conversion,
// which is what makes the loopback bit-exact.
static void FillFormat(const Device* d, Float64 rate, AudioStreamBasicDescription* f)
{
    f->mSampleRate       = rate;
    f->mFormatID         = kAudioFormatLinearPCM;
    f->mFormatFlags      = kAudioFormatFlagIsFloat | kAudioFormatFlagsNativeEndian | kAudioFormatFlagIsPacked;
    f->mBytesPerPacket   = (UInt32)sizeof(Float32) * d->channels;
    f->mFramesPerPacket  = 1;
    f->mBytesPerFrame    = (UInt32)sizeof(Float32) * d->channels;
    f->mChannelsPerFrame = d->channels;
    f->mBitsPerChannel   = 32;
    f->mReserved         = 0;
}

// ---------------------------------------------------------------- config

// Returns number of entries, or -1 if the string could not be read at all.
// Reads config text (format at the top of this file) into an array of entries.
// It is deliberately forgiving: a malformed line is skipped, a channel count out of range is
// clamped to 1..kMaxChannels, an unknown sample rate becomes the default, a repeated UID is
// dropped, and anything beyond kMaxDevices is ignored. Bad input cannot make the driver fail;
// at worst it yields fewer devices than were asked for.
static SInt32 ParseConfig(CFStringRef s, Entry* out)
{
    char* buf = malloc(16384);
    if (!buf) return -1;
    if (!CFStringGetCString(s, buf, 16384, kCFStringEncodingUTF8)) { free(buf); return -1; }

    SInt32 n = 0;
    char* save = NULL;
    for (char* line = strtok_r(buf, "\n", &save); line && n < kMaxDevices; line = strtok_r(NULL, "\n", &save)) {
        // Split the line at its first three tabs: f[0] = uid, f[1] = channels, f[2] = rate,
        // f[3] = name. The name is "everything after the third tab".
        char* f[4] = { 0 };
        char* p = line;
        int k;
        for (k = 0; k < 3; k++) {
            f[k] = p;
            char* t = strchr(p, '\t');
            if (!t) break;
            *t = 0;
            p = t + 1;
        }
        if (k < 3 || !f[0][0]) continue;          // malformed line
        f[3] = p;

        // macOS identifies a device by its UID, so a UID may appear only once. First one wins.
        bool dup = false;
        for (SInt32 j = 0; j < n; j++) if (strcmp(out[j].uid, f[0]) == 0) dup = true;
        if (dup) continue;

        Entry* e = &out[n];
        memset(e, 0, sizeof(*e));
        strlcpy(e->uid, f[0], sizeof(e->uid));
        strlcpy(e->name, f[3][0] ? f[3] : f[0], sizeof(e->name));
        long ch = strtol(f[1], NULL, 10);
        e->channels = (UInt32)(ch < 1 ? 1 : (ch > kMaxChannels ? kMaxChannels : ch));
        e->rate = strtod(f[2], NULL);
        if (!RateSupported(e->rate)) e->rate = kDefaultRate;
        n++;
    }
    free(buf);
    return n;
}

// Caller holds gStateMutex. Returns a +1 CFString (or NULL).
// Writes the current device table back out as config text, one line per live device.
// Used to answer the 'vscf' property and to save the settings.
static CFStringRef CopyConfigString(void)
{
    size_t cap = 16384, n = 0;
    char* buf = malloc(cap);
    if (!buf) return NULL;
    buf[0] = 0;
    for (int i = 0; i < kMaxDevices && n < cap; i++) {
        const Device* d = &gDev[i];
        if (!d->alive) continue;
        n += (size_t)snprintf(buf + n, cap - n, "%s\t%u\t%.0f\t%s\n", d->uid, (unsigned)d->channels, d->sampleRate, d->name);
    }
    CFStringRef s = CFStringCreateWithCString(NULL, buf, kCFStringEncodingUTF8);
    free(buf);
    return s;
}

// Caller holds gStateMutex. Returns a +1 CFString.
// Builds the meter text: one line per live device, two numbers per channel (peak, then RMS).
// If nothing has been played into a device for kStaleSeconds, its line is all zeros. Without
// that check the meters would freeze at their last value when playback stops, because the
// audio thread that updates them is no longer being called.
static CFStringRef CopyMetersString(void)
{
    size_t cap = 40960, n = 0;
    char* buf = malloc(cap);
    if (!buf) return CFSTR("");
    buf[0] = 0;
    UInt64 now = mach_absolute_time();
    UInt64 staleTicks = (UInt64)(gHostTicksPerSecond * kStaleSeconds);

    for (int i = 0; i < kMaxDevices; i++) {
        Device* d = &gDev[i];
        if (!d->alive || cap - n < 2048) continue;
        UInt64 last = atomic_load_explicit(&d->lastWriteHostTime, memory_order_relaxed);
        // live = audio was written recently enough for the stored levels to mean something.
        bool live = last != 0 && now >= last && (now - last) < staleTicks;
        n += (size_t)snprintf(buf + n, cap - n, "%s\t", d->uid);
        for (UInt32 c = 0; c < d->channels; c++) {
            Float32 pk = 0, rms = 0;
            if (live) {
                pk  = atomic_load_explicit(&d->peak[c], memory_order_relaxed);
                rms = sqrtf(atomic_load_explicit(&d->meanSquare[c], memory_order_relaxed));
            }
            n += (size_t)snprintf(buf + n, cap - n, c ? ",%.4f,%.4f" : "%.4f,%.4f", pk, rms);
        }
        n += (size_t)snprintf(buf + n, cap - n, "\n");
    }
    CFStringRef s = CFStringCreateWithCString(NULL, buf, kCFStringEncodingUTF8);
    free(buf);
    return s ? s : CFSTR("");
}

// Caller holds gStateMutex.
// Fills a free slot with a new device and marks it alive. It takes the slot's ioMutex so
// that an audio thread still finishing with the slot's previous occupant cannot see the new
// device half-built.
static void DeviceCreate(Device* d, const Entry* e)
{
    pthread_mutex_lock(&d->ioMutex);
    d->id = gNextID;
    gNextID += 3;
    strlcpy(d->uid, e->uid, sizeof(d->uid));
    strlcpy(d->name, e->name, sizeof(d->name));
    d->channels = e->channels;
    d->sampleRate = e->rate;
    free(d->ring);
    // The loopback buffer: kRingFrames frames of `channels` samples each, all zero to begin with.
    d->ring = calloc((size_t)kRingFrames * d->channels, sizeof(Float32));
    d->ioRunning = 0;
    d->hostTicksPerFrame = gHostTicksPerSecond / d->sampleRate;
    d->anchorHostTime = 0;
    d->numberTimeStamps = 0;
    d->writeStart = d->writeEnd = 0;
    atomic_store(&d->lastWriteHostTime, 0);
    for (UInt32 c = 0; c < kMaxChannels; c++) { atomic_store(&d->peak[c], 0.0f); atomic_store(&d->meanSquare[c], 0.0f); }
    d->alive = (d->ring != NULL);
    pthread_mutex_unlock(&d->ioMutex);
}

// Caller holds gStateMutex. A device whose UID and channel count are unchanged is left
// running untouched (a rename is applied in place). Anything else is torn down and
// published again under a new object ID, which is how the HAL learns the new layout.
// THIS IS WHAT MAKES LIVE CHANGES POSSIBLE. It compares the devices that exist with the list
// that was asked for and does the minimum:
//   * same UID, same channel count   -> left completely alone; its audio keeps running.
//                                       If only the name differs, the name is changed in place.
//   * UID no longer in the list,
//     or its channel count changed   -> the device is retired (marked not alive).
//   * UID in the list but not live   -> created in a free slot with new object IDs. This
//     (new, or just retired above)      covers both brand-new devices and resized ones.
// Nothing in here talks to macOS. The caller sends the notifications afterwards (NotifyWorker),
// and macOS then updates every app's device list. coreaudiod is not restarted at any point.
static void ApplyConfig(const Entry* e, SInt32 n, Notify* note)
{
    // used[j]: entry j of the new list is already satisfied by a device that exists.
    bool used[kMaxDevices] = { false };

    for (int i = 0; i < kMaxDevices; i++) {
        Device* d = &gDev[i];
        if (!d->alive) continue;
        // Pass 1: for each existing device, look for its UID in the new list (m = its index).
        SInt32 m = -1;
        for (SInt32 j = 0; j < n; j++) if (!used[j] && strcmp(e[j].uid, d->uid) == 0) { m = j; break; }
        if (m >= 0 && e[m].channels == d->channels) {
            used[m] = true;
            if (strcmp(e[m].name, d->name) != 0) {
                strlcpy(d->name, e[m].name, sizeof(d->name));
                if (note && note->nRenamed < kMaxDevices) note->renamed[note->nRenamed++] = d->id;
            }
        } else {
            pthread_mutex_lock(&d->ioMutex);
            d->alive = false;
            pthread_mutex_unlock(&d->ioMutex);
            if (note) note->listChanged = true;
        }
    }
    // Pass 2: every entry that is still unsatisfied gets a new device in the first free slot.
    for (SInt32 j = 0; j < n; j++) {
        if (used[j]) continue;
        for (int i = 0; i < kMaxDevices; i++) {
            if (gDev[i].alive) continue;
            DeviceCreate(&gDev[i], &e[j]);
            if (note) note->listChanged = true;
            break;
        }
    }
}

// Saves the current device list in coreaudiod's settings store, so that it is there again
// after a reboot even if the control panel never runs. The lock is released before the host
// is called, so that our lock is never held during a call into macOS.
static void PersistConfig(void)
{
    pthread_mutex_lock(&gStateMutex);
    CFStringRef s = CopyConfigString();
    pthread_mutex_unlock(&gStateMutex);
    if (s && gHost) gHost->WriteToStorage(gHost, kStorageKey, s);
    if (s) CFRelease(s);
}

// Host notifications are sent off the calling thread so we never re-enter the HAL
// from inside one of its own calls.
// "The plug-in's device list changed" makes devices appear or disappear in every app.
// "This device's name changed" updates its label. Until these are sent, macOS still believes
// the old picture.
static void NotifyWorker(void* ctx)
{
    Notify* n = (Notify*)ctx;
    if (gHost) {
        if (n->listChanged) {
            AudioObjectPropertyAddress a[2] = {
                { kAudioPlugInPropertyDeviceList,   kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMain },
                { kAudioObjectPropertyOwnedObjects, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMain },
            };
            gHost->PropertiesChanged(gHost, kAudioObjectPlugInObject, 2, a);
        }
        for (UInt32 i = 0; i < n->nRenamed; i++) {
            AudioObjectPropertyAddress a = { kAudioObjectPropertyName, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMain };
            gHost->PropertiesChanged(gHost, n->renamed[i], 1, &a);
        }
    }
    free(n);
}

// Asks macOS to schedule a sample-rate change. macOS pauses audio on the device, calls
// PerformDeviceConfigurationChange (further down), and starts audio again.
static void RateChangeWorker(void* ctx)
{
    RateChange* rc = (RateChange*)ctx;
    if (gHost) gHost->RequestDeviceConfigurationChange(gHost, rc->device, (UInt64)rc->rate, NULL);
    free(rc);
}

// ---------------------------------------------------------------- ring buffer + meters

// HOW THE LOOPBACK BUFFER WORKS
//
// Every buffer macOS hands us carries a "sample time": a frame counter on the device's own
// timeline, 0 when audio starts and +1 for every frame after that. Playback that arrives for
// sample time T is stored at ring position T modulo kRingFrames. Recording that is asked for
// sample time T is read from the same position. macOS asks for playback a little ahead of
// "now" and hands out recording a little behind "now", so the recording side finds what the
// playback side stored a moment earlier.
//
// The ring is only kRingFrames long, so old audio gets overwritten as time goes on.
// writeStart and writeEnd (in Device) remember which stretch of the timeline the ring holds
// real audio for. A request outside that stretch is answered with silence, never with
// leftovers.
//
// RingPos turns a sample time into a position in the ring. The second line handles negative
// times, for which C's % operator would give a negative result.
static inline UInt32 RingPos(SInt64 t)
{
    SInt64 m = t % kRingFrames;
    return (UInt32)(m < 0 ? m + kRingFrames : m);
}

// Copies `frames` frames into the ring, starting at sample time t. If the span runs off the
// end of the ring it continues at the beginning, hence two copies: `first` frames up to the
// end of the ring, the rest from position 0.
static void RingWrite(Device* d, SInt64 t, const Float32* src, UInt32 frames)
{
    UInt32 ch = d->channels, pos = RingPos(t);
    UInt32 first = kRingFrames - pos;
    if (first > frames) first = frames;
    memcpy(d->ring + (size_t)pos * ch, src, (size_t)first * ch * sizeof(Float32));
    memcpy(d->ring, src + (size_t)first * ch, (size_t)(frames - first) * ch * sizeof(Float32));
}

// The same in the other direction: out of the ring, into the caller's buffer.
static void RingRead(const Device* d, SInt64 t, Float32* dst, UInt32 frames)
{
    UInt32 ch = d->channels, pos = RingPos(t);
    UInt32 first = kRingFrames - pos;
    if (first > frames) first = frames;
    memcpy(dst, d->ring + (size_t)pos * ch, (size_t)first * ch * sizeof(Float32));
    memcpy(dst + (size_t)first * ch, d->ring, (size_t)(frames - first) * ch * sizeof(Float32));
}

// Fills a span of the ring with silence. Used for the hole left when playback skipped ahead.
static void RingZero(Device* d, SInt64 t, UInt32 frames)
{
    UInt32 ch = d->channels, pos = RingPos(t);
    UInt32 first = kRingFrames - pos;
    if (first > frames) first = frames;
    memset(d->ring + (size_t)pos * ch, 0, (size_t)first * ch * sizeof(Float32));
    memset(d->ring, 0, (size_t)(frames - first) * ch * sizeof(Float32));
}

// Level measurement, run on every buffer that is played into a device. For each channel:
//   peak        the largest absolute sample in this buffer, but never less than the previous
//               peak after it has decayed a little. That decay is the "peak hold" falling back.
//   meanSquare  a running average of sample squared. Its square root is the RMS level a VU
//               meter shows. The average is a one-pole low-pass filter:
//                   new = old + coeff * (this buffer's mean square - old)
//               with coeff derived from kVUTau and the buffer's duration, so the meter responds
//               equally fast at any buffer size and sample rate.
static void Meter(Device* d, const Float32* buf, UInt32 frames)
{
    if (frames == 0) return;
    UInt32 ch = d->channels;
    Float32 seconds   = (Float32)((Float64)frames / d->sampleRate);
    Float32 vuCoeff   = 1.0f - expf(-seconds / kVUTau);
    Float32 peakDecay = expf(-seconds / kPeakTau);

    for (UInt32 c = 0; c < ch; c++) {
        Float32 pk = 0, sum = 0;
        for (UInt32 i = 0; i < frames; i++) {
            Float32 x = buf[(size_t)i * ch + c];
            Float32 ax = fabsf(x);
            if (ax > pk) pk = ax;
            sum += x * x;
        }
        // isfinite guards against NaN or infinite samples, which would otherwise stick in the
        // running average forever.
        Float32 ms = atomic_load_explicit(&d->meanSquare[c], memory_order_relaxed);
        ms += vuCoeff * (sum / (Float32)frames - ms);
        if (!isfinite(ms)) ms = 0;
        atomic_store_explicit(&d->meanSquare[c], ms, memory_order_relaxed);

        Float32 held = atomic_load_explicit(&d->peak[c], memory_order_relaxed) * peakDecay;
        if (!isfinite(pk)) pk = 0;
        atomic_store_explicit(&d->peak[c], pk > held ? pk : held, memory_order_relaxed);
    }
}

// ---------------------------------------------------------------- properties (read)

// ANSWERING PROPERTY QUESTIONS
//
// macOS calls GetPropertyData with: which object, which property (selector and scope), a
// buffer, and the buffer's size. We write the answer into the buffer and report how many
// bytes we wrote.
//
// PUT covers the common case where the answer is one value of a known type: it checks that
// the buffer is big enough, stores the value, reports its size and returns from GetProp.
// (It is a macro rather than a function precisely so that it can return from its caller.)
#define PUT(type, value) do {                                               \
        if (inSize < sizeof(type)) return kAudioHardwareBadPropertySizeError; \
        *(type*)out = (value);                                              \
        *outSize = (UInt32)sizeof(type);                                    \
        return kAudioHardwareNoError;                                       \
    } while (0)

// The other common case: the answer is a list of object IDs. Writes as many as fit.
static OSStatus PutIDs(const AudioObjectID* ids, UInt32 n, UInt32 inSize, UInt32* outSize, void* out)
{
    UInt32 fit = inSize / (UInt32)sizeof(AudioObjectID);
    if (fit > n) fit = n;
    if (fit) memcpy(out, ids, fit * sizeof(AudioObjectID));
    *outSize = fit * (UInt32)sizeof(AudioObjectID);
    return kAudioHardwareNoError;
}

// The properties whose answer is a CF object (a string). Probe needs to know, because it
// must release such an object after a trial run.
static bool ReturnsCFObject(AudioObjectPropertySelector sel)
{
    switch (sel) {
        case kAudioObjectPropertyManufacturer:
        case kAudioObjectPropertyName:
        case kAudioDevicePropertyDeviceUID:
        case kAudioDevicePropertyModelUID:
        case kAudioPlugInPropertyResourceBundle:
        case kSelConfig:
        case kSelMeters:
            return true;
        default:
            return false;
    }
}

// The single source of truth for every readable property. HasProperty and
// GetPropertyDataSize are derived from it by probing into a scratch buffer.
// Caller holds gStateMutex.
static OSStatus GetProp(AudioObjectID obj, const AudioObjectPropertyAddress* a,
                        UInt32 qSize, const void* q, UInt32 inSize, UInt32* outSize, void* out)
{
    Device* d = NULL;
    ObjKind kind = Find(obj, &d);
    AudioObjectPropertySelector sel = a->mSelector;
    AudioObjectPropertyScope scope = a->mScope;

    // ---- The plug-in object: who we are, which devices exist, and our two custom properties.
    if (kind == kObjPlugIn) {
        AudioObjectID ids[kMaxDevices];
        UInt32 n = 0;
        for (int i = 0; i < kMaxDevices; i++) if (gDev[i].alive) ids[n++] = gDev[i].id;

        switch (sel) {
            case kAudioObjectPropertyBaseClass:      PUT(AudioClassID, kAudioObjectClassID);
            case kAudioObjectPropertyClass:          PUT(AudioClassID, kAudioPlugInClassID);
            case kAudioObjectPropertyOwner:          PUT(AudioObjectID, kAudioObjectUnknown);
            case kAudioObjectPropertyManufacturer:   PUT(CFStringRef, kManufacturer);
            case kAudioPlugInPropertyResourceBundle: PUT(CFStringRef, CFSTR(""));
            case kAudioObjectPropertyOwnedObjects:
            case kAudioPlugInPropertyDeviceList:     return PutIDs(ids, n, inSize, outSize, out);
            case kAudioPlugInPropertyBoxList:        *outSize = 0; return kAudioHardwareNoError;
            case kAudioPlugInPropertyTranslateUIDToBox: PUT(AudioObjectID, kAudioObjectUnknown);
            // "Which of your devices has this UID?" The UID arrives as the qualifier.
            case kAudioPlugInPropertyTranslateUIDToDevice: {
                AudioObjectID found = kAudioObjectUnknown;
                if (q && qSize >= sizeof(CFStringRef) && *(const CFStringRef*)q) {
                    for (int i = 0; i < kMaxDevices && found == kAudioObjectUnknown; i++) {
                        if (!gDev[i].alive) continue;
                        CFStringRef uid = CopyCFString(gDev[i].uid);
                        if (CFStringCompare(uid, *(const CFStringRef*)q, 0) == kCFCompareEqualTo) found = gDev[i].id;
                        CFRelease(uid);
                    }
                }
                PUT(AudioObjectID, found);
            }
            // Declares our two custom properties and that each carries a string. Without this
            // declaration coreaudiod would not know how to pass them between processes.
            case kAudioObjectPropertyCustomPropertyInfoList: {
                AudioServerPlugInCustomPropertyInfo info[2] = {
                    { kSelConfig, kAudioServerPlugInCustomPropertyDataTypeCFString, kAudioServerPlugInCustomPropertyDataTypeNone },
                    { kSelMeters, kAudioServerPlugInCustomPropertyDataTypeCFString, kAudioServerPlugInCustomPropertyDataTypeNone },
                };
                UInt32 fit = inSize / (UInt32)sizeof(info[0]);
                if (fit > 2) fit = 2;
                memcpy(out, info, fit * sizeof(info[0]));
                *outSize = fit * (UInt32)sizeof(info[0]);
                return kAudioHardwareNoError;
            }
            case kSelConfig: {
                if (inSize < sizeof(CFStringRef)) return kAudioHardwareBadPropertySizeError;
                CFStringRef s = CopyConfigString();
                *(CFStringRef*)out = s ? s : CFSTR("");
                *outSize = (UInt32)sizeof(CFStringRef);
                return kAudioHardwareNoError;
            }
            case kSelMeters: {
                if (inSize < sizeof(CFStringRef)) return kAudioHardwareBadPropertySizeError;
                *(CFStringRef*)out = CopyMetersString();
                *outSize = (UInt32)sizeof(CFStringRef);
                return kAudioHardwareNoError;
            }
            default: return kAudioHardwareUnknownPropertyError;
        }
    }

    // ---- A device object: identity, capabilities, clock parameters, the streams it owns.
    if (kind == kObjDevice) {
        switch (sel) {
            case kAudioObjectPropertyBaseClass:    PUT(AudioClassID, kAudioObjectClassID);
            case kAudioObjectPropertyClass:        PUT(AudioClassID, kAudioDeviceClassID);
            case kAudioObjectPropertyOwner:        PUT(AudioObjectID, kAudioObjectPlugInObject);
            case kAudioObjectPropertyName:         PUT(CFStringRef, CopyCFString(d->name));
            case kAudioObjectPropertyManufacturer: PUT(CFStringRef, kManufacturer);
            case kAudioDevicePropertyDeviceUID:    PUT(CFStringRef, CopyCFString(d->uid));
            case kAudioDevicePropertyModelUID:     PUT(CFStringRef, kModelUID);
            // "Virtual" tells apps that this is not a piece of hardware.
            case kAudioDevicePropertyTransportType: PUT(UInt32, kAudioDeviceTransportTypeVirtual);
            case kAudioDevicePropertyRelatedDevices: return PutIDs(&d->id, 1, inSize, outSize, out);
            case kAudioDevicePropertyClockDomain:  PUT(UInt32, 0);
            case kAudioDevicePropertyDeviceIsAlive: PUT(UInt32, 1);
            case kAudioDevicePropertyDeviceIsRunning: PUT(UInt32, d->ioRunning > 0 ? 1 : 0);
            case kAudioDevicePropertyDeviceCanBeDefaultDevice:       PUT(UInt32, 1);
            case kAudioDevicePropertyDeviceCanBeDefaultSystemDevice: PUT(UInt32, 1);
            // We add no delay of our own, so latency and safety offset are both zero.
            case kAudioDevicePropertyLatency:      PUT(UInt32, 0);
            case kAudioDevicePropertySafetyOffset: PUT(UInt32, 0);
            case kAudioDevicePropertyIsHidden:     PUT(UInt32, 0);
            // How often our clock ticks, in frames (see GetZeroTimeStamp).
            case kAudioDevicePropertyZeroTimeStampPeriod: PUT(UInt32, kRingFrames);
            case kAudioDevicePropertyNominalSampleRate:   PUT(Float64, d->sampleRate);
            // No volume or mute controls in this version, so the list of controls is empty.
            case kAudioObjectPropertyControlList:  *outSize = 0; return kAudioHardwareNoError;
            case kAudioObjectPropertyOwnedObjects:
            // Which streams the device has. The scope says which side is being asked about:
            // input, output, or both (global).
            case kAudioDevicePropertyStreams: {
                AudioObjectID ids[2];
                UInt32 n = 0;
                if (scope == kAudioObjectPropertyScopeGlobal || scope == kAudioObjectPropertyScopeInput)  ids[n++] = d->id + 1;
                if (scope == kAudioObjectPropertyScopeGlobal || scope == kAudioObjectPropertyScopeOutput) ids[n++] = d->id + 2;
                return PutIDs(ids, n, inSize, outSize, out);
            }
            case kAudioDevicePropertyAvailableNominalSampleRates: {
                UInt32 fit = inSize / (UInt32)sizeof(AudioValueRange);
                if (fit > kNumRates) fit = kNumRates;
                AudioValueRange* r = (AudioValueRange*)out;
                for (UInt32 i = 0; i < fit; i++) { r[i].mMinimum = kRates[i]; r[i].mMaximum = kRates[i]; }
                *outSize = fit * (UInt32)sizeof(AudioValueRange);
                return kAudioHardwareNoError;
            }
            case kAudioDevicePropertyPreferredChannelsForStereo: {
                if (inSize < 2 * sizeof(UInt32)) return kAudioHardwareBadPropertySizeError;
                ((UInt32*)out)[0] = 1;
                ((UInt32*)out)[1] = d->channels > 1 ? 2 : 1;
                *outSize = 2 * (UInt32)sizeof(UInt32);
                return kAudioHardwareNoError;
            }
            // A label for every channel: Left, Right, then Core Audio's standard sequence.
            case kAudioDevicePropertyPreferredChannelLayout: {
                UInt32 need = (UInt32)(offsetof(AudioChannelLayout, mChannelDescriptions) + d->channels * sizeof(AudioChannelDescription));
                if (inSize < need) return kAudioHardwareBadPropertySizeError;
                AudioChannelLayout* l = (AudioChannelLayout*)out;
                memset(l, 0, need);
                l->mChannelLayoutTag = kAudioChannelLayoutTag_UseChannelDescriptions;
                l->mNumberChannelDescriptions = d->channels;
                for (UInt32 c = 0; c < d->channels; c++) l->mChannelDescriptions[c].mChannelLabel = kAudioChannelLabel_Left + c;
                *outSize = need;
                return kAudioHardwareNoError;
            }
            default: return kAudioHardwareUnknownPropertyError;
        }
    }

    // ---- A stream object: its direction and its audio format.
    if (kind == kObjStreamIn || kind == kObjStreamOut) {
        bool input = (kind == kObjStreamIn);
        switch (sel) {
            case kAudioObjectPropertyBaseClass:     PUT(AudioClassID, kAudioObjectClassID);
            case kAudioObjectPropertyClass:         PUT(AudioClassID, kAudioStreamClassID);
            case kAudioObjectPropertyOwner:         PUT(AudioObjectID, d->id);
            case kAudioObjectPropertyOwnedObjects:  *outSize = 0; return kAudioHardwareNoError;
            case kAudioStreamPropertyIsActive:      PUT(UInt32, 1);
            // 1 = input (apps record from it), 0 = output (apps play into it).
            case kAudioStreamPropertyDirection:     PUT(UInt32, input ? 1 : 0);
            case kAudioStreamPropertyTerminalType:  PUT(UInt32, input ? kAudioStreamTerminalTypeMicrophone : kAudioStreamTerminalTypeSpeaker);
            case kAudioStreamPropertyStartingChannel: PUT(UInt32, 1);
            case kAudioStreamPropertyLatency:       PUT(UInt32, 0);
            // The format in use now. "Virtual" and "physical" are the same thing for us, because
            // there is no hardware format behind the stream.
            case kAudioStreamPropertyVirtualFormat:
            case kAudioStreamPropertyPhysicalFormat: {
                if (inSize < sizeof(AudioStreamBasicDescription)) return kAudioHardwareBadPropertySizeError;
                FillFormat(d, d->sampleRate, (AudioStreamBasicDescription*)out);
                *outSize = (UInt32)sizeof(AudioStreamBasicDescription);
                return kAudioHardwareNoError;
            }
            // Every format we can run: the same layout at each supported sample rate.
            case kAudioStreamPropertyAvailableVirtualFormats:
            case kAudioStreamPropertyAvailablePhysicalFormats: {
                UInt32 fit = inSize / (UInt32)sizeof(AudioStreamRangedDescription);
                if (fit > kNumRates) fit = kNumRates;
                AudioStreamRangedDescription* r = (AudioStreamRangedDescription*)out;
                for (UInt32 i = 0; i < fit; i++) {
                    FillFormat(d, kRates[i], &r[i].mFormat);
                    r[i].mSampleRateRange.mMinimum = kRates[i];
                    r[i].mSampleRateRange.mMaximum = kRates[i];
                }
                *outSize = fit * (UInt32)sizeof(AudioStreamRangedDescription);
                return kAudioHardwareNoError;
            }
            default: return kAudioHardwareUnknownPropertyError;
        }
    }

    return kAudioHardwareBadObjectError;
}

// Runs GetProp into a scratch buffer to learn whether a property exists and how big it is.
// Before asking for an answer, macOS often asks "does this property exist?" or "how big is
// the answer?". Rather than keep three separate lists that could drift apart, those two
// questions are answered by really running GetProp into a throwaway buffer and looking at
// what came out. If the trial answer was a CF object, it is released again here.
static OSStatus Probe(AudioObjectID obj, const AudioObjectPropertyAddress* a, UInt32 qSize, const void* q, UInt32* outSize)
{
    _Alignas(8) UInt8 scratch[8192];
    UInt32 size = 0;
    pthread_mutex_lock(&gStateMutex);
    OSStatus err = GetProp(obj, a, qSize, q, (UInt32)sizeof(scratch), &size, scratch);
    pthread_mutex_unlock(&gStateMutex);
    if (err == kAudioHardwareNoError && ReturnsCFObject(a->mSelector) && size == sizeof(CFTypeRef)) {
        CFTypeRef ref = *(CFTypeRef*)(void*)scratch;
        if (ref) CFRelease(ref);
    }
    if (outSize) *outSize = size;
    return err;
}

// Entry point: "does this object have this property?"
static Boolean VirtualSafeAudio_HasProperty(AudioServerPlugInDriverRef drv, AudioObjectID obj, pid_t pid, const AudioObjectPropertyAddress* a)
{
    (void)drv; (void)pid;
    if (!a) return false;
    return Probe(obj, a, 0, NULL, NULL) == kAudioHardwareNoError;
}

// Entry point: "how many bytes would the answer be?"
static OSStatus VirtualSafeAudio_GetPropertyDataSize(AudioServerPlugInDriverRef drv, AudioObjectID obj, pid_t pid, const AudioObjectPropertyAddress* a,
                                             UInt32 qSize, const void* q, UInt32* outSize)
{
    (void)drv; (void)pid;
    if (!a || !outSize) return kAudioHardwareIllegalOperationError;
    return Probe(obj, a, qSize, q, outSize);
}

// Entry point: "what is the answer?" Takes the state lock; GetProp does the work.
static OSStatus VirtualSafeAudio_GetPropertyData(AudioServerPlugInDriverRef drv, AudioObjectID obj, pid_t pid, const AudioObjectPropertyAddress* a,
                                         UInt32 qSize, const void* q, UInt32 inSize, UInt32* outSize, void* out)
{
    (void)drv; (void)pid;
    if (!a || !outSize || !out) return kAudioHardwareIllegalOperationError;
    pthread_mutex_lock(&gStateMutex);
    OSStatus err = GetProp(obj, a, qSize, q, inSize, outSize, out);
    pthread_mutex_unlock(&gStateMutex);
    return err;
}

// ---------------------------------------------------------------- properties (write)

// Entry point: "may this property be changed?" Four can: our device list, a device's sample
// rate, and the two stream-format properties (through which apps also change the rate).
static OSStatus VirtualSafeAudio_IsPropertySettable(AudioServerPlugInDriverRef drv, AudioObjectID obj, pid_t pid, const AudioObjectPropertyAddress* a, Boolean* outSettable)
{
    (void)drv; (void)pid;
    if (!a || !outSettable) return kAudioHardwareIllegalOperationError;
    OSStatus err = Probe(obj, a, 0, NULL, NULL);
    if (err != kAudioHardwareNoError) return err;
    switch (a->mSelector) {
        case kSelConfig:
        case kAudioDevicePropertyNominalSampleRate:
        case kAudioStreamPropertyVirtualFormat:
        case kAudioStreamPropertyPhysicalFormat:
            *outSettable = true;
            break;
        default:
            *outSettable = false;
    }
    return kAudioHardwareNoError;
}

// Entry point: "change this property". Two kinds of change are accepted:
//   1. the device list (custom property 'vscf'). This is the call the control panel makes
//      when you press Apply, and it takes effect immediately;
//   2. a device's sample rate, asked for by an app or by Audio MIDI Setup.
static OSStatus VirtualSafeAudio_SetPropertyData(AudioServerPlugInDriverRef drv, AudioObjectID obj, pid_t pid, const AudioObjectPropertyAddress* a,
                                         UInt32 qSize, const void* q, UInt32 inSize, const void* inData)
{
    (void)drv; (void)pid; (void)qSize; (void)q;
    if (!a || !inData) return kAudioHardwareIllegalOperationError;

    // --- new device list from the GUI (or anything else that can set a CFString property)
    if (obj == kAudioObjectPlugInObject && a->mSelector == kSelConfig) {
        if (inSize < sizeof(CFStringRef)) return kAudioHardwareBadPropertySizeError;
        CFStringRef s = *(const CFStringRef*)inData;
        if (!s || CFGetTypeID(s) != CFStringGetTypeID()) return kAudioHardwareIllegalOperationError;

        // Parse the text, apply it to the device table, save it, then tell macOS. The
        // notification is sent from a background queue after this call has returned, because
        // macOS reacts to it by calling straight back into the driver.
        Entry* e = calloc(kMaxDevices, sizeof(Entry));
        Notify* note = calloc(1, sizeof(Notify));
        SInt32 n = (e && note) ? ParseConfig(s, e) : -1;
        if (n < 0) { free(e); free(note); return kAudioHardwareIllegalOperationError; }

        pthread_mutex_lock(&gStateMutex);
        ApplyConfig(e, n, note);
        pthread_mutex_unlock(&gStateMutex);
        free(e);

        PersistConfig();
        dispatch_async_f(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), note, NotifyWorker);
        return kAudioHardwareNoError;
    }

    // --- sample rate, either directly or through a stream format
    Float64 newRate = 0, curRate = 0;
    AudioObjectID deviceID = kAudioObjectUnknown;

    pthread_mutex_lock(&gStateMutex);
    Device* d = NULL;
    ObjKind kind = Find(obj, &d);
    OSStatus err = kAudioHardwareNoError;
    if (kind == kObjDevice && a->mSelector == kAudioDevicePropertyNominalSampleRate) {
        if (inSize < sizeof(Float64)) err = kAudioHardwareBadPropertySizeError;
        else newRate = *(const Float64*)inData;
    } else if ((kind == kObjStreamIn || kind == kObjStreamOut) &&
               (a->mSelector == kAudioStreamPropertyVirtualFormat || a->mSelector == kAudioStreamPropertyPhysicalFormat)) {
        if (inSize < sizeof(AudioStreamBasicDescription)) err = kAudioHardwareBadPropertySizeError;
        else {
            const AudioStreamBasicDescription* f = (const AudioStreamBasicDescription*)inData;
            if (f->mFormatID != kAudioFormatLinearPCM || f->mChannelsPerFrame != d->channels || f->mBitsPerChannel != 32)
                err = kAudioDeviceUnsupportedFormatError;
            else newRate = f->mSampleRate;
        }
    } else {
        err = (kind == kObjNone) ? kAudioHardwareBadObjectError : kAudioHardwareUnsupportedOperationError;
    }
    if (err == kAudioHardwareNoError) { deviceID = d->id; curRate = d->sampleRate; }
    pthread_mutex_unlock(&gStateMutex);

    if (err != kAudioHardwareNoError) return err;
    // The rate is not changed here. We ask macOS to schedule the change (RateChangeWorker) so
    // that it can pause audio around it; the change itself happens in
    // PerformDeviceConfigurationChange.
    if (!RateSupported(newRate)) return kAudioDeviceUnsupportedFormatError;
    if (newRate != curRate) {
        RateChange* rc = malloc(sizeof(RateChange));
        if (!rc) return kAudioHardwareIllegalOperationError;
        rc->device = deviceID;
        rc->rate = newRate;
        dispatch_async_f(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), rc, RateChangeWorker);
    }
    return kAudioHardwareNoError;
}

// ---------------------------------------------------------------- device lifecycle

// Entry point, called once when coreaudiod loads the driver (at boot, or when Core Audio is
// restarted). We remember the host, measure the clock, and publish the device list that was
// saved last time, or a single stereo device if nothing was ever saved.
static OSStatus VirtualSafeAudio_Initialize(AudioServerPlugInDriverRef drv, AudioServerPlugInHostRef host)
{
    (void)drv;
    gHost = host;

    mach_timebase_info_data_t tb;
    mach_timebase_info(&tb);
    gHostTicksPerSecond = 1e9 * (Float64)tb.denom / (Float64)tb.numer;

    for (int i = 0; i < kMaxDevices; i++) pthread_mutex_init(&gDev[i].ioMutex, NULL);

    Entry* e = calloc(kMaxDevices, sizeof(Entry));
    if (!e) return kAudioHardwareIllegalOperationError;
    SInt32 n = -1;

    CFPropertyListRef stored = NULL;
    if (host->CopyFromStorage(host, kStorageKey, &stored) == kAudioHardwareNoError && stored) {
        if (CFGetTypeID(stored) == CFStringGetTypeID()) n = ParseConfig((CFStringRef)stored, e);
        CFRelease(stored);
    }
    if (n < 0) {                                  // first run: one stereo device
        strlcpy(e[0].uid, "virtualsafeaudio-main", sizeof(e[0].uid));
        strlcpy(e[0].name, "VirtualSafeAudio", sizeof(e[0].name));
        e[0].channels = 2;
        e[0].rate = kDefaultRate;
        n = 1;
    }

    pthread_mutex_lock(&gStateMutex);
    ApplyConfig(e, n, NULL);
    pthread_mutex_unlock(&gStateMutex);
    free(e);
    return kAudioHardwareNoError;
}

// CreateDevice / DestroyDevice exist for drivers whose devices are created by other software
// through a separate macOS mechanism. Ours are created through the config property instead,
// so both are refused.
static OSStatus VirtualSafeAudio_CreateDevice(AudioServerPlugInDriverRef drv, CFDictionaryRef desc, const AudioServerPlugInClientInfo* client, AudioObjectID* outID)
{
    (void)drv; (void)desc; (void)client; (void)outID;
    return kAudioHardwareUnsupportedOperationError;
}

static OSStatus VirtualSafeAudio_DestroyDevice(AudioServerPlugInDriverRef drv, AudioObjectID dev)
{
    (void)drv; (void)dev;
    return kAudioHardwareUnsupportedOperationError;
}

// Called when an app starts (Add) or stops (Remove) using a device. We keep nothing per app.
static OSStatus VirtualSafeAudio_AddDeviceClient(AudioServerPlugInDriverRef drv, AudioObjectID dev, const AudioServerPlugInClientInfo* client)
{
    (void)drv; (void)dev; (void)client;
    return kAudioHardwareNoError;
}

static OSStatus VirtualSafeAudio_RemoveDeviceClient(AudioServerPlugInDriverRef drv, AudioObjectID dev, const AudioServerPlugInClientInfo* client)
{
    (void)drv; (void)dev; (void)client;
    return kAudioHardwareNoError;
}

// The only configuration change we request is a sample-rate change; inAction carries the rate.
// By the time this is called macOS has stopped all audio on the device, so the rate can be
// switched safely. The length of a clock tick depends on the rate, so it is recomputed, and
// the loopback timeline starts fresh.
static OSStatus VirtualSafeAudio_PerformDeviceConfigurationChange(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt64 action, void* info)
{
    (void)drv; (void)info;
    Float64 rate = (Float64)action;
    if (!RateSupported(rate)) return kAudioHardwareIllegalOperationError;

    Device* d = LockDeviceForIO(dev);
    if (!d) return kAudioHardwareBadObjectError;
    d->sampleRate = rate;
    d->hostTicksPerFrame = gHostTicksPerSecond / rate;
    d->writeStart = d->writeEnd = 0;
    pthread_mutex_unlock(&d->ioMutex);

    PersistConfig();
    return kAudioHardwareNoError;
}

// macOS decided not to go through with a change we requested. Nothing to undo.
static OSStatus VirtualSafeAudio_AbortDeviceConfigurationChange(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt64 action, void* info)
{
    (void)drv; (void)dev; (void)action; (void)info;
    return kAudioHardwareNoError;
}

// ---------------------------------------------------------------- IO

// Entry point: an app started playing or recording on the device. For the first app the
// device clock starts: this moment becomes sample time 0.
static OSStatus VirtualSafeAudio_StartIO(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt32 client)
{
    (void)drv; (void)client;
    Device* d = LockDeviceForIO(dev);
    if (!d) return kAudioHardwareBadObjectError;
    if (d->ioRunning == 0) {
        d->numberTimeStamps = 0;
        d->anchorHostTime = mach_absolute_time();
        d->writeStart = d->writeEnd = 0;
    }
    d->ioRunning++;
    pthread_mutex_unlock(&d->ioMutex);
    return kAudioHardwareNoError;
}

// Entry point: an app stopped. Only the count changes.
static OSStatus VirtualSafeAudio_StopIO(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt32 client)
{
    (void)drv; (void)client;
    Device* d = LockDeviceForIO(dev);
    if (!d) return kAudioHardwareBadObjectError;
    if (d->ioRunning > 0) d->ioRunning--;
    pthread_mutex_unlock(&d->ioMutex);
    return kAudioHardwareNoError;
}

// THE DEVICE CLOCK
//
// macOS needs to know how fast the device consumes samples. A hardware driver reports, at
// intervals, "my sample counter read S at host time H". We have no hardware, so we state an
// ideal clock: sample time advances by exactly kRingFrames every (kRingFrames / sampleRate)
// seconds, counted from the moment audio started (anchorHostTime). At 48 kHz one such period
// is 16384 / 48000 = 0.341 s.
//
// Each call returns the most recent tick of that clock: (sample time, host time). macOS
// interpolates between ticks to place every buffer on the timeline. The seed stays 1 because
// our timeline never jumps; a driver changes it to say "forget what you knew about my clock".
static OSStatus VirtualSafeAudio_GetZeroTimeStamp(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt32 client,
                                          Float64* outSampleTime, UInt64* outHostTime, UInt64* outSeed)
{
    (void)drv; (void)client;
    Device* d = LockDeviceForIO(dev);
    if (!d) return kAudioHardwareBadObjectError;

    UInt64 now = mach_absolute_time();
    Float64 ticksPerPeriod = d->hostTicksPerFrame * (Float64)kRingFrames;
    UInt64 next = d->anchorHostTime + (UInt64)((Float64)(d->numberTimeStamps + 1) * ticksPerPeriod);
    if (next <= now) d->numberTimeStamps++;

    *outSampleTime = (Float64)d->numberTimeStamps * (Float64)kRingFrames;
    *outHostTime   = d->anchorHostTime + (UInt64)((Float64)d->numberTimeStamps * ticksPerPeriod);
    *outSeed       = 1;

    pthread_mutex_unlock(&d->ioMutex);
    return kAudioHardwareNoError;
}

// macOS lists every stage of an IO cycle and asks which of them we take part in. Two:
//   ReadInput   fill a buffer for the apps that are recording from the device;
//   WriteMix    receive the mix of everything apps are playing into the device.
// "In place" means we work directly on the buffer macOS provides.
static OSStatus VirtualSafeAudio_WillDoIOOperation(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt32 client, UInt32 op,
                                           Boolean* outWillDo, Boolean* outInPlace)
{
    (void)drv; (void)dev; (void)client;
    Boolean will = (op == kAudioServerPlugInIOOperationReadInput || op == kAudioServerPlugInIOOperationWriteMix);
    if (outWillDo)  *outWillDo = will;
    if (outInPlace) *outInPlace = true;
    return kAudioHardwareNoError;
}

// BeginIOOperation / EndIOOperation bracket each stage. Nothing to prepare or clean up.
static OSStatus VirtualSafeAudio_BeginIOOperation(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt32 client, UInt32 op,
                                          UInt32 frames, const AudioServerPlugInIOCycleInfo* cycle)
{
    (void)drv; (void)dev; (void)client; (void)op; (void)frames; (void)cycle;
    return kAudioHardwareNoError;
}

// THE AUDIO PATH. Called on a real-time thread, many times a second, per device.
//   WriteMix    `frames` frames of playback have arrived for sample time t: store them in the
//               ring, update the meters, note the time.
//   ReadInput   `frames` frames are wanted for sample time t: if the ring holds real audio for
//               that whole span, copy it out; otherwise hand back silence.
// Nothing in here allocates memory, touches a file or waits for anything slower than the
// device's own mutex.
static OSStatus VirtualSafeAudio_DoIOOperation(AudioServerPlugInDriverRef drv, AudioObjectID dev, AudioObjectID stream, UInt32 client, UInt32 op,
                                       UInt32 frames, const AudioServerPlugInIOCycleInfo* cycle, void* mainBuffer, void* secondaryBuffer)
{
    (void)drv; (void)stream; (void)client; (void)secondaryBuffer;
    if (op != kAudioServerPlugInIOOperationReadInput && op != kAudioServerPlugInIOOperationWriteMix) return kAudioHardwareNoError;
    if (!mainBuffer || !cycle || frames > kRingFrames) return kAudioHardwareIllegalOperationError;

    Device* d = LockDeviceForIO(dev);
    if (!d) return kAudioHardwareBadObjectError;
    Float32* buf = (Float32*)mainBuffer;

    if (op == kAudioServerPlugInIOOperationWriteMix) {
        SInt64 t = (SInt64)cycle->mOutputTime.mSampleTime;
        if (t > d->writeEnd && t - d->writeEnd < kRingFrames && d->writeEnd > d->writeStart) {
            RingZero(d, d->writeEnd, (UInt32)(t - d->writeEnd));   // short dropout: keep history, fill the hole with silence
        } else if (t != d->writeEnd) {
            d->writeStart = t;                                      // fresh start or a jump: earlier ring content is stale
        }
        RingWrite(d, t, buf, frames);
        d->writeEnd = t + frames;
        Meter(d, buf, frames);
        atomic_store_explicit(&d->lastWriteHostTime, mach_absolute_time(), memory_order_relaxed);
    } else {
        SInt64 t = (SInt64)cycle->mInputTime.mSampleTime;
        // The ring holds the last kRingFrames frames that were written, but never further back
        // than the point where the current unbroken run of playback began.
        SInt64 oldest = d->writeEnd - kRingFrames;
        if (oldest < d->writeStart) oldest = d->writeStart;
        if (t >= oldest && t + (SInt64)frames <= d->writeEnd) RingRead(d, t, buf, frames);
        else memset(buf, 0, (size_t)frames * d->channels * sizeof(Float32));   // nothing is playing into this span
    }

    pthread_mutex_unlock(&d->ioMutex);
    return kAudioHardwareNoError;
}

static OSStatus VirtualSafeAudio_EndIOOperation(AudioServerPlugInDriverRef drv, AudioObjectID dev, UInt32 client, UInt32 op,
                                        UInt32 frames, const AudioServerPlugInIOCycleInfo* cycle)
{
    (void)drv; (void)dev; (void)client; (void)op; (void)frames; (void)cycle;
    return kAudioHardwareNoError;
}

// ---------------------------------------------------------------- COM plumbing + factory

// PLUMBING
//
// macOS loads drivers through an old plug-in mechanism modelled on Microsoft's COM: the
// driver hands over a table of function pointers, the host finds the table by calling
// QueryInterface and keeps a reference count with AddRef / Release. None of it does anything
// interesting here, since the driver is one global object that lives as long as the process,
// but the three functions have to exist.
static HRESULT VirtualSafeAudio_QueryInterface(void* drv, REFIID iid, LPVOID* outInterface);
static ULONG   VirtualSafeAudio_AddRef(void* drv);
static ULONG   VirtualSafeAudio_Release(void* drv);

// The table: every entry point above, in exactly the order the AudioServerPlugIn interface
// defines. coreaudiod reaches the driver only through these pointers.
static AudioServerPlugInDriverInterface gInterface = {
    NULL,
    VirtualSafeAudio_QueryInterface,
    VirtualSafeAudio_AddRef,
    VirtualSafeAudio_Release,
    VirtualSafeAudio_Initialize,
    VirtualSafeAudio_CreateDevice,
    VirtualSafeAudio_DestroyDevice,
    VirtualSafeAudio_AddDeviceClient,
    VirtualSafeAudio_RemoveDeviceClient,
    VirtualSafeAudio_PerformDeviceConfigurationChange,
    VirtualSafeAudio_AbortDeviceConfigurationChange,
    VirtualSafeAudio_HasProperty,
    VirtualSafeAudio_IsPropertySettable,
    VirtualSafeAudio_GetPropertyDataSize,
    VirtualSafeAudio_GetPropertyData,
    VirtualSafeAudio_SetPropertyData,
    VirtualSafeAudio_StartIO,
    VirtualSafeAudio_StopIO,
    VirtualSafeAudio_GetZeroTimeStamp,
    VirtualSafeAudio_WillDoIOOperation,
    VirtualSafeAudio_BeginIOOperation,
    VirtualSafeAudio_DoIOOperation,
    VirtualSafeAudio_EndIOOperation,
};
// A "driver reference" is a pointer to a pointer to the table. That is how COM objects look.
static AudioServerPlugInDriverInterface* gInterfacePtr = &gInterface;
static AudioServerPlugInDriverRef        gDriverRef    = &gInterfacePtr;

static HRESULT VirtualSafeAudio_QueryInterface(void* drv, REFIID iid, LPVOID* outInterface)
{
    if (drv != gDriverRef || !outInterface) return E_NOINTERFACE;
    CFUUIDRef requested = CFUUIDCreateFromUUIDBytes(NULL, iid);
    HRESULT result = E_NOINTERFACE;
    if (requested) {
        if (CFEqual(requested, IUnknownUUID) || CFEqual(requested, kAudioServerPlugInDriverInterfaceUUID)) {
            atomic_fetch_add(&gRefCount, 1);
            *outInterface = gDriverRef;
            result = S_OK;
        }
        CFRelease(requested);
    }
    return result;
}

static ULONG VirtualSafeAudio_AddRef(void* drv)
{
    (void)drv;
    return atomic_fetch_add(&gRefCount, 1) + 1;
}

static ULONG VirtualSafeAudio_Release(void* drv)
{
    (void)drv;
    UInt32 c = atomic_load(&gRefCount);
    if (c > 0) c = atomic_fetch_sub(&gRefCount, 1) - 1;
    return c;
}

// Named in Info.plist under CFPlugInFactories.
// The one function macOS finds by name. It is called once when the bundle is loaded and
// answers "give me your driver" with the reference above. Everything else is reached through
// the table.
void* VirtualSafeAudio_Create(CFAllocatorRef allocator, CFUUIDRef requestedTypeUUID);
void* VirtualSafeAudio_Create(CFAllocatorRef allocator, CFUUIDRef requestedTypeUUID)
{
    (void)allocator;
    if (CFEqual(requestedTypeUUID, kAudioServerPlugInTypeUUID)) return gDriverRef;
    return NULL;
}
