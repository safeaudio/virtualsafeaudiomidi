// vsamidi — virtual MIDI loopback ports for VirtualSafeAudioMIDI
//
// WHAT THIS FILE IS
//   A small command-line program. While it runs, it publishes 0..16 virtual MIDI ports.
//   Each port shows up in every MIDI app twice, under the same name: once in the list of
//   MIDI outputs (send to it) and once in the list of MIDI inputs (receive from it).
//   Whatever is sent into a port comes straight back out of it, so one app can drive
//   another. It is the MIDI counterpart of the audio driver in driver/virtualsafeaudio.c.
//
// HOW IT DIFFERS FROM THE AUDIO DRIVER
//   The audio driver is loaded by macOS itself and lives as long as the Mac is on. MIDI
//   needs no driver for this: any running program may publish virtual MIDI ports through
//   CoreMIDI. The ports exist exactly as long as that program runs. So this helper is
//   started by the control panel when MIDI is switched on and stopped when it is switched
//   off, and nothing has to be installed.
//
// COREMIDI WORDS
//   endpoint     one end of a MIDI connection.
//   destination  an endpoint apps SEND to. Ours has a callback that receives the MIDI.
//   source       an endpoint apps RECEIVE from. We feed it by calling MIDIReceived.
//   A "port" in this program is one destination plus one source with the same name, and
//   the callback of the first simply hands every packet to the second (see Forward).
//
// HOW THE CONTROL PANEL TALKS TO IT
//   Plain text lines over standard input and output. The panel is the parent process.
//     in:   uid <TAB> name        one line per port that should exist
//           .                     a line with a single dot: "that is the whole list, apply it"
//     out:  READY                 once, at start
//           OK <TAB> uid ...      after each applied list: the ports that now exist
//           A <TAB> uid=count ... whenever traffic has passed: total MIDI packets per port
//           WARN <TAB> text       a port could not be created
//           ERROR <TAB> text      could not start at all; the program exits
//   When standard input closes (the panel has gone away), the program exits and the ports
//   disappear with it.
//
// LIVE CHANGES
//   A new list is compared with the ports that exist, and only the difference is applied:
//   a port whose uid is still in the list keeps running untouched (a new name is set in
//   place), a port that is gone from the list is removed, a new uid gets a new port.
//   Traffic on the ports that stay is never interrupted.

#include <CoreMIDI/CoreMIDI.h>
#include <CoreFoundation/CoreFoundation.h>
#include <poll.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define kMaxPorts 16

// One virtual port. A fixed table of these (gPorts) holds every port; a slot is either
// alive or free.
typedef struct {
    bool            alive;
    char            uid[64];        // stable identity chosen by the control panel
    char            name[128];      // what MIDI apps display
    MIDIEndpointRef input;          // CoreMIDI destination: apps send MIDI to it
    MIDIEndpointRef output;         // CoreMIDI source: apps receive MIDI from it
    _Atomic UInt64  events;         // MIDI packets forwarded so far (written by the MIDI thread)
    UInt64          reported;       // the count last printed to the panel
} Port;

// One line of the wanted list, parsed.
typedef struct { char uid[64]; char name[128]; } Entry;

static Port          gPorts[kMaxPorts];
static MIDIClientRef gClient = 0;       // our registration with CoreMIDI

// ---------------------------------------------------------------- the MIDI path

// Called by CoreMIDI, on its own high-priority thread, whenever an app sends MIDI to one
// of our destinations. `refCon` is the Port the destination belongs to. The packets are
// passed on exactly as they arrived, time stamps included, so nothing is re-timed,
// filtered or merged. This function must stay short: it is the whole latency of the port.
static void Forward(const MIDIPacketList* packets, void* refCon, void* connectionRefCon)
{
    (void)connectionRefCon;
    Port* p = (Port*)refCon;
    if (!p->alive) return;
    MIDIReceived(p->output, packets);
    atomic_fetch_add_explicit(&p->events, packets->numPackets, memory_order_relaxed);
}

// ---------------------------------------------------------------- ports

static CFStringRef Str(const char* s)
{
    CFStringRef r = CFStringCreateWithCString(NULL, s, kCFStringEncodingUTF8);
    return r ? r : CFSTR("?");
}

// Apps such as DAWs remember a MIDI port by its "unique ID", not by its name. CoreMIDI
// would hand out a random one each time the port is created, and the DAW would then treat
// the port as new after every restart. So the ID is derived from the port's uid (FNV-1a
// hash), which makes it the same on every run. `which` is 1 for the input side and 2 for
// the output side, so the two differ and neither can be zero.
static SInt32 StableID(const char* uid, int which)
{
    UInt32 h = 2166136261u;
    for (const char* s = uid; *s; s++) h = (h ^ (unsigned char)*s) * 16777619u;
    return (SInt32)((h & 0x7FFFFFF0u) | (UInt32)which);
}

static OSStatus PortCreate(Port* p, const Entry* e)
{
    CFStringRef name = Str(e->name);
    OSStatus err = MIDIDestinationCreate(gClient, name, Forward, p, &p->input);
    if (err == 0) {
        err = MIDISourceCreate(gClient, name, &p->output);
        if (err != 0) MIDIEndpointDispose(p->input);
    }
    CFRelease(name);
    if (err != 0) return err;

    MIDIObjectSetIntegerProperty(p->input,  kMIDIPropertyUniqueID, StableID(e->uid, 1));
    MIDIObjectSetIntegerProperty(p->output, kMIDIPropertyUniqueID, StableID(e->uid, 2));
    MIDIObjectSetStringProperty(p->input,  kMIDIPropertyManufacturer, CFSTR("VirtualSafeAudioMIDI"));
    MIDIObjectSetStringProperty(p->output, kMIDIPropertyManufacturer, CFSTR("VirtualSafeAudioMIDI"));

    strlcpy(p->uid, e->uid, sizeof(p->uid));
    strlcpy(p->name, e->name, sizeof(p->name));
    atomic_store(&p->events, 0);
    p->reported = 0;
    p->alive = true;                 // last: from here on Forward passes MIDI through
    return 0;
}

static void PortRename(Port* p, const char* newName)
{
    CFStringRef name = Str(newName);
    MIDIObjectSetStringProperty(p->input,  kMIDIPropertyName, name);
    MIDIObjectSetStringProperty(p->output, kMIDIPropertyName, name);
    CFRelease(name);
    strlcpy(p->name, newName, sizeof(p->name));
}

static void PortRemove(Port* p)
{
    p->alive = false;                // first: Forward stops passing MIDI through
    MIDIEndpointDispose(p->input);
    MIDIEndpointDispose(p->output);
}

// ---------------------------------------------------------------- the wanted list

// Parses "uid <TAB> name". Returns false for a line that is not a usable port.
static bool ParseLine(const char* line, Entry* out)
{
    const char* tab = strchr(line, '\t');
    size_t uidLen = tab ? (size_t)(tab - line) : strlen(line);
    if (uidLen == 0 || uidLen >= sizeof(out->uid)) return false;
    memset(out, 0, sizeof(*out));
    memcpy(out->uid, line, uidLen);
    const char* name = (tab && tab[1]) ? tab + 1 : out->uid;      // no name given: show the uid
    strlcpy(out->name, name, sizeof(out->name));
    for (char* c = out->name; *c; c++) if ((unsigned char)*c < 0x20) *c = ' ';
    return true;
}

// Makes the live ports match the wanted list, changing as little as possible, then tells
// the panel which ports exist.
static void ApplyConfig(const Entry* e, int n)
{
    bool used[kMaxPorts] = { false };

    // Pass 1: ports that exist. Still wanted -> keep (rename if needed). Not wanted -> remove.
    for (int i = 0; i < kMaxPorts; i++) {
        Port* p = &gPorts[i];
        if (!p->alive) continue;
        int m = -1;
        for (int j = 0; j < n; j++) if (!used[j] && strcmp(e[j].uid, p->uid) == 0) { m = j; break; }
        if (m < 0) { PortRemove(p); continue; }
        used[m] = true;
        if (strcmp(e[m].name, p->name) != 0) PortRename(p, e[m].name);
    }
    // Pass 2: wanted ports that do not exist yet.
    for (int j = 0; j < n; j++) {
        if (used[j]) continue;
        for (int i = 0; i < kMaxPorts; i++) {
            if (gPorts[i].alive) continue;
            OSStatus err = PortCreate(&gPorts[i], &e[j]);
            if (err != 0) printf("WARN\tcould not create \"%s\" (CoreMIDI error %d)\n", e[j].name, (int)err);
            break;
        }
    }

    printf("OK");
    for (int i = 0; i < kMaxPorts; i++) if (gPorts[i].alive) printf("\t%s", gPorts[i].uid);
    printf("\n");
}

// Prints the packet counters, but only when something has passed since the last time.
static void ReportActivity(void)
{
    bool changed = false;
    for (int i = 0; i < kMaxPorts; i++) {
        Port* p = &gPorts[i];
        if (p->alive && atomic_load_explicit(&p->events, memory_order_relaxed) != p->reported) changed = true;
    }
    if (!changed) return;
    printf("A");
    for (int i = 0; i < kMaxPorts; i++) {
        Port* p = &gPorts[i];
        if (!p->alive) continue;
        p->reported = atomic_load_explicit(&p->events, memory_order_relaxed);
        printf("\t%s=%llu", p->uid, (unsigned long long)p->reported);
    }
    printf("\n");
}

// ---------------------------------------------------------------- talking to the panel

// Lines collect in gPending until the "." line arrives; then the list is applied as a whole.
static Entry gPending[kMaxPorts];
static int   gPendingCount = 0;

static void HandleLine(const char* line)
{
    if (strcmp(line, ".") == 0) {
        ApplyConfig(gPending, gPendingCount);
        gPendingCount = 0;
        return;
    }
#ifdef VSA_TEST
    // Test builds only: "!send <TAB> uid <TAB> n" pretends an app sent n note-ons into a port.
    if (strncmp(line, "!send\t", 6) == 0) {
        char uid[64] = "";
        int n = 0;
        if (sscanf(line + 6, "%63[^\t]\t%d", uid, &n) == 2) {
            MIDIPacketList list = { 0 };
            list.numPackets = 1;
            list.packet[0].length = 3;
            list.packet[0].data[0] = 0x90; list.packet[0].data[1] = 60; list.packet[0].data[2] = 100;
            for (int i = 0; i < kMaxPorts; i++)
                if (gPorts[i].alive && strcmp(gPorts[i].uid, uid) == 0)
                    for (int k = 0; k < n; k++) Forward(&list, &gPorts[i], NULL);
        }
        return;
    }
#endif
    Entry e;
    if (!ParseLine(line, &e)) return;                                   // junk line: ignore
    for (int j = 0; j < gPendingCount; j++) if (strcmp(gPending[j].uid, e.uid) == 0) return;   // repeated uid: first wins
    if (gPendingCount < kMaxPorts) gPending[gPendingCount++] = e;        // beyond 16: ignore
}

#ifndef VSA_NO_MAIN
int main(void)
{
    setvbuf(stdout, NULL, _IOLBF, 0);       // the panel reads us line by line

    OSStatus err = MIDIClientCreate(CFSTR("VirtualSafeAudioMIDI"), NULL, NULL, &gClient);
    if (err != 0) {
        printf("ERROR\tmacOS refused to open CoreMIDI (error %d)\n", (int)err);
        return 1;
    }
    printf("READY\n");

    // Main loop: wait up to 50 ms for input from the panel, handle every complete line that
    // has arrived, then report activity. MIDI itself does not pass through this loop; it is
    // forwarded on CoreMIDI's own thread (Forward), so nothing here can delay it.
    static char buffer[16384];
    size_t have = 0;
    struct pollfd in = { STDIN_FILENO, POLLIN, 0 };
    for (;;) {
        if (poll(&in, 1, 50) > 0) {
            ssize_t got = read(STDIN_FILENO, buffer + have, sizeof(buffer) - 1 - have);
            if (got <= 0) break;                                   // the panel has gone away
            have += (size_t)got;
            buffer[have] = 0;
            char* start = buffer;
            for (char* nl; (nl = strchr(start, '\n')) != NULL; start = nl + 1) {
                *nl = 0;
                HandleLine(start);
            }
            have = strlen(start);
            memmove(buffer, start, have);
            if (have >= sizeof(buffer) - 1) have = 0;              // one absurdly long line: drop it
        }
        ReportActivity();
    }

    for (int i = 0; i < kMaxPorts; i++) if (gPorts[i].alive) PortRemove(&gPorts[i]);
    return 0;
}
#endif
