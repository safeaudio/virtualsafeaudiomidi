// miditest — looks at MIDI ports from the outside, the way any other MIDI app would.
// The STP's Mac runner uses it to check the virtual ports that vsamidi publishes.
//
//   miditest list                  every MIDI endpoint macOS knows, one per line:
//                                      SRC|DST <TAB> uniqueID <TAB> name
//                                  SRC = apps can receive from it, DST = apps can send to it
//   miditest loop "<name>" [n]     sends n note-ons (default 100) to the endpoint called <name>
//                                  and counts how many come back from the endpoint of the same
//                                  name. Prints: sent=N received=M out_of_order=K
//                                  Exit code 0 only if all came back, in order.

#include <CoreMIDI/CoreMIDI.h>
#include <CoreFoundation/CoreFoundation.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static _Atomic int gReceived = 0;
static _Atomic int gOutOfOrder = 0;

// Called by CoreMIDI for everything that arrives from the port under test. The notes were
// sent with pitch 0,1,2,...,127,0,1,... so the order can be checked as they come back.
static void OnMIDI(const MIDIPacketList* list, void* refCon, void* connectionRefCon)
{
    (void)refCon; (void)connectionRefCon;
    const MIDIPacket* p = &list->packet[0];
    for (UInt32 i = 0; i < list->numPackets; i++) {
        if (p->length >= 3 && p->data[0] == 0x90) {
            int index = atomic_fetch_add(&gReceived, 1);
            if (p->data[1] != (Byte)(index % 128)) atomic_fetch_add(&gOutOfOrder, 1);
        }
        p = MIDIPacketNext(p);
    }
}

static void NameOf(MIDIObjectRef object, char* out, size_t size)
{
    CFStringRef s = NULL;
    out[0] = 0;
    if (MIDIObjectGetStringProperty(object, kMIDIPropertyName, &s) == 0 && s) {
        CFStringGetCString(s, out, (CFIndex)size, kCFStringEncodingUTF8);
        CFRelease(s);
    }
}

static MIDIEndpointRef Find(bool source, const char* wanted)
{
    ItemCount n = source ? MIDIGetNumberOfSources() : MIDIGetNumberOfDestinations();
    for (ItemCount i = 0; i < n; i++) {
        MIDIEndpointRef e = source ? MIDIGetSource(i) : MIDIGetDestination(i);
        char name[256];
        NameOf(e, name, sizeof(name));
        if (strcmp(name, wanted) == 0) return e;
    }
    return 0;
}

static void List(bool source)
{
    ItemCount n = source ? MIDIGetNumberOfSources() : MIDIGetNumberOfDestinations();
    for (ItemCount i = 0; i < n; i++) {
        MIDIEndpointRef e = source ? MIDIGetSource(i) : MIDIGetDestination(i);
        char name[256];
        SInt32 id = 0;
        NameOf(e, name, sizeof(name));
        MIDIObjectGetIntegerProperty(e, kMIDIPropertyUniqueID, &id);
        printf("%s\t%d\t%s\n", source ? "SRC" : "DST", (int)id, name);
    }
}

int main(int argc, char** argv)
{
    MIDIClientRef client = 0;
    if (MIDIClientCreate(CFSTR("VirtualSafeAudioMIDI test"), NULL, NULL, &client) != 0) {
        printf("error: could not open CoreMIDI\n");
        return 2;
    }

    if (argc >= 2 && strcmp(argv[1], "list") == 0) {
        List(true);
        List(false);
        return 0;
    }

    if (argc >= 3 && strcmp(argv[1], "loop") == 0) {
        int count = argc >= 4 ? atoi(argv[3]) : 100;
        MIDIEndpointRef to = Find(false, argv[2]);
        MIDIEndpointRef from = Find(true, argv[2]);
        if (!to || !from) {
            printf("error: no port called \"%s\" (%s)\n", argv[2], !to && !from ? "neither side found" : !to ? "cannot send to it" : "cannot receive from it");
            return 2;
        }
        MIDIPortRef inPort = 0, outPort = 0;
        MIDIInputPortCreate(client, CFSTR("in"), OnMIDI, NULL, &inPort);
        MIDIOutputPortCreate(client, CFSTR("out"), &outPort);
        MIDIPortConnectSource(inPort, from, NULL);
        usleep(200000);                                   // let the connection settle

        for (int i = 0; i < count; i++) {
            Byte storage[64];
            MIDIPacketList* list = (MIDIPacketList*)storage;
            MIDIPacket* packet = MIDIPacketListInit(list);
            Byte noteOn[3] = { 0x90, (Byte)(i % 128), 100 };
            MIDIPacketListAdd(list, sizeof(storage), packet, 0, sizeof(noteOn), noteOn);
            MIDISend(outPort, to, list);
            usleep(1000);
        }
        for (int waited = 0; waited < 2000 && atomic_load(&gReceived) < count; waited += 10) usleep(10000);

        int received = atomic_load(&gReceived), bad = atomic_load(&gOutOfOrder);
        printf("sent=%d received=%d out_of_order=%d\n", count, received, bad);
        return (received == count && bad == 0) ? 0 : 1;
    }

    printf("usage: miditest list | miditest loop \"<port name>\" [count]\n");
    return 2;
}
