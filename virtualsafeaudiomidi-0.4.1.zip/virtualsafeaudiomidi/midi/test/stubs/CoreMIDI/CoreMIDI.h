#pragma once
// Stand-in for Apple's CoreMIDI header, just enough to compile and test off-Mac.
#include <CoreFoundation/CoreFoundation.h>
typedef UInt32 MIDIObjectRef, MIDIClientRef, MIDIEndpointRef, MIDIPortRef;
typedef UInt64 MIDITimeStamp; typedef unsigned char Byte; typedef uint16_t UInt16; typedef unsigned long ItemCount;
#pragma pack(push, 4)
typedef struct { MIDITimeStamp timeStamp; UInt16 length; Byte data[256]; } MIDIPacket;
typedef struct { UInt32 numPackets; MIDIPacket packet[1]; } MIDIPacketList;
#pragma pack(pop)
typedef void (*MIDIReadProc)(const MIDIPacketList*, void*, void*);
typedef void (*MIDINotifyProc)(const void*, void*);
extern CFStringRef kMIDIPropertyName, kMIDIPropertyUniqueID, kMIDIPropertyManufacturer;
OSStatus MIDIClientCreate(CFStringRef, MIDINotifyProc, void*, MIDIClientRef*);
OSStatus MIDIDestinationCreate(MIDIClientRef, CFStringRef, MIDIReadProc, void*, MIDIEndpointRef*);
OSStatus MIDISourceCreate(MIDIClientRef, CFStringRef, MIDIEndpointRef*);
OSStatus MIDIReceived(MIDIEndpointRef, const MIDIPacketList*);
OSStatus MIDIEndpointDispose(MIDIEndpointRef);
OSStatus MIDIObjectSetStringProperty(MIDIObjectRef, CFStringRef, CFStringRef);
OSStatus MIDIObjectSetIntegerProperty(MIDIObjectRef, CFStringRef, SInt32);
OSStatus MIDIObjectGetStringProperty(MIDIObjectRef, CFStringRef, CFStringRef*);
OSStatus MIDIObjectGetIntegerProperty(MIDIObjectRef, CFStringRef, SInt32*);
ItemCount MIDIGetNumberOfSources(void); ItemCount MIDIGetNumberOfDestinations(void);
MIDIEndpointRef MIDIGetSource(ItemCount); MIDIEndpointRef MIDIGetDestination(ItemCount);
OSStatus MIDIInputPortCreate(MIDIClientRef, CFStringRef, MIDIReadProc, void*, MIDIPortRef*);
OSStatus MIDIOutputPortCreate(MIDIClientRef, CFStringRef, MIDIPortRef*);
OSStatus MIDIPortConnectSource(MIDIPortRef, MIDIEndpointRef, void*);
OSStatus MIDISend(MIDIPortRef, MIDIEndpointRef, const MIDIPacketList*);
MIDIPacket* MIDIPacketListInit(MIDIPacketList*);
MIDIPacket* MIDIPacketListAdd(MIDIPacketList*, unsigned long, MIDIPacket*, MIDITimeStamp, unsigned long, const Byte*);
static inline const MIDIPacket* MIDIPacketNext(const MIDIPacket* p) { return (const MIDIPacket*)&p->data[p->length]; }
