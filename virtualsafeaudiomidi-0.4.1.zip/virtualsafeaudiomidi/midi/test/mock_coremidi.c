#include "mock_coremidi.h"
#include <stdlib.h>
#include <string.h>

// ---- a few CoreFoundation strings
struct __CFString { char* s; };
CFStringRef __stub_cfstr(const char* s) { struct __CFString* r = malloc(sizeof *r); r->s = strdup(s); return r; }
CFStringRef CFStringCreateWithCString(CFAllocatorRef a, const char* s, CFStringEncoding e) { (void)a; (void)e; return __stub_cfstr(s); }
Boolean CFStringGetCString(CFStringRef s, char* buf, CFIndex n, CFStringEncoding e) { (void)e; if ((CFIndex)strlen(s->s) >= n) return 0; strcpy(buf, s->s); return 1; }
void CFRelease(CFTypeRef r) { (void)r; }
static struct __CFString kName = { "name" }, kUnique = { "uniqueID" }, kMaker = { "manufacturer" };
CFStringRef kMIDIPropertyName = &kName, kMIDIPropertyUniqueID = &kUnique, kMIDIPropertyManufacturer = &kMaker;

// ---- endpoints
static MockEndpoint gEnd[256];
static int gEndCount = 0;
static MockEndpoint* ByRef(MIDIEndpointRef ref) { for (int i = 0; i < gEndCount; i++) if (gEnd[i].ref == ref) return &gEnd[i]; return NULL; }

static MockEndpoint* New(CFStringRef name, bool isSource)
{
    if (gEndCount >= 256) return NULL;
    MockEndpoint* e = &gEnd[gEndCount];
    memset(e, 0, sizeof *e);
    e->ref = 1000 + (MIDIEndpointRef)gEndCount++;
    e->isSource = isSource;
    strncpy(e->name, name->s, sizeof(e->name) - 1);
    return e;
}

OSStatus MIDIClientCreate(CFStringRef n, MIDINotifyProc p, void* r, MIDIClientRef* out) { (void)n; (void)p; (void)r; *out = 1; return 0; }
OSStatus MIDIDestinationCreate(MIDIClientRef c, CFStringRef name, MIDIReadProc proc, void* refCon, MIDIEndpointRef* out)
{ (void)c; MockEndpoint* e = New(name, false); if (!e) return -1; e->proc = proc; e->refCon = refCon; *out = e->ref; return 0; }
OSStatus MIDISourceCreate(MIDIClientRef c, CFStringRef name, MIDIEndpointRef* out)
{ (void)c; MockEndpoint* e = New(name, true); if (!e) return -1; *out = e->ref; return 0; }
OSStatus MIDIEndpointDispose(MIDIEndpointRef ref) { MockEndpoint* e = ByRef(ref); if (!e || e->disposed) return -1; e->disposed = true; return 0; }
OSStatus MIDIObjectSetStringProperty(MIDIObjectRef ref, CFStringRef key, CFStringRef value)
{ MockEndpoint* e = ByRef(ref); if (!e) return -1; if (key == kMIDIPropertyName) strncpy(e->name, value->s, sizeof(e->name) - 1); return 0; }
OSStatus MIDIObjectSetIntegerProperty(MIDIObjectRef ref, CFStringRef key, SInt32 value)
{ MockEndpoint* e = ByRef(ref); if (!e) return -1; if (key == kMIDIPropertyUniqueID) e->uniqueID = value; return 0; }
OSStatus MIDIReceived(MIDIEndpointRef ref, const MIDIPacketList* list)
{
    MockEndpoint* e = ByRef(ref);
    if (!e || e->disposed || !e->isSource) return -1;
    e->packetsOut += (int)list->numPackets;
    e->lastLength = list->packet[0].length > 256 ? 256 : list->packet[0].length;
    memcpy(e->last, list->packet[0].data, (size_t)e->lastLength);
    return 0;
}

// ---- the test's side
int MockLiveCount(void) { int n = 0; for (int i = 0; i < gEndCount; i++) if (!gEnd[i].disposed) n++; return n; }
int MockCreatedTotal(void) { return gEndCount; }
MockEndpoint* MockFind(const char* name, bool isSource)
{ for (int i = 0; i < gEndCount; i++) if (!gEnd[i].disposed && gEnd[i].isSource == isSource && strcmp(gEnd[i].name, name) == 0) return &gEnd[i]; return NULL; }
void MockAppSends(MockEndpoint* d, const Byte* bytes, int length)
{
    MIDIPacketList list; memset(&list, 0, sizeof list);
    list.numPackets = 1; list.packet[0].length = (UInt16)length; memcpy(list.packet[0].data, bytes, (size_t)length);
    if (d && !d->disposed && d->proc) d->proc(&list, d->refCon, NULL);
}
