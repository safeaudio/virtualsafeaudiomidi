#pragma once
// A pretend CoreMIDI for tests: records every endpoint and every packet, and lets a test
// play the part of "another MIDI app".
#include <CoreMIDI/CoreMIDI.h>
#include <stdbool.h>
typedef struct {
    MIDIEndpointRef ref; bool isSource, disposed; char name[128]; SInt32 uniqueID;
    MIDIReadProc proc; void* refCon;             // destinations: where sent MIDI is delivered
    int packetsOut; Byte last[256]; int lastLength; // sources: what apps listening would have received
} MockEndpoint;
int           MockLiveCount(void);
MockEndpoint* MockFind(const char* name, bool isSource);     // live endpoints only
void          MockAppSends(MockEndpoint* destination, const Byte* bytes, int length);
int           MockCreatedTotal(void);
