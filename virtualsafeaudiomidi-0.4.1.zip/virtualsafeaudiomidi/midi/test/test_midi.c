// Off-Mac logic test for the MIDI helper. Compiles vsamidi.c against a pretend CoreMIDI
// (mock_coremidi.c) and plays the part of the control panel and of other MIDI apps.
// Each CASE is one test in the STP.
//
//   gcc -std=c11 -D_GNU_SOURCE -Istubs -I../../driver/test/stubs test_midi.c mock_coremidi.c -o test_midi && ./test_midi

#define VSA_NO_MAIN
#include "../vsamidi.c"
#include "mock_coremidi.h"

static int gChecks = 0;
static const char* gCase = NULL;
static const char* gTitle = NULL;
static FILE* gReport = NULL;                 // the real standard output; the helper's own chatter is sent elsewhere
static void EndCase(void) { if (gCase) fprintf(gReport, "PASS %s %s\n", gCase, gTitle); }
#define CASE(id, title) do { EndCase(); gCase = id; gTitle = title; } while (0)
#define CHECK(cond) do { gChecks++; if (!(cond)) { fprintf(gReport, "FAIL %s %s (line %d: %s)\n", gCase ? gCase : "?", gTitle ? gTitle : "", __LINE__, #cond); exit(1); } } while (0)

// What the control panel would send: lines, then the dot.
static void Panel(const char* text)
{
    char copy[4096]; strncpy(copy, text, sizeof copy - 1); copy[sizeof copy - 1] = 0;
    char* save = NULL;
    for (char* line = strtok_r(copy, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) HandleLine(line);
    HandleLine(".");
}
static Port* PortByUID(const char* uid) { for (int i = 0; i < kMaxPorts; i++) if (gPorts[i].alive && strcmp(gPorts[i].uid, uid) == 0) return &gPorts[i]; return NULL; }

int main(void)
{
    gReport = fdopen(dup(STDOUT_FILENO), "w");
    if (!freopen("/dev/null", "w", stdout)) return 2;    // the helper's protocol lines (OK ..., A ...) are not under test here
    (void)ReportActivity;
    MIDIClientCreate(CFSTR("test"), NULL, NULL, &gClient);
    const Byte noteOn[3] = { 0x90, 60, 100 };

    CASE("MID-001", "Each port is published as one input and one output with the same name");
    Panel("a\tSynth bus\nb\tDrum bus");
    CHECK(MockLiveCount() == 4);
    CHECK(MockFind("Synth bus", false) && MockFind("Synth bus", true));
    CHECK(MockFind("Drum bus", false) && MockFind("Drum bus", true));

    CASE("MID-002", "MIDI sent into a port comes out of the same port unchanged");
    MockAppSends(MockFind("Synth bus", false), noteOn, 3);
    MockEndpoint* out = MockFind("Synth bus", true);
    CHECK(out->packetsOut == 1 && out->lastLength == 3 && memcmp(out->last, noteOn, 3) == 0);

    CASE("MID-003", "Ports do not leak into each other");
    CHECK(MockFind("Drum bus", true)->packetsOut == 0);
    MockAppSends(MockFind("Drum bus", false), noteOn, 3);
    CHECK(MockFind("Drum bus", true)->packetsOut == 1 && out->packetsOut == 1);

    CASE("MID-004", "A long message (system exclusive, 200 bytes) passes through intact");
    Byte sysex[200]; sysex[0] = 0xF0; for (int i = 1; i < 199; i++) sysex[i] = (Byte)(i & 0x7F); sysex[199] = 0xF7;
    MIDIPacketList big; memset(&big, 0, sizeof big); big.numPackets = 1; big.packet[0].length = 200; memcpy(big.packet[0].data, sysex, 200);
    int before = out->packetsOut;
    Forward(&big, PortByUID("a"), NULL);
    CHECK(out->packetsOut == before + 1 && out->lastLength == 200 && memcmp(out->last, sysex, 200) == 0);

    CASE("MID-005", "Traffic is counted per port");
    CHECK(atomic_load(&PortByUID("a")->events) == 2 && atomic_load(&PortByUID("b")->events) == 1);

    CASE("MID-006", "Renaming a port keeps the same endpoints; only the name changes");
    MIDIEndpointRef inBefore = PortByUID("a")->input, outBefore = PortByUID("a")->output;
    int created = MockCreatedTotal();
    Panel("a\tLead synth\nb\tDrum bus");
    CHECK(PortByUID("a")->input == inBefore && PortByUID("a")->output == outBefore && MockCreatedTotal() == created);
    CHECK(MockFind("Lead synth", false) && MockFind("Lead synth", true) && !MockFind("Synth bus", true));

    CASE("MID-007", "Adding a port leaves the existing ports untouched");
    Panel("a\tLead synth\nb\tDrum bus\nc\tClock");
    CHECK(MockLiveCount() == 6 && PortByUID("a")->input == inBefore && MockCreatedTotal() == created + 2);
    MockAppSends(MockFind("Lead synth", false), noteOn, 3);
    CHECK(atomic_load(&PortByUID("a")->events) == 3);                 // still the same port, still counting

    CASE("MID-008", "Removing a port takes away both of its sides and nothing else");
    Panel("a\tLead synth\nc\tClock");
    CHECK(MockLiveCount() == 4 && !MockFind("Drum bus", false) && !MockFind("Drum bus", true));
    CHECK(PortByUID("a")->input == inBefore && PortByUID("b") == NULL);

    CASE("MID-009", "A port keeps the same unique IDs every time it is created, different for its two sides");
    SInt32 inID = MockFind("Clock", false)->uniqueID, outID = MockFind("Clock", true)->uniqueID;
    CHECK(inID != 0 && outID != 0 && inID != outID);
    Panel("a\tLead synth");
    Panel("a\tLead synth\nc\tClock");
    CHECK(MockFind("Clock", false)->uniqueID == inID && MockFind("Clock", true)->uniqueID == outID);
    CHECK(MockFind("Lead synth", false)->uniqueID != inID);

    CASE("MID-010", "Junk lines are ignored, a repeated port is created once, and no more than 16 ports exist");
    Panel("\tno uid\na\tLead synth\na\tDuplicate\nplain");
    CHECK(MockLiveCount() == 4 && PortByUID("plain") && strcmp(PortByUID("plain")->name, "plain") == 0 && !MockFind("Duplicate", true));
    char many[2048] = ""; for (int i = 0; i < 20; i++) sprintf(many + strlen(many), "p%d\tPort %d\n", i, i);
    Panel(many);
    CHECK(MockLiveCount() == 2 * kMaxPorts && PortByUID("p15") && !PortByUID("p16"));

    CASE("MID-011", "An empty list removes every port");
    Panel("");
    CHECK(MockLiveCount() == 0);
    MockAppSends(MockFind("Port 0", false), noteOn, 3);               // nothing there any more; must not crash

    EndCase();
    fprintf(gReport, "midi helper logic: %d checks passed\n", gChecks);
    return 0;
}
