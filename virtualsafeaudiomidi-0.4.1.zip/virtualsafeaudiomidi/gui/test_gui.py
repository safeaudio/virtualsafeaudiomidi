#!/usr/bin/env python3
"""Control panel server tests, run against the mock driver. Each case is one STP test.

    python3 gui/test_gui.py

Prints one "PASS <id> <title>" or "FAIL <id> <title> (<what>)" line per case.
"""
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import threading
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import virtualsafeaudiomidi_gui as lg

results = []
_current = None


def case(test_id, title):
    global _current
    _current = [test_id, title, []]
    results.append(_current)


def check(cond, what):
    if not cond:
        _current[2].append(what)


def raises(fn, what):
    try:
        fn()
    except ValueError:
        return
    _current[2].append(what + " was accepted")


# ---------------------------------------------------------------- wire formats
devs = [{"uid": "a", "channels": 2, "sampleRate": 48000, "name": "Desk return"},
        {"uid": "b", "channels": 16, "sampleRate": 96000, "name": "אפיק ב"}]

case("API-001", "Device list text format round-trips, including a Hebrew name")
text = lg.format_config(devs)
check(text == "a\t2\t48000\tDesk return\nb\t16\t96000\tאפיק ב\n", "layout")
check(lg.parse_config(text) == devs, "round-trip")

case("API-002", "Malformed lines in the driver's device list are skipped")
check(lg.parse_config("junk\n\nx\tNaN\t1\tn\nok\t4\t44100\tName with\ttab\n") ==
      [{"uid": "ok", "channels": 4, "sampleRate": 44100, "name": "Name with\ttab"}], "parse result")

case("API-003", "Meter text from the driver is parsed per device")
check(lg.parse_meters("a\t0.5000,0.2500,1.0000,0.7071\nb\t\nbad line\n") == {"a": [0.5, 0.25, 1.0, 0.7071], "b": []}, "parse result")

# ---------------------------------------------------------------- validating what the browser sends
cur = [{"uid": "a", "channels": 2, "sampleRate": 96000, "name": "A"}]
out = lg.sanitize_devices([{"uid": "a", "name": "  New\tname\n", "channels": 2}, {"name": "", "channels": 8}], cur)

case("API-004", "An edited device keeps its ID and sample rate; control characters are stripped from the name")
check(out[0] == {"uid": "a", "name": "New name", "channels": 2, "sampleRate": 96000}, "result %r" % (out[0],))

case("API-005", "A new device is stereo at 48 kHz and takes the lowest free number as its name and its ID")
check(out[1] == {"uid": "virtualsafeaudio-1", "name": "VirtualSafeAudio#1", "channels": 2, "sampleRate": 48000}, "result %r" % (out[1],))

case("API-006", "An invalid device ID from the browser is replaced, not passed to the driver")
check(lg.sanitize_devices([{"uid": "has space", "name": "x", "channels": 1}], [])[0]["uid"].startswith("virtualsafeaudio-"), "uid kept")

case("API-007", "A preset's sample rate is used when its device does not exist yet")
check(lg.sanitize_devices([{"uid": "p", "name": "x", "channels": 1, "sampleRate": 88200}], [])[0]["sampleRate"] == 88200, "rate")

case("API-008", "A very long non-ASCII name is shortened to fit the driver's name buffer")
check(len(lg.sanitize_devices([{"name": "ש" * 200, "channels": 1}], [])[0]["name"].encode()) <= lg.NAME_MAX_BYTES, "too long")

case("API-009", "An empty device list is accepted")
check(lg.sanitize_devices([], cur) == [], "result")

case("API-010", "Invalid device lists are rejected (wrong type, duplicate ID, duplicate name, 17 devices); a channel count from the browser is ignored")
raises(lambda: lg.sanitize_devices("nope", []), "non-list")
raises(lambda: lg.sanitize_devices([{"uid": "a", "name": "x"}, {"uid": "a", "name": "y"}], []), "duplicate id")
raises(lambda: lg.sanitize_devices([{"name": "Same"}, {"name": "Same"}], []), "duplicate name")
raises(lambda: lg.sanitize_devices([{}] * 17, []), "17 devices")
check([d["channels"] for d in lg.sanitize_devices([{"channels": 0}, {"channels": 64}, {"channels": "8"}], [])] == [2, 2, 2], "a device was not stereo")

case("API-043", "Numbering: new devices take the lowest free number, so a removed number is reused; renamed devices do not block it")
have = [{"uid": "virtualsafeaudio-1", "name": "VirtualSafeAudio#1"}, {"uid": "virtualsafeaudio-3", "name": "VirtualSafeAudio#3"}]
got = lg.sanitize_devices(have + [{}, {}], [])
check([(d["uid"], d["name"]) for d in got[2:]] == [("virtualsafeaudio-2", "VirtualSafeAudio#2"), ("virtualsafeaudio-4", "VirtualSafeAudio#4")], "got %r" % (got[2:],))
got = lg.sanitize_devices([{"uid": "virtualsafeaudio-1", "name": "Desk return"}, {}], [])
check((got[1]["uid"], got[1]["name"]) == ("virtualsafeaudio-2", "VirtualSafeAudio#1"), "got %r" % (got[1],))
check([p["name"] for p in lg.sanitize_ports([{}, {"name": "Clock"}, {}])] == ["VirtualSafeMIDI#1", "Clock", "VirtualSafeMIDI#2"], "MIDI numbering")

# ---------------------------------------------------------------- HTTP API end to end
tmp = tempfile.mkdtemp()
backend = lg.MockBackend()
server = lg.make_server("127.0.0.1", 0, lg.App(backend, tmp, "mock"))
threading.Thread(target=server.serve_forever, daemon=True).start()
base = "http://127.0.0.1:%d" % server.server_address[1]


def call(path, body=None, content_type="application/json"):
    req = urllib.request.Request(base + path)
    if body is not None:
        req.data = json.dumps(body).encode()
        req.add_header("Content-Type", content_type)
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


case("API-011", "GET /api/state returns devices, mode, limits and presets")
status, st = call("/api/state")
check(status == 200 and st["connected"] and st["mode"] == "mock" and len(st["devices"]) == 2, "state %r" % (st,))
check(st["limits"] == {"maxDevices": 16, "maxPorts": 16} and st["presets"] == {}, "limits/presets")

case("API-012", "GET / serves the control panel page")
with urllib.request.urlopen(base + "/") as r:
    page = r.read().decode()
check("<title>VirtualSafeAudioMIDI</title>" in page, "title missing")

case("API-013", "POST /api/config applies a device list and the driver receives exactly that list")
status, st = call("/api/config", {"devices": [{"uid": "virtualsafeaudio-1", "name": "Main", "channels": 4}, {"name": "Second"}]})
check(status == 200 and [d["channels"] for d in st["devices"]] == [2, 2], "response")
check(backend.config == "virtualsafeaudio-1\t2\t48000\tMain\nvirtualsafeaudio-2\t2\t48000\tSecond\n", "driver got %r" % backend.config)
new_uid = st["devices"][1]["uid"]

case("API-014", "An invalid device list returns 400 with a readable message and leaves the driver untouched")
status, err = call("/api/config", {"devices": [{"name": "Same"}, {"name": "Same"}]})
check(status == 400 and "both called" in err.get("error", ""), "status %s %r" % (status, err))
check(len(lg.parse_config(backend.config)) == 2, "driver config changed")

case("API-015", "A POST that is not JSON is refused (blocks cross-site form posts)")
status, _ = call("/api/config", {"devices": []}, content_type="text/plain")
check(status == 415, "status %s" % status)
check(len(lg.parse_config(backend.config)) == 2, "driver config changed")

case("API-016", "An unknown address returns 404")
status, _ = call("/api/nope")
check(status == 404, "status %s" % status)

case("API-017", "Saving a preset stores the devices with their IDs on disk")
status, st = call("/api/state")
status, st = call("/api/presets", {"name": "Live set", "devices": st["devices"]})
check(status == 200 and [d["uid"] for d in st["presets"]["Live set"]["devices"]] == ["virtualsafeaudio-1", new_uid], "preset content")
check(os.path.exists(os.path.join(tmp, "presets.json")), "presets.json missing")

case("API-018", "A preset without a name is refused")
status, err = call("/api/presets", {"name": "  ", "devices": []})
check(status == 400, "status %s" % status)

case("API-019", "Presets are still there after the panel server restarts")
check("Live set" in lg.App(lg.MockBackend(), tmp, "mock").state()["presets"], "preset lost")

case("API-020", "Deleting a preset removes it")
status, st = call("/api/presets/delete", {"name": "Live set"})
check(status == 200 and st["presets"] == {}, "still present")

case("API-021", "Meter stream delivers events with peak and RMS for every channel, all within 0..1")
with urllib.request.urlopen(base + "/api/meters", timeout=5) as r:
    check(r.headers["Content-Type"] == "text/event-stream", "content type")
    events = []
    while len(events) < 3:
        line = r.readline().decode()
        if line.startswith("data: "):
            events.append(json.loads(line[6:]))
check(all(sorted(e) == sorted(["virtualsafeaudio-1", new_uid]) and all(len(v) == 4 for v in e.values()) for e in events), "values per channel")
check(all(0 <= v <= 1 for e in events for vals in e.values() for v in vals), "range")


class Missing:
    def get_config(self):
        raise lg.DriverError("The VirtualSafeAudio driver is not loaded.")
    get_meters = get_config

    def set_config(self, text):
        raise lg.DriverError("The VirtualSafeAudio driver is not loaded.")


case("API-022", "With no driver installed the server reports it plainly and keeps running")
app = lg.App(Missing(), tmp, "driver")
st = app.state()
check(not st["connected"] and "not loaded" in st["error"] and st["devices"] == [], "state %r" % (st,))
check(app.meters_json() == (b"{}", False), "meters")

# ---------------------------------------------------------------- switching audio on and off
before_off = backend.config

case("API-031", "Switching audio off tells the driver to publish nothing and remembers the layout")
status, st = call("/api/audio/active", {"active": False})
check(status == 200 and backend.config == "", "driver still has %r" % backend.config)
check(st["audio"] == {"active": False, "installed": True, "saved": 2, "keep": False} and st["devices"] == [], "state %r" % (st["audio"],))

case("API-032", "Audio devices cannot be edited while audio is off")
status, err = call("/api/config", {"devices": [{"name": "x", "channels": 2}]})
check(status == 400 and "off" in err.get("error", "") and backend.config == "", "status %s %r" % (status, err))

case("API-033", "The audio on/off choice is remembered when the panel restarts")
check(lg.App(backend, tmp, "mock").state()["audio"]["active"] is False, "came back switched on")

case("API-034", "Switching audio on again brings back exactly the devices that were there")
status, st = call("/api/audio/active", {"active": True})
check(status == 200 and backend.config == before_off, "driver has %r" % backend.config)
check(st["audio"]["active"] is True and len(st["devices"]) == 2, "state")

case("API-035", "A preset holds audio devices and MIDI ports together; a version 0.1 preset still loads")
status, st = call("/api/presets", {"name": "Both", "devices": st["devices"], "ports": [{"name": "Clock"}, {"name": "Notes"}]})
both = st["presets"].get("Both", {})
check(status == 200 and len(both.get("devices", [])) == 2 and [p["name"] for p in both.get("ports", [])] == ["Clock", "Notes"], "preset %r" % (both,))
check(lg.normalize_preset([{"uid": "a", "name": "A", "channels": 2, "sampleRate": 48000}]) ==
      {"devices": [{"uid": "a", "name": "A", "channels": 2, "sampleRate": 48000}], "ports": []}, "old preset format")

server.shutdown()

# ---------------------------------------------------------------- installing the audio driver from the panel
case("INS-038", "The administrator step of the panel's install reads only a staged copy, never the project folder")
project = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
work = tempfile.mkdtemp()
staged = os.path.join(work, "it's a staging dir", "VirtualSafeAudio.driver")       # awkward on purpose: space and quote
dest = os.path.join(work, "HAL folder")
os.makedirs(os.path.join(staged, "Contents", "MacOS"))
open(os.path.join(staged, "Contents", "MacOS", "VirtualSafeAudio"), "w").write("new build")
os.makedirs(os.path.join(dest, "VirtualSafeAudio.driver", "Contents"))
open(os.path.join(dest, "VirtualSafeAudio.driver", "Contents", "left-over"), "w").write("old build")
real = lg.install_shell_command("/tmp/vsa-install-x/VirtualSafeAudio.driver")
check(project not in real and "install.sh" not in real, "command refers to the project folder: " + real)
check(real.startswith("mkdir -p /Library/Audio/Plug-Ins/HAL && rm -rf /Library/Audio/Plug-Ins/HAL/VirtualSafeAudio.driver && cp -R /tmp/vsa-install-x/VirtualSafeAudio.driver /Library/Audio/Plug-Ins/HAL/ && chown -R root:wheel")
      and real.endswith("&& (killall -9 coreaudiod || true)"), "unexpected command: " + real)
ran = subprocess.run(["/bin/sh", "-c", lg.install_shell_command(staged, dest_dir=dest, owner=None, restart=False)],
                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
installed = os.path.join(dest, "VirtualSafeAudio.driver", "Contents")
check(ran.returncode == 0, "command failed: " + ran.stdout.strip())
check(os.path.exists(os.path.join(installed, "MacOS", "VirtualSafeAudio")) and
      open(os.path.join(installed, "MacOS", "VirtualSafeAudio")).read() == "new build", "new driver not in place")
check(not os.path.exists(os.path.join(installed, "left-over")), "files of the previous install were left behind")

# ---------------------------------------------------------------- audio devices follow the app
class FakeGuard:                       # records what the panel tells its guard process
    def __init__(self):
        self.modes, self.released = [], False

    def set_mode(self, mode):
        self.modes.append(mode)

    def release(self):
        self.released = True


case("API-037", "The guard removes the audio devices when its panel goes away in follow mode, and only then")
b = lg.MockBackend()
lg.run_audio_guard(b, io.StringIO("follow\nkeep\n"))
check(b.config != "", "devices removed although the last word was keep")
lg.run_audio_guard(b, io.StringIO(""))
check(b.config != "", "devices removed although the guard was never told to follow")
lg.run_audio_guard(b, io.StringIO("keep\nfollow\n"))
check(b.config == "", "devices still there after the panel went away in follow mode")
lg.run_audio_guard(Missing(), io.StringIO("follow\n"))            # no driver: must end quietly, not crash

case("API-038", "By default audio follows the app: devices leave when the panel closes and the same ones return at the next start")
tmp_follow = tempfile.mkdtemp()
driver = lg.MockBackend()
layout = driver.config
g1 = FakeGuard()
first = lg.App(driver, tmp_follow, "mock", guard=g1)
st = first.state()
check(st["audio"]["keep"] is False and g1.modes[-1:] == ["follow"], "keep=%r, guard told %r" % (st["audio"]["keep"], g1.modes))
first.shutdown()
check(g1.released, "guard was not released at shutdown")
lg.run_audio_guard(driver, io.StringIO("follow\n"))                 # what the real guard process does at that moment
check(driver.config == "", "devices not removed")
again = lg.App(driver, tmp_follow, "mock", guard=FakeGuard())
st = again.state()
check(driver.config == layout and len(st["devices"]) == 2, "after restart the driver has %r" % driver.config)

case("API-039", "With Keep switched on the devices are left alone, and the choice is remembered")
g2 = FakeGuard()
keeper = lg.App(driver, tmp_follow, "mock", guard=g2)
st = keeper.set_audio_keep(True)
check(st["audio"]["keep"] is True and g2.modes[-1] == "keep", "keep=%r, guard told %r" % (st["audio"]["keep"], g2.modes))
g3 = FakeGuard()
check(lg.App(driver, tmp_follow, "mock", guard=g3).state()["audio"]["keep"] is True and g3.modes[-1] == "keep", "not remembered")
status_keep = lg.App(driver, tempfile.mkdtemp(), "mock", guard=FakeGuard(), keep_audio=True)
check(status_keep.state()["audio"]["keep"] is True and status_keep.guard.modes[-1] == "keep", "--keep-audio did not force keep")
keeper.set_audio_keep(False)

case("API-040", "Audio that was switched off, or a layout emptied on purpose, is not brought back at the next start")
g4 = FakeGuard()
off = lg.App(driver, tmp_follow, "mock", guard=g4)
off.set_audio_active(False)
check(driver.config == "" and g4.modes[-1] == "keep", "after switching off: driver %r, guard %r" % (driver.config, g4.modes[-1]))
st = lg.App(driver, tmp_follow, "mock", guard=FakeGuard()).state()
check(driver.config == "" and st["audio"]["active"] is False, "switched-off audio came back")
tmp_empty = tempfile.mkdtemp()
driver2 = lg.MockBackend()
emptied = lg.App(driver2, tmp_empty, "mock", guard=FakeGuard())
emptied.state()
emptied.apply({"devices": []})
check(lg.App(driver2, tmp_empty, "mock", guard=FakeGuard()).state()["devices"] == [] and driver2.config == "", "deliberately empty layout was refilled")

case("API-041", "A guard that acts late (an older copy being replaced) cannot wipe the layout: the running panel puts it back")
tmp_race = tempfile.mkdtemp()
driver3 = lg.MockBackend()
layout3 = driver3.config
newer = lg.App(driver3, tmp_race, "mock", guard=FakeGuard())
check(len(newer.state()["devices"]) == 2, "setup")
lg.run_audio_guard(driver3, io.StringIO("follow\n"))                 # the replaced copy's guard fires after the new panel is up
check(driver3.config == "", "setup: guard did not empty the list")
st = newer.state()
check(driver3.config == layout3 and len(st["devices"]) == 2, "layout not restored: driver has %r" % driver3.config)
check(len(lg.App(driver3, tmp_race, "mock", guard=FakeGuard()).state()["devices"]) == 2, "layout was lost for the next start")

case("API-042", "Devices found in the driver are brought in line: the app's own become stereo and the driver's first-run device becomes #1; others are left alone")
found = lg.MockBackend()
found.config = "virtualsafeaudio-main\t6\t48000\tVirtualSafeAudio\nvirtualsafeaudio-7\t8\t96000\tBus\nstp-test\t8\t48000\tSTP test device\n"
st = lg.App(found, tempfile.mkdtemp(), "mock", guard=FakeGuard()).state()
check(found.config == "virtualsafeaudio-main\t2\t48000\tVirtualSafeAudio#1\nvirtualsafeaudio-7\t2\t96000\tBus\nstp-test\t8\t48000\tSTP test device\n",
      "driver has %r" % found.config)
check([d["name"] for d in st["devices"]] == ["VirtualSafeAudio#1", "Bus", "STP test device"], "state %r" % (st["devices"],))

case("API-044", "A renamed device is taken out and put back under the same identity, so that macOS shows the new name; others are untouched")
drv = lg.MockBackend()
renamer = lg.App(drv, tempfile.mkdtemp(), "mock", guard=FakeGuard())
renamer.state()
drv.history.clear()
renamer.apply({"devices": [{"uid": "virtualsafeaudio-1", "name": "VirtualSafeAudio#1"}, {"uid": "virtualsafeaudio-2", "name": "Desk return"}]})
check(len(drv.history) == 2, "driver was handed %d lists, expected 2 (without the device, then with it)" % len(drv.history))
check(drv.history[0] == "virtualsafeaudio-1\t2\t48000\tVirtualSafeAudio#1\n", "first list: %r" % drv.history[:1])
check(drv.history[-1] == "virtualsafeaudio-1\t2\t48000\tVirtualSafeAudio#1\nvirtualsafeaudio-2\t2\t48000\tDesk return\n", "last list: %r" % drv.history[-1:])
check(drv.config == drv.history[-1], "device did not come back in its old place: %r" % drv.config)
drv.history.clear()
renamer.apply({"devices": [{"uid": "virtualsafeaudio-1", "name": "VirtualSafeAudio#1"}, {"uid": "virtualsafeaudio-2", "name": "Desk return"}, {}]})
check(len(drv.history) == 1, "adding a device took %d steps; only a rename needs two" % len(drv.history))
old_default = lg.MockBackend()
old_default.config = "virtualsafeaudio-main\t2\t48000\tVirtualSafeAudio\n"
lg.App(old_default, tempfile.mkdtemp(), "mock", guard=FakeGuard()).state()
check(old_default.history == ["", "virtualsafeaudio-main\t2\t48000\tVirtualSafeAudio#1\n"], "the driver's first device was not republished as #1: %r" % old_default.history)

case("ROB-013", "If the panel is killed outright, its audio guard still gets its turn")
marker = os.path.join(tempfile.mkdtemp(), "guard-ran")
guard_code = ("import sys\nmode = 'keep'\nfor line in sys.stdin:\n    mode = line.strip() or mode\nopen(%r, 'w').write(mode)\n" % marker)
panel_code = ("import sys, time; sys.path.insert(0, %r); import virtualsafeaudiomidi_gui as g; "
              "guard = g.AudioGuard(command=[sys.executable, '-c', %r]); guard.set_mode('keep'); guard.set_mode('follow'); "
              "print('ready', flush=True); time.sleep(60)") % (os.path.dirname(os.path.abspath(__file__)), guard_code)
panel = subprocess.Popen([sys.executable, "-c", panel_code], stdout=subprocess.PIPE, universal_newlines=True)
panel.stdout.readline()
check(not os.path.exists(marker), "guard acted while the panel was still alive")
panel.kill()                                                           # no chance to clean up
panel.wait()
deadline = time.time() + 5
while time.time() < deadline and not os.path.exists(marker):
    time.sleep(0.05)
time.sleep(0.1)
check(os.path.exists(marker) and open(marker).read() == "follow", "guard did not run, or acted on the wrong instruction")

# ---------------------------------------------------------------- MIDI: the panel with the real helper
#
# The helper (midi/vsamidi.c) is built here against the pretend CoreMIDI in midi/test, so the
# whole chain panel -> text protocol -> helper runs for real; only macOS itself is stood in for.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MIDI_CASES = [
    ("MID-012", "Switching MIDI on starts the helper and creates the saved ports"),
    ("MID-013", "A changed port list reaches the running helper without restarting it"),
    ("MID-014", "MIDI passing through a port is reported to the panel as traffic"),
    ("MID-015", "Switching MIDI off stops the helper"),
    ("MID-016", "The MIDI on/off choice and the port list are remembered when the panel restarts"),
    ("MID-017", "Invalid MIDI port lists are rejected (wrong type, duplicate ID, duplicate name, 17 ports)"),
    ("MID-018", "If the helper cannot start, the panel says why, MIDI stays off and audio carries on"),
    ("MID-019", "MIDI works with no audio driver present"),
    ("MID-020", "If the helper dies, the panel reports it instead of pretending the ports exist"),
    ("ROB-012", "If the panel is killed outright, the MIDI helper exits by itself and leaves no orphan"),
]
skipped = []
helper = os.path.join(tempfile.mkdtemp(), "vsamidi-mock")
cc = shutil.which("gcc") or shutil.which("cc") or shutil.which("clang")
built = cc and subprocess.run(
    [cc, "-std=c11", "-D_GNU_SOURCE", "-DVSA_TEST", "-Istubs", "-I../../driver/test/stubs", "../vsamidi.c", "mock_coremidi.c", "-o", helper],
    cwd=os.path.join(ROOT, "midi", "test"), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0

if not built:
    skipped = [(i, t, "the helper could not be compiled against the stand-in headers on this machine") for i, t in MIDI_CASES]
else:
    titles = dict(MIDI_CASES)
    mcase = lambda test_id: case(test_id, titles[test_id])
    tmp_midi = tempfile.mkdtemp()
    midi = lg.MidiHelper(command=[helper])
    app = lg.App(lg.MockBackend(), tmp_midi, "mock", midi=midi)
    server = lg.make_server("127.0.0.1", 0, app)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = "http://127.0.0.1:%d" % server.server_address[1]

    mcase("MID-017")
    raises(lambda: lg.sanitize_ports("nope"), "non-list")
    raises(lambda: lg.sanitize_ports([{"uid": "a", "name": "x"}, {"uid": "a", "name": "y"}]), "duplicate id")
    raises(lambda: lg.sanitize_ports([{"name": "Same"}, {"name": "Same"}]), "duplicate name")
    raises(lambda: lg.sanitize_ports([{"name": "p%d" % i} for i in range(17)]), "17 ports")
    clean = lg.sanitize_ports([{"name": ""}, {"uid": "bad uid", "name": " Tab\there "}])
    check(clean[0]["name"] == "VirtualSafeMIDI#1" and clean[1]["uid"].startswith("vsamidi-") and clean[1]["name"] == "Tab here", "cleaning %r" % (clean,))

    mcase("MID-012")
    status, st = call("/api/config", {"ports": [{"uid": "a", "name": "Synth bus"}, {"uid": "b", "name": "Drum bus"}]})
    check(status == 200 and not midi.running() and len(st["midi"]["ports"]) == 2, "ports saved while off; helper must not be running yet")
    status, st = call("/api/midi/active", {"active": True})
    check(status == 200 and st["midi"] == {"active": True, "error": None, "ports": [{"uid": "a", "name": "Synth bus"}, {"uid": "b", "name": "Drum bus"}]}, "state %r" % (st.get("midi"),))
    check(midi.running() and midi.live == ["a", "b"], "helper has %r" % (midi.live,))

    mcase("MID-013")
    pid = midi.proc.pid
    status, st = call("/api/config", {"ports": [{"uid": "a", "name": "Lead synth"}, {"uid": "c", "name": "Clock"}]})
    check(status == 200 and midi.live == ["a", "c"], "helper has %r" % (midi.live,))
    check(midi.running() and midi.proc.pid == pid, "helper was restarted")

    mcase("MID-014")
    midi.proc.stdin.write("!send\ta\t7\n")
    midi.proc.stdin.flush()
    deadline = time.time() + 3
    while time.time() < deadline and midi.activity().get("a") != 7:
        time.sleep(0.05)
    check(midi.activity() == {"a": 7, "c": 0}, "counters %r" % (midi.activity(),))
    with urllib.request.urlopen(base + "/api/meters", timeout=5) as r:
        seen = None
        for _ in range(40):
            line = r.readline().decode()
            if line.startswith("event: midi"):
                seen = json.loads(r.readline().decode()[6:])
                break
    check(seen == {"a": 7, "c": 0}, "stream carried %r" % (seen,))

    mcase("MID-016")
    second = lg.MidiHelper(command=[helper])
    restarted = lg.App(lg.MockBackend(), tmp_midi, "mock", midi=second)
    check(restarted.state()["midi"]["active"] and second.running() and second.live == ["a", "c"], "after restart: %r" % (second.live,))
    restarted.shutdown()

    mcase("MID-020")
    midi.proc.kill()
    midi.proc.wait()
    st = app.state()
    check(st["midi"]["error"] and "stopped" in st["midi"]["error"], "state %r" % (st["midi"],))

    mcase("MID-015")
    status, st = call("/api/midi/active", {"active": True})          # bring it back first
    proc = midi.proc
    check(status == 200 and midi.running() and st["midi"]["error"] is None, "could not switch on again")
    status, st = call("/api/midi/active", {"active": False})
    check(status == 200 and st["midi"]["active"] is False and proc.poll() is not None, "helper still running")
    check(len(st["midi"]["ports"]) == 2, "port list was lost when switching off")
    server.shutdown()

    mcase("MID-018")
    broken = lg.App(lg.MockBackend(), tempfile.mkdtemp(), "mock", midi=lg.MidiHelper(command=["/nonexistent/vsamidi"]))
    try:
        broken.set_midi_active(True)
        check(False, "no error raised")
    except lg.MidiError as e:
        check("could not be started" in str(e), "message %r" % str(e))
    st = broken.state()
    check(st["midi"]["active"] is False and st["midi"]["error"] and st["connected"] and len(st["devices"]) == 2, "state %r" % (st["midi"],))

    mcase("MID-019")
    alone = lg.MidiHelper(command=[helper])
    no_audio = lg.App(Missing(), tempfile.mkdtemp(), "driver", midi=alone, driver_installed=lambda: False)
    no_audio.apply({"ports": [{"uid": "solo", "name": "Solo"}]})
    st = no_audio.set_midi_active(True)
    check(st["midi"]["active"] and alone.live == ["solo"] and not st["connected"] and st["audio"]["installed"] is False, "state %r" % (st,))
    no_audio.shutdown()

    mcase("ROB-012")
    script = ("import sys, time; sys.path.insert(0, %r); import virtualsafeaudiomidi_gui as g; "
              "h = g.MidiHelper(command=[%r]); h.start(); h.set_ports([{'uid': 'x', 'name': 'X'}]); "
              "print(h.proc.pid, flush=True); time.sleep(60)") % (os.path.dirname(os.path.abspath(__file__)), helper)
    panel = subprocess.Popen([sys.executable, "-c", script], stdout=subprocess.PIPE, universal_newlines=True)
    helper_pid = int(panel.stdout.readline())

    def exited(pid):        # gone, or a zombie that nobody has collected yet
        stat = subprocess.run(["ps", "-o", "stat=", "-p", str(pid)], stdout=subprocess.PIPE, universal_newlines=True).stdout.strip()
        return stat == "" or stat.startswith("Z")
    check(not exited(helper_pid), "helper was not running before the kill")
    panel.kill()                                                       # no chance to clean up
    panel.wait()
    deadline = time.time() + 3
    while time.time() < deadline and not exited(helper_pid):
        time.sleep(0.05)
    check(exited(helper_pid), "helper %d is still running 3 s after the panel was killed" % helper_pid)

failed = 0
for test_id, title, problems in results:
    if problems:
        failed += 1
        print("FAIL %s %s (%s)" % (test_id, title, "; ".join(problems)))
    else:
        print("PASS %s %s" % (test_id, title))
for test_id, title, why in skipped:
    print("SKIP %s %s (%s)" % (test_id, title, why))
print("control panel server: %d of %d cases passed%s" % (len(results) - failed, len(results), ", %d skipped" % len(skipped) if skipped else ""))
sys.exit(1 if failed else 0)
