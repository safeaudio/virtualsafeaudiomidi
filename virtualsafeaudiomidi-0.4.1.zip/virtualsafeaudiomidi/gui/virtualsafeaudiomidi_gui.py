#!/usr/bin/env python3
"""VirtualSafeAudioMIDI control panel — the web GUI for virtual audio devices and virtual MIDI ports.

    python3 gui/virtualsafeaudiomidi_gui.py            # then open http://127.0.0.1:8767
    python3 gui/virtualsafeaudiomidi_gui.py --mock     # nothing real needed: fake devices, ports and signal

Two independent halves, each switched on or off in the panel:

  Audio  lives in the driver (driver/virtualsafeaudio.c), which macOS loads by itself. This
         process only edits the driver's device list and relays its meters. By default the
         audio devices follow the app: they are taken away when the panel closes and put back
         when it starts. A setting in the panel keeps them instead.
  MIDI   lives in a small helper program (midi/vsamidi.c) that this process starts when MIDI
         is switched on. MIDI ports exist while the panel runs with MIDI on.

Standard library only; runs on the python3 that ships with the Xcode command line tools.
"""

import atexit
import argparse
import ctypes
import http.client
import json
import math
import os
import platform
import re
import shlex
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = "0.4.1"
BUNDLE_ID = "audio.virtualsafeaudio.driver"
MAX_DEVICES = 16
CHANNELS = 2                               # every audio device the app makes is stereo
AUDIO_NAME, AUDIO_UID = "VirtualSafeAudio#", "virtualsafeaudio-"      # VirtualSafeAudio#1, #2, ...
MIDI_NAME, MIDI_UID = "VirtualSafeMIDI#", "vsamidi-"
RATES = (44100, 48000, 88200, 96000, 176400, 192000)
DEFAULT_RATE = 48000
NAME_MAX_BYTES = 120                       # driver keeps names in a 128-byte buffer
UID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
HAL_DIR = "/Library/Audio/Plug-Ins/HAL"
HAL_BUNDLE = HAL_DIR + "/VirtualSafeAudio.driver"
MAX_PORTS = 16
DEFAULT_DEVICE = {"uid": AUDIO_UID + "1", "name": AUDIO_NAME + "1", "channels": CHANNELS, "sampleRate": DEFAULT_RATE}


class DriverError(Exception):
    pass


class MidiError(Exception):
    pass


# ------------------------------------------------------------------ wire formats

def parse_config(text):
    """'uid<TAB>channels<TAB>rate<TAB>name' per line -> list of device dicts."""
    devices = []
    for line in text.split("\n"):
        parts = line.split("\t", 3)
        if len(parts) != 4 or not parts[0]:
            continue
        try:
            devices.append({"uid": parts[0], "channels": int(parts[1]),
                            "sampleRate": int(float(parts[2])), "name": parts[3]})
        except ValueError:
            continue
    return devices


def format_config(devices):
    return "".join("%s\t%d\t%d\t%s\n" % (d["uid"], d["channels"], d["sampleRate"], d["name"]) for d in devices)


def parse_meters(text):
    """'uid<TAB>peak0,rms0,peak1,rms1,...' per line -> {uid: [floats]}."""
    out = {}
    for line in text.split("\n"):
        uid, sep, values = line.partition("\t")
        if not sep or not uid:
            continue
        try:
            out[uid] = [float(v) for v in values.split(",")] if values else []
        except ValueError:
            continue
    return out


def clean_name(name, fallback):
    name = re.sub(r"[\x00-\x1f\x7f]+", " ", str(name)).strip()
    while len(name.encode("utf-8")) > NAME_MAX_BYTES:
        name = name[:-1]
    return name or fallback


def _lowest_free(taken, prefix):
    """prefix + the smallest number 1, 2, 3, ... that is not in `taken` yet."""
    k = 1
    while prefix + str(k) in taken:
        k += 1
    return prefix + str(k)


def _sanitize(raw, what, limit, name_prefix, uid_prefix):
    """Shared checks for a list of audio devices or MIDI ports coming from the browser.

    Returns [(uid, name, original item)]. An item without a name is new: it gets the lowest free
    number (VirtualSafeAudio#1, #2, ...), so a removed number is reused by the next one added. An
    item without a usable id gets the lowest free id the same way, which makes "#2" the same device
    to other apps every time it is created. Raises ValueError with a message the GUI can show."""
    if not isinstance(raw, list):
        raise ValueError("Expected a list of %ss." % what)
    if len(raw) > limit:
        raise ValueError("At most %d %ss." % (limit, what))
    items = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError("%s %d is not an object." % (what.capitalize(), i + 1))
        uid = item.get("uid")
        if not (isinstance(uid, str) and UID_RE.match(uid) and len(uid) <= 60):
            uid = None
        items.append([uid, clean_name(item.get("name") or "", ""), item])
    names, uids = set(), set()
    for uid, name, _ in items:
        if name and name in names:
            raise ValueError("Two %ss are both called \"%s\". Apps could not tell them apart." % (what, name))
        if uid and uid in uids:
            raise ValueError("Two %ss share the id %s." % (what, uid))
        names.add(name)
        uids.add(uid)
    for entry in items:
        if not entry[1]:
            entry[1] = _lowest_free(names, name_prefix)
            names.add(entry[1])
        if not entry[0]:
            entry[0] = _lowest_free(uids, uid_prefix)
            uids.add(entry[0])
    return [tuple(entry) for entry in items]


def sanitize_devices(raw, current):
    """Validate an audio device list coming from the browser. Every device is stereo, whatever the
    browser sends. `current` is what the driver has now; a device that keeps its uid keeps its
    sample rate."""
    rates = {d["uid"]: d["sampleRate"] for d in current}
    out = []
    for uid, name, item in _sanitize(raw, "audio device", MAX_DEVICES, AUDIO_NAME, AUDIO_UID):
        rate = rates.get(uid, item.get("sampleRate"))
        out.append({"uid": uid, "name": name, "channels": CHANNELS, "sampleRate": rate if rate in RATES else DEFAULT_RATE})
    return out


def sanitize_ports(raw):
    """Validate a MIDI port list coming from the browser."""
    return [{"uid": uid, "name": name} for uid, name, _ in _sanitize(raw, "MIDI port", MAX_PORTS, MIDI_NAME, MIDI_UID)]


def normalize_devices(devices):
    """Bring devices found in the driver in line with what the app makes: stereo, numbered names.
    Only the app's own devices are touched (ids starting "virtualsafeaudio-"), so a device that some
    other tool put into the driver is left as it is. Returns (devices, changed)."""
    names = {d["name"] for d in devices}
    out, changed = [], False
    for d in devices:
        d = dict(d)
        if d["uid"].startswith(AUDIO_UID):
            if d["channels"] != CHANNELS:
                d["channels"], changed = CHANNELS, True
            if d["uid"] == AUDIO_UID + "main" and d["name"] == "VirtualSafeAudio":      # the driver's own first-run device
                names.discard(d["name"])
                d["name"] = _lowest_free(names, AUDIO_NAME)
                names.add(d["name"])
                changed = True
        out.append(d)
    return out, changed


def install_shell_command(staged_bundle, dest_dir=HAL_DIR, owner="root:wheel", restart=True):
    """The one command line that runs as administrator when the panel installs the audio driver.

    It reads only `staged_bundle` (a copy in the temporary folder) and writes only `dest_dir`.
    It must never touch the project folder: macOS does not let the administrator shell read
    Downloads, Desktop or Documents, and that is exactly where an unzipped download lives."""
    q = shlex.quote
    target = dest_dir + "/VirtualSafeAudio.driver"
    steps = ["mkdir -p " + q(dest_dir), "rm -rf " + q(target), "cp -R " + q(staged_bundle) + " " + q(dest_dir + "/")]
    if owner:
        steps.append("chown -R " + owner + " " + q(target))
    command = " && ".join(steps)
    if restart:
        command += " && (killall -9 coreaudiod || true)"      # Core Audio restarts by itself and loads the driver
    return command


def normalize_preset(value):
    """Presets hold audio devices and MIDI ports. Version 0.1 stored a bare list of audio devices."""
    if isinstance(value, list):
        return {"devices": value, "ports": []}
    if isinstance(value, dict):
        return {"devices": value.get("devices") or [], "ports": value.get("ports") or []}
    return {"devices": [], "ports": []}


# ------------------------------------------------------------------ backends

def _fourcc(s):
    return struct.unpack(">I", s.encode("ascii"))[0]


class _Address(ctypes.Structure):
    _fields_ = [("selector", ctypes.c_uint32), ("scope", ctypes.c_uint32), ("element", ctypes.c_uint32)]


class CoreAudioBackend:
    """Reads and writes the driver's two custom properties on its plug-in object."""

    SYSTEM_OBJECT = 1
    UTF8 = 0x08000100

    def __init__(self):
        self.ca = ctypes.CDLL("/System/Library/Frameworks/CoreAudio.framework/CoreAudio")
        self.cf = ctypes.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
        vp, u32 = ctypes.c_void_p, ctypes.c_uint32
        self.ca.AudioObjectGetPropertyData.argtypes = [u32, ctypes.POINTER(_Address), u32, vp, ctypes.POINTER(u32), vp]
        self.ca.AudioObjectGetPropertyData.restype = ctypes.c_int32
        self.ca.AudioObjectSetPropertyData.argtypes = [u32, ctypes.POINTER(_Address), u32, vp, u32, vp]
        self.ca.AudioObjectSetPropertyData.restype = ctypes.c_int32
        self.cf.CFStringCreateWithCString.argtypes = [vp, ctypes.c_char_p, u32]
        self.cf.CFStringCreateWithCString.restype = vp
        self.cf.CFStringGetLength.argtypes = [vp]
        self.cf.CFStringGetLength.restype = ctypes.c_long
        self.cf.CFStringGetMaximumSizeForEncoding.argtypes = [ctypes.c_long, u32]
        self.cf.CFStringGetMaximumSizeForEncoding.restype = ctypes.c_long
        self.cf.CFStringGetCString.argtypes = [vp, ctypes.c_char_p, ctypes.c_long, u32]
        self.cf.CFStringGetCString.restype = ctypes.c_ubyte
        self.cf.CFRelease.argtypes = [vp]
        self.cf.CFRelease.restype = None
        self._lock = threading.Lock()
        self._plugin = 0

    # -- CFString helpers
    def _cfstr(self, text):
        ref = self.cf.CFStringCreateWithCString(None, text.encode("utf-8"), self.UTF8)
        if not ref:
            raise DriverError("Could not build a CFString.")
        return ref

    def _pystr(self, ref):
        size = self.cf.CFStringGetMaximumSizeForEncoding(self.cf.CFStringGetLength(ref), self.UTF8) + 1
        buf = ctypes.create_string_buffer(size)
        if not self.cf.CFStringGetCString(ref, buf, size, self.UTF8):
            raise DriverError("Could not read a string from the driver.")
        return buf.value.decode("utf-8", "replace")

    # -- plug-in lookup
    def _find_plugin(self):
        addr = _Address(_fourcc("bidp"), _fourcc("glob"), 0)     # kAudioHardwarePropertyTranslateBundleIDToPlugIn
        bundle = self._cfstr(BUNDLE_ID)
        try:
            qualifier = ctypes.c_void_p(bundle)
            plugin = ctypes.c_uint32(0)
            size = ctypes.c_uint32(ctypes.sizeof(plugin))
            err = self.ca.AudioObjectGetPropertyData(self.SYSTEM_OBJECT, ctypes.byref(addr),
                                                     ctypes.sizeof(qualifier), ctypes.byref(qualifier),
                                                     ctypes.byref(size), ctypes.byref(plugin))
        finally:
            self.cf.CFRelease(bundle)
        if err != 0 or plugin.value == 0:
            raise DriverError("The VirtualSafeAudio driver is not loaded. Run ./install.sh, then reload this page.")
        return plugin.value

    def _with_plugin(self, fn):
        # The plug-in's object ID changes whenever coreaudiod restarts, so retry once with a fresh lookup.
        with self._lock:
            for attempt in (0, 1):
                if not self._plugin:
                    self._plugin = self._find_plugin()
                err, value = fn(self._plugin)
                if err == 0:
                    return value
                self._plugin = 0
            raise DriverError("Core Audio refused the request (error %d)." % err)

    def _get_string(self, selector):
        def call(plugin):
            addr = _Address(_fourcc(selector), _fourcc("glob"), 0)
            ref = ctypes.c_void_p(0)
            size = ctypes.c_uint32(ctypes.sizeof(ref))
            err = self.ca.AudioObjectGetPropertyData(plugin, ctypes.byref(addr), 0, None, ctypes.byref(size), ctypes.byref(ref))
            if err != 0 or not ref.value:
                return (err or -1), None
            try:
                return 0, self._pystr(ref.value)
            finally:
                self.cf.CFRelease(ref.value)
        return self._with_plugin(call)

    def get_config(self):
        return self._get_string("vscf")

    def get_meters(self):
        return self._get_string("vsmt")

    def set_config(self, text):
        def call(plugin):
            addr = _Address(_fourcc("vscf"), _fourcc("glob"), 0)
            ref = ctypes.c_void_p(self._cfstr(text))
            try:
                return self.ca.AudioObjectSetPropertyData(plugin, ctypes.byref(addr), 0, None, ctypes.sizeof(ref), ctypes.byref(ref)), None
            finally:
                self.cf.CFRelease(ref.value)
        self._with_plugin(call)


class MockBackend:
    """Stands in for the driver so the GUI can be previewed and tested anywhere. Like the real
    driver it keeps devices in slots: a device that stays keeps its place, and a new one takes
    the first free slot, which is what puts a re-added #2 back between #1 and #3."""

    def __init__(self):
        self._slots = []
        self.history = []                      # every list set_config was given, oldest first
        self.config = AUDIO_UID + "1\t2\t48000\t" + AUDIO_NAME + "1\n" + AUDIO_UID + "2\t2\t48000\t" + AUDIO_NAME + "2\n"

    @property
    def config(self):
        return "".join(line + "\n" for line in self._slots if line)

    @config.setter
    def config(self, text):                    # tests put a list straight into the "driver"
        self._slots = [line for line in text.split("\n") if line]

    def get_config(self):
        return self.config

    def set_config(self, text):
        self.history.append(text)
        wanted = {line.split("\t", 1)[0]: line for line in text.split("\n") if line}
        slots = [wanted.pop(line.split("\t", 1)[0], None) if line else None for line in self._slots]
        for line in wanted.values():
            if None in slots:
                slots[slots.index(None)] = line
            else:
                slots.append(line)
        self._slots = slots

    def get_meters(self):
        t = time.time()
        lines = []
        for d in parse_config(self.config):
            values = []
            for c in range(d["channels"]):
                beat = max(0.0, math.sin(t * (2.1 + 0.37 * (c % 5)) + c)) ** 3
                rms = 0.02 + 0.45 * beat * (0.6 + 0.4 * math.sin(t * 0.31 + c * 1.7))
                values += ["%.4f" % min(1.0, rms * 1.9), "%.4f" % rms]
            lines.append(d["uid"] + "\t" + ",".join(values))
        return "\n".join(lines) + "\n"


# ------------------------------------------------------------------ audio follows the app

def run_audio_guard(backend, stream):
    """The whole job of the audio guard, a tiny child process of the panel.

    The panel keeps a pipe open to it and writes "follow" or "keep" whenever the choice changes.
    When the pipe closes, the panel is gone, however it went: window closed, Ctrl+C, crash,
    force-quit. If the last word was "follow", the guard tells the driver to publish no devices.
    The panel saved the layout beforehand and gives it back to the driver at the next start."""
    mode = "keep"                          # with no instruction at all, leave everything alone
    for line in stream:
        word = line.strip()
        if word in ("follow", "keep"):
            mode = word
    if mode == "follow":
        try:
            backend.set_config("")
        except Exception:                  # nothing useful can be done about it from here
            pass


class AudioGuard:
    """The panel's handle on its guard process (see run_audio_guard)."""

    def __init__(self, command=None):
        self.command = command or [sys.executable, os.path.abspath(__file__), "--audio-guard"]
        self.proc = None

    def set_mode(self, mode):
        if self.proc is None or self.proc.poll() is not None:
            try:
                # Its own session: closing the Terminal window hangs up the panel, and the guard
                # has to outlive exactly that moment.
                self.proc = subprocess.Popen(self.command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                             stderr=subprocess.DEVNULL, universal_newlines=True, start_new_session=True)
            except OSError:
                self.proc = None
                return
        try:
            self.proc.stdin.write(mode + "\n")
            self.proc.stdin.flush()
        except (OSError, ValueError):
            pass

    def release(self):
        """The panel is exiting in an orderly way. Closing the pipe is what lets the guard act."""
        if self.proc:
            try:
                self.proc.stdin.close()
            except OSError:
                pass
            try:
                self.proc.wait(5)
            except subprocess.TimeoutExpired:
                pass


# ------------------------------------------------------------------ MIDI

class MidiHelper:
    """Runs the native helper that owns the virtual MIDI ports (midi/vsamidi.c) and talks to it
    in plain text over its standard input and output. The protocol is described at the top of
    that file. Stopping the helper removes the ports."""

    def __init__(self, command=None):
        self.command = command          # tests pass a helper built against a pretend CoreMIDI
        self.proc = None
        self.counts = {}                # uid -> MIDI packets forwarded so far
        self.live = []                  # uids the helper says exist
        self.warnings = []
        self._confirmed = threading.Event()
        self._lock = threading.Lock()

    def _command(self):
        if self.command:
            return self.command
        binary = os.path.join(ROOT, "build", "vsamidi")
        source = os.path.join(ROOT, "midi", "vsamidi.c")
        if not os.path.exists(binary) or os.path.getmtime(binary) < os.path.getmtime(source):
            try:
                p = subprocess.run([os.path.join(ROOT, "build.sh"), "midi"], stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, universal_newlines=True, timeout=180)
                failed, detail = p.returncode != 0, (p.stdout.strip().splitlines() or [""])[-1]
            except (OSError, subprocess.TimeoutExpired) as e:
                failed, detail = True, str(e)
            if failed:
                raise MidiError("The MIDI helper could not be built. It needs Apple's command line tools "
                                "(xcode-select --install). " + detail[:200])
        return [binary]

    def running(self):
        return self.proc is not None and self.proc.poll() is None

    def start(self):
        if self.running():
            return
        try:
            self.proc = subprocess.Popen(self._command(), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.DEVNULL, universal_newlines=True, bufsize=1)
        except OSError as e:
            self.proc = None
            raise MidiError("The MIDI helper could not be started: %s" % e)
        first = self.proc.stdout.readline().strip()          # the helper says READY or ERROR straight away
        if first != "READY":
            self.stop()
            raise MidiError(first.partition("\t")[2] or "The MIDI helper did not start.")
        self.counts, self.live, self.warnings = {}, [], []
        threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()

    def _read(self, proc):
        for line in proc.stdout:
            parts = line.rstrip("\n").split("\t")
            if parts[0] == "OK":
                self.live = [u for u in parts[1:] if u]
                self._confirmed.set()
            elif parts[0] == "A":
                counts = {}
                for item in parts[1:]:
                    uid, _, n = item.rpartition("=")
                    if uid and n.isdigit():
                        counts[uid] = int(n)
                self.counts = counts
            elif parts[0] == "WARN":
                self.warnings.append("\t".join(parts[1:]))

    def set_ports(self, ports):
        if not self.running():
            raise MidiError("The MIDI helper is not running.")
        with self._lock:
            self._confirmed.clear()
            self.warnings = []
            try:
                self.proc.stdin.write("".join("%s\t%s\n" % (p["uid"], p["name"]) for p in ports) + ".\n")
                self.proc.stdin.flush()
            except (OSError, ValueError):
                raise MidiError("The MIDI helper stopped unexpectedly.")
            if not self._confirmed.wait(5):
                raise MidiError("The MIDI helper did not confirm the change.")
            missing = [p["name"] for p in ports if p["uid"] not in self.live]
            if missing:
                raise MidiError("macOS refused to create: %s. %s" % (", ".join(missing), " ".join(self.warnings)))

    def stop(self):
        proc, self.proc = self.proc, None
        if proc:
            try:
                proc.stdin.close()                      # the helper exits when its input closes
            except OSError:
                pass
            try:
                proc.wait(3)
            except subprocess.TimeoutExpired:
                proc.kill()
        self.counts, self.live = {}, []

    def activity(self):
        return dict(self.counts)


class MockMidi:
    """Stands in for the helper in --mock mode: no real ports, made-up traffic."""

    def __init__(self):
        self._on = False
        self.ports = []
        self._t0 = time.time()

    def running(self):
        return self._on

    def start(self):
        self._on = True

    def stop(self):
        self._on, self.ports = False, []

    def set_ports(self, ports):
        self.ports = list(ports)

    def activity(self):
        t = time.time() - self._t0
        return {p["uid"]: (0 if i % 3 == 2 else int(t * (4 + 9 * i))) for i, p in enumerate(self.ports)}


# ------------------------------------------------------------------ application

def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else default
    except (OSError, ValueError):
        return default


def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(path + ".tmp", path)


class App:
    def __init__(self, backend, data_dir, mode, midi=None, driver_installed=None, guard=None, keep_audio=False):
        self.backend = backend
        self.mode = mode
        self.midi = midi if midi is not None else (MockMidi() if mode == "mock" else MidiHelper())
        self.driver_installed = driver_installed or ((lambda: True) if mode == "mock" else (lambda: os.path.isdir(HAL_BUNDLE)))
        self.presets_path = os.path.join(data_dir, "presets.json")
        self.settings_path = os.path.join(data_dir, "settings.json")
        self._lock = threading.RLock()
        self._meter_cache = (0.0, b"{}", True)
        # keep_audio: this run must leave the audio devices alone when it exits, whatever the
        # setting says (the test runner starts short-lived panels next to the real one).
        self.force_keep = keep_audio
        self.guard = guard if guard is not None else (AudioGuard() if mode == "driver" and not keep_audio else None)
        self.republish_pause = 0.5 if mode == "driver" else 0.0      # see _write_devices

        # What is switched on, and what to bring back when something is switched on again.
        stored = _read_json(self.settings_path, {})
        audio, midi_s = stored.get("audio") or {}, stored.get("midi") or {}
        self.settings = {
            "audio": {"active": bool(audio.get("active", True)), "saved": audio.get("saved") or [],
                      "keep": bool(audio.get("keep", False))},
            "midi": {"active": bool(midi_s.get("active", False)), "ports": midi_s.get("ports") or []},
        }
        self.midi_error = None
        if self.settings["midi"]["active"]:
            self._start_midi()
        self._sync_guard()

    def _save_settings(self):
        _write_json(self.settings_path, self.settings)

    def _follows_app(self):
        """True when the audio devices should exist only while the panel runs."""
        audio = self.settings["audio"]
        return audio["active"] and not audio["keep"] and not self.force_keep

    def _sync_guard(self):
        if self.guard:
            self.guard.set_mode("follow" if self._follows_app() else "keep")

    def _devices(self):
        return parse_config(self.backend.get_config())

    def _write_devices(self, devices, current):
        """Hand a device list to the driver so that macOS really shows it.

        The driver can change a device's name in place, without interrupting it, and tells macOS.
        But the macOS sound menu and many apps read a device's name only when the device appears,
        so an in-place rename stays invisible there. A renamed device is therefore taken out and,
        a moment later, put back under the same identity: to macOS it is a device that was
        unplugged and plugged in again, and it comes back with its new name. Only the renamed
        device is interrupted; adding and removing other devices needs no such step."""
        old = {d["uid"]: d["name"] for d in current}
        renamed = {d["uid"] for d in devices if d["uid"] in old and old[d["uid"]] != d["name"]}
        if renamed:
            self.backend.set_config(format_config([d for d in devices if d["uid"] not in renamed]))
            time.sleep(self.republish_pause)       # let macOS notice that it has gone
        self.backend.set_config(format_config(devices))

    def _start_midi(self):
        try:
            self.midi.start()
            self.midi.set_ports(self.settings["midi"]["ports"])
            self.midi_error = None
        except MidiError as e:
            self.midi_error = str(e)
            self.midi.stop()

    def state(self):
        try:
            devices, error = self._devices(), None
        except DriverError as e:
            devices, error = [], str(e)
        audio, midi = self.settings["audio"], self.settings["midi"]
        if error is None:
            with self._lock:
                if self._follows_app() and not devices and audio["saved"]:
                    # Audio follows the app and the driver has nothing, although there is a layout
                    # to show: the list was emptied when a panel last closed (normally the previous
                    # run; possibly an older copy that was replaced a moment ago). Put it back.
                    try:
                        self.backend.set_config(format_config(audio["saved"]))
                        devices = self._devices()
                    except DriverError:
                        pass
                tidy, changed = normalize_devices(devices)
                if changed:
                    try:
                        self._write_devices(tidy, devices)
                        devices = self._devices()
                    except DriverError:
                        pass
                if devices and not audio["active"]:
                    audio["active"] = True               # the driver has devices, so audio is on, whatever we remembered
                    self._save_settings()
                    self._sync_guard()
                if audio["active"] and devices and devices != audio["saved"]:
                    # Always know what to bring back next time. An empty list seen here is never
                    # taken as the layout: only an empty list the user applied counts (see apply).
                    audio["saved"] = devices
                    self._save_settings()
        if midi["active"] and self.midi_error is None and not self.midi.running():
            self.midi_error = "The MIDI helper stopped unexpectedly. Switch MIDI off and on again."
        return {"version": VERSION, "root": ROOT, "pid": os.getpid(),
                "mode": self.mode, "connected": error is None, "error": error, "devices": devices,
                "audio": {"active": audio["active"], "installed": bool(self.driver_installed()), "saved": len(audio["saved"]),
                          "keep": bool(audio["keep"] or self.force_keep)},
                "midi": {"active": midi["active"], "error": self.midi_error, "ports": midi["ports"]},
                "presets": {name: normalize_preset(v) for name, v in _read_json(self.presets_path, {}).items()},
                "limits": {"maxDevices": MAX_DEVICES, "maxPorts": MAX_PORTS}}

    def apply(self, body):
        """Apply edited audio devices and/or MIDI ports. Both lists are validated before either is touched."""
        with self._lock:
            devices = ports = current = None
            if body.get("devices") is not None:
                if not self.settings["audio"]["active"]:
                    raise ValueError("Audio is switched off. Switch it on to change audio devices.")
                current = self._devices()
                devices = sanitize_devices(body["devices"], current)
            if body.get("ports") is not None:
                ports = sanitize_ports(body["ports"])
            if devices is not None:
                self._write_devices(devices, current)
                self.settings["audio"]["saved"] = devices
                self._save_settings()
            if ports is not None:
                self.settings["midi"]["ports"] = ports
                self._save_settings()
                if self.settings["midi"]["active"]:
                    self.midi.set_ports(ports)
        return self.state()

    def set_midi_active(self, active):
        with self._lock:
            if active:
                self.settings["midi"]["active"] = True
                self._start_midi()
                if self.midi_error:
                    self.settings["midi"]["active"] = False
                    self._save_settings()
                    raise MidiError(self.midi_error)
            else:
                self.midi.stop()
                self.settings["midi"]["active"] = False
                self.midi_error = None
            self._save_settings()
        return self.state()

    def set_audio_active(self, active):
        """Off: remember the device layout and tell the driver to publish nothing.
        On: give the driver the remembered layout back (or one stereo device if there is none)."""
        with self._lock:
            audio = self.settings["audio"]
            if active != audio["active"]:
                if active:
                    self.backend.set_config(format_config(audio["saved"] or [DEFAULT_DEVICE]))
                else:
                    audio["saved"] = self._devices()
                    self.backend.set_config("")
                audio["active"] = active
                self._save_settings()
                self._sync_guard()
        return self.state()

    def set_audio_keep(self, keep):
        """Keep: the audio devices stay in macOS when the panel is closed (and after a reboot).
        Not keep (the default): they follow the app."""
        with self._lock:
            self.settings["audio"]["keep"] = bool(keep)
            self._save_settings()
            self._sync_guard()
        return self.state()

    def install_driver(self):
        """The panel's install button. Builds the driver as the current user, then asks macOS for an
        administrator password (the standard system dialog) to copy it into place and restart Core Audio."""
        if self.mode == "mock":
            return self.state()
        if platform.system() != "Darwin":
            raise ValueError("The audio driver can only be installed on macOS.")
        build = subprocess.run([os.path.join(ROOT, "build.sh"), "driver"], stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, universal_newlines=True)
        if build.returncode != 0:
            raise ValueError("The driver could not be built. It needs Apple's command line tools (xcode-select --install). "
                             + (build.stdout.strip().splitlines() or [""])[-1][:200])
        # Stage a copy of the built driver outside the project folder, then run the privileged
        # part against that copy only (see install_shell_command for why).
        staging = tempfile.mkdtemp(prefix="vsa-install-")
        try:
            staged = os.path.join(staging, "VirtualSafeAudio.driver")
            shutil.copytree(os.path.join(ROOT, "build", "VirtualSafeAudio.driver"), staged, symlinks=True)
            os.chmod(staging, 0o755)
            admin = subprocess.run(
                ["osascript", "-e", "on run argv",
                 "-e", "do shell script (item 1 of argv) with administrator privileges",
                 "-e", "end run", install_shell_command(staged)],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, timeout=300)
        except subprocess.TimeoutExpired:
            raise ValueError("The install timed out waiting for the password dialog.")
        except OSError as e:
            raise ValueError("The built driver could not be prepared for install: %s" % e)
        finally:
            shutil.rmtree(staging, ignore_errors=True)
        if admin.returncode != 0:
            detail = (admin.stdout.strip().splitlines() or [""])[-1][:200]
            if "User canceled" in detail or "(-128)" in detail:
                raise ValueError("The install was cancelled. Nothing was changed.")
            raise ValueError("The install did not finish. " + detail)
        for _ in range(30):                                  # Core Audio needs a moment to come back and load the driver
            try:
                self.backend.get_config()
                break
            except DriverError:
                time.sleep(0.5)
        with self._lock:
            self.settings["audio"]["active"] = True
            self._save_settings()
            self._sync_guard()
        return self.state()

    def save_preset(self, name, body):
        name = clean_name(name, "")
        if not name:
            raise ValueError("Give the preset a name.")
        with self._lock:
            presets = _read_json(self.presets_path, {})
            presets[name] = {"devices": sanitize_devices(body.get("devices") or [], []),
                             "ports": sanitize_ports(body.get("ports") or [])}
            _write_json(self.presets_path, presets)
        return self.state()

    def delete_preset(self, name):
        with self._lock:
            presets = _read_json(self.presets_path, {})
            presets.pop(name, None)
            _write_json(self.presets_path, presets)
        return self.state()

    def meters_json(self):
        """Latest audio meters as JSON bytes. Shared between browser tabs; refreshed at most every
        25 ms while the driver answers, and only once a second while it does not."""
        now = time.monotonic()
        stamp, payload, ok = self._meter_cache
        if now - stamp < (0.025 if ok else 1.0):
            return payload, ok
        try:
            payload, ok = json.dumps(parse_meters(self.backend.get_meters()), separators=(",", ":")).encode(), True
        except DriverError:
            payload, ok = b"{}", False
        self._meter_cache = (now, payload, ok)
        return payload, ok

    def midi_json(self):
        """MIDI packet counters per port as JSON bytes, or None while MIDI is off."""
        if not self.settings["midi"]["active"]:
            return None
        return json.dumps(self.midi.activity(), separators=(",", ":")).encode()

    def shutdown(self):
        self.midi.stop()
        if self.guard:
            self.guard.release()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    app = None

    def log_message(self, fmt, *args):
        pass

    def _send(self, status, body, content_type="application/json"):
        if not isinstance(body, bytes):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            with open(os.path.join(HERE, "index.html"), "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        elif path == "/api/state":
            self._send(200, self.app.state())
        elif path == "/api/meters":
            self._stream()
        else:
            self._send(404, {"error": "Not found."})

    def do_POST(self):
        # Requiring a JSON content type means another website cannot fire this at us with a plain form post.
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            return self._send(415, {"error": "Send JSON."})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(length).decode("utf-8")) if 0 < length <= 1 << 20 else None
            if not isinstance(body, dict):
                raise ValueError("Expected a JSON object.")
            path = self.path.split("?", 1)[0]
            if path == "/api/config":
                result = self.app.apply(body)
            elif path == "/api/presets":
                result = self.app.save_preset(body.get("name", ""), body)
            elif path == "/api/presets/delete":
                result = self.app.delete_preset(str(body.get("name", "")))
            elif path == "/api/audio/active":
                result = self.app.set_audio_active(bool(body.get("active")))
            elif path == "/api/audio/keep":
                result = self.app.set_audio_keep(bool(body.get("keep")))
            elif path == "/api/midi/active":
                result = self.app.set_midi_active(bool(body.get("active")))
            elif path == "/api/audio/install":
                result = self.app.install_driver()
            else:
                return self._send(404, {"error": "Not found."})
            self._send(200, result)
        except ValueError as e:
            self._send(400, {"error": str(e)})
        except (DriverError, MidiError) as e:
            self._send(503, {"error": str(e)})

    def _stream(self):
        """Server-sent events: audio meters about 30 times a second as plain messages, MIDI packet
        counters about 10 times a second as events named "midi"."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        tick = 0
        try:
            while True:
                payload, _ = self.app.meters_json()
                out = b"data: " + payload + b"\n\n"
                if tick % 3 == 0:
                    midi = self.app.midi_json()
                    if midi is not None:
                        out += b"event: midi\ndata: " + midi + b"\n\n"
                tick += 1
                self.wfile.write(out)
                self.wfile.flush()
                time.sleep(1 / 30)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass


def make_server(host, port, app):
    handler = type("BoundHandler", (Handler,), {"app": app})
    server = ThreadingHTTPServer((host, port), handler)
    server.daemon_threads = True
    return server


def check_running(port):
    """What is answering on the panel's port? Used by the launcher before it starts anything.
         none                         nothing; free to start
         same                         this very copy of the panel, same version, same folder
         other <version> <folder> <pid>   a different copy or version of the panel
         foreign                      some other program"""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/api/state" % port, timeout=2) as r:
            state = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError:
        return "foreign"                     # something answered, but not with our page
    except ValueError:
        return "foreign"
    except (OSError, http.client.HTTPException):
        return "none"                        # nothing there, or a panel caught in the act of closing
    if not (isinstance(state, dict) and "mode" in state and "limits" in state):
        return "foreign"
    version, root = str(state.get("version", "0.2.1 or older")), str(state.get("root", "an unknown folder"))
    if version == VERSION and root == ROOT:
        return "same"
    return "other\t%s\t%s\t%s" % (version, root, state.get("pid", ""))


def main():
    ap = argparse.ArgumentParser(description="Web control panel for VirtualSafeAudioMIDI.")
    ap.add_argument("--version", action="version", version=VERSION)
    ap.add_argument("--check-running", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--audio-guard", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--keep-audio", action="store_true",
                    help="Leave the audio devices alone when this panel exits, whatever the setting in the panel says.")
    ap.add_argument("--port", type=int, default=8767)
    ap.add_argument("--host", default="127.0.0.1",
                    help="Use 0.0.0.0 to reach the panel from other machines on your network (there is no password).")
    ap.add_argument("--mock", action="store_true", help="Run with nothing real: fake devices, fake ports, fake signal.")
    ap.add_argument("--open", action="store_true", help="Open the panel in the default browser.")
    ap.add_argument("--data-dir", default=os.path.expanduser("~/Library/Application Support/VirtualSafeAudioMIDI"))
    args = ap.parse_args()
    if args.check_running:
        print(check_running(args.port))
        return
    if args.audio_guard:
        class Driver:                                        # reached for only when it is needed
            def set_config(self, text):
                CoreAudioBackend().set_config(text)
        run_audio_guard(Driver(), sys.stdin)
        return

    backend, mode = (MockBackend(), "mock") if args.mock else (CoreAudioBackend(), "driver")
    url = "http://%s:%d" % ("127.0.0.1" if args.host in ("0.0.0.0", "") else args.host, args.port)
    # Claim the port before anything else: a second copy must stop here, before it could start
    # a second MIDI helper with the same ports.
    try:
        server = make_server(args.host, args.port, None)
    except OSError as e:
        print("Cannot start on port %d: %s." % (args.port, e.strerror or e))
        print("If the panel is already running, open %s. Otherwise choose another port with --port." % url)
        sys.exit(2)
    app = App(backend, args.data_dir, mode, keep_audio=args.keep_audio)
    server.RequestHandlerClass.app = app
    atexit.register(app.shutdown)
    print("VirtualSafeAudioMIDI %s control panel (%s) at %s — Ctrl+C to stop" % (VERSION, mode, url))
    if args.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print()


if __name__ == "__main__":
    main()
