#!/usr/bin/env python3
"""Control panel interface tests in a real (headless) browser, against the mock driver.
There is no Apply step in the panel: every test acts and then asks the server what exists.
Each case is one STP test. Needs Playwright:  pip install playwright && playwright install chromium

    python3 gui/test_browser.py
"""
import json
import os
import sys
import tempfile
import threading
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import virtualsafeaudiomidi_gui as lg
from playwright.sync_api import sync_playwright

results = []


def start(backend, mode, **options):
    server = lg.make_server("127.0.0.1", 0, lg.App(backend, tempfile.mkdtemp(), mode, **options))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return "http://127.0.0.1:%d" % server.server_address[1]


def server_state(base):
    with urllib.request.urlopen(base + "/api/state", timeout=5) as r:
        return json.loads(r.read())


def server_devices(base):
    return server_state(base)["devices"]


def case(test_id, title, fn):
    problems = []

    def check(cond, what):
        if not cond:
            problems.append(what)
    try:
        fn(check)
    except Exception as e:                      # a crash inside one case fails that case only
        problems.append("%s: %s" % (type(e).__name__, str(e).split("\n")[0]))
    results.append((test_id, title, problems))


class Missing:
    def get_config(self):
        raise lg.DriverError("The VirtualSafeAudio driver is not loaded. Run ./install.sh, then reload this page.")
    get_meters = set_config = lambda self, *a: Missing.get_config(self)


AMBER_PIXELS = """(i) => { const c = document.querySelectorAll('.unit canvas')[i]; const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
  let n = 0; for (let k = 0; k < d.length; k += 4) if (d[k] > 240 && d[k+1] > 150 && d[k+1] < 190 && d[k+2] < 60) n++; return n; }"""

base = start(lg.MockBackend(), "mock")          # starts with VirtualSafeAudio#1 and VirtualSafeAudio#2
missing = start(Missing(), "driver", driver_installed=lambda: False, midi=lg.MockMidi())
A = "VirtualSafeAudio#"
M = "VirtualSafeMIDI#"

with sync_playwright() as p:
    browser = p.chromium.launch()
    pg = browser.new_page(viewport={"width": 1180, "height": 900})
    errors = []
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    note = lambda: pg.inner_text("#note")
    units = lambda: pg.locator(".unit").count()
    ports = lambda: pg.locator(".port").count()
    device_names = lambda: [d["name"] for d in server_devices(base)]
    port_names = lambda: [x["name"] for x in server_state(base)["midi"]["ports"]]
    settle = lambda ms=500: pg.wait_for_timeout(ms)

    def t(check):
        pg.goto(base)
        pg.wait_for_selector(".unit")
        check(units() == 2, "expected 2 device rows, found %d" % units())
        check([pg.input_value("#name0"), pg.input_value("#name1")] == [A + "1", A + "2"], "names shown: %r" % [pg.input_value("#name0"), pg.input_value("#name1")])
        check("Demo mode" in pg.inner_text("#statusText"), "status text: " + pg.inner_text("#statusText"))
        check("Version " + lg.VERSION in pg.inner_text("#serverNote"), "version not shown: " + pg.inner_text("#serverNote"))
        check(not errors, "script errors: %r" % errors)
    case("UI-001", "Panel loads with no script errors, shows its version and one row per device", t)

    def t(check):
        settle(800)
        check(pg.evaluate(AMBER_PIXELS, 0) > 50, "no lit segments on the first device's meter")
        check(all("Stereo" in x for x in pg.locator(".unit .rate").all_inner_texts()), "a device is not shown as stereo")
    case("UI-002", "Every device shows a stereo (left/right) meter with lit segments when it has signal", t)

    def t(check):
        check(pg.locator("#apply").count() == 0 and pg.locator("#discard").count() == 0, "an Apply or Discard control still exists")
        pg.click("#add"); settle()
        devices = server_devices(base)
        check([d["name"] for d in devices] == [A + "1", A + "2", A + "3"], "driver has %r" % [d["name"] for d in devices])
        check(devices[-1]["channels"] == 2 and devices[-1]["uid"] == "virtualsafeaudio-3", "new device: %r" % (devices[-1],))
        check(units() == 3 and note() == "Added %s3." % A, "rows: %d, note: %s" % (units(), note()))
    case("UI-034", "Adding a device creates it in the driver at once, stereo, with no Apply step", t)

    def t(check):
        pg.locator(".unit .remove").nth(1).click(); settle()
        check(device_names() == [A + "1", A + "3"], "driver has %r" % device_names())
        check(units() == 2 and note() == "Removed %s2." % A, "rows: %d, note: %s" % (units(), note()))
    case("UI-010", "Removing a device takes it out of the driver at once", t)

    def t(check):
        pg.click("#deviceMore"); settle()
        devices = server_devices(base)
        check([d["name"] for d in devices] == [A + "1", A + "2", A + "3"], "driver has %r" % [d["name"] for d in devices])
        check(devices[1]["uid"] == "virtualsafeaudio-2", "re-added #2 has id %r" % devices[1]["uid"])
    case("UI-033", "Devices are named VirtualSafeAudio#1, #2, ...; a removed number is reused, with the same identity", t)

    def t(check):
        check(pg.input_value("#deviceCount") == "3", "count shows %s with 3 devices" % pg.input_value("#deviceCount"))
        pg.fill("#deviceCount", "5"); pg.press("#deviceCount", "Tab"); settle()
        check(device_names() == [A + str(n) for n in range(1, 6)] and units() == 5, "after typing 5: %r" % device_names())
        pg.click("#deviceFewer"); pg.click("#deviceFewer"); settle(700)
        check(device_names() == [A + "1", A + "2", A + "3"] and pg.input_value("#deviceCount") == "3", "after two steps down: %r" % device_names())
        pg.fill("#deviceCount", "0"); pg.press("#deviceCount", "Tab"); settle()
        check(device_names() == [] and units() == 0, "after typing 0 the driver still has %r" % device_names())
        check(note() == "Now 0 audio devices in macOS." and "No virtual audio devices" in pg.inner_text("#units"), "note: " + note())
        pg.click("#deviceMore"); pg.click("#deviceMore"); settle(700)
        check(device_names() == [A + "1", A + "2"], "after + + from zero: %r" % device_names())
    case("UI-030", "Setting the number of devices creates or removes that many at once, down to none", t)

    def t(check):
        pg.fill("#deviceCount", "99"); pg.press("#deviceCount", "Tab"); settle(700)
        check(len(device_names()) == 16 and pg.input_value("#deviceCount") == "16", "99 gave %d devices" % len(device_names()))
        check(pg.is_disabled("#add"), "Add still enabled at 16")
        pg.click("#deviceMore"); settle()
        check(len(device_names()) == 16 and not pg.locator("#note.error").count(), "a 17th device was attempted")
        pg.fill("#deviceCount", "2"); pg.press("#deviceCount", "Tab"); settle(700)
        check(device_names() == [A + "1", A + "2"], "back to two: %r" % device_names())
    case("UI-014", "No more than 16 devices can exist", t)

    def t(check):
        pg.fill("#name1", "אפיק תופים"); pg.press("#name1", "Enter"); settle()
        check(device_names()[1] == "אפיק תופים", "driver has %r" % device_names()[1])
        check(pg.input_value("#name1") == "אפיק תופים", "field shows %r" % pg.input_value("#name1"))
        check(note().startswith("Renamed to אפיק תופים."), "note: " + note())
        check(server_devices(base)[1]["uid"] == "virtualsafeaudio-2", "renaming changed the device's identity")
    case("UI-012", "A device can be renamed, in Hebrew, and keeps its identity", t)

    def t(check):
        pg.fill("#name1", A + "1"); pg.press("#name1", "Tab"); settle()
        check("both called" in note() and pg.locator("#note.error").count() == 1, "note: " + note())
        check(device_names()[1] == "אפיק תופים" and pg.input_value("#name1") == "אפיק תופים", "name after refused duplicate: %r" % pg.input_value("#name1"))
        pg.fill("#name1", "   "); pg.press("#name1", "Tab"); settle()
        check(device_names()[1] == "אפיק תופים" and pg.input_value("#name1") == "אפיק תופים", "name after empty input: %r" % pg.input_value("#name1"))
    case("UI-035", "A duplicate or empty name is refused and the old name stays", t)
    errors.clear()      # the browser logs the refused request (HTTP 400) to its console; that one was the point of the test

    def t(check):
        pg.focus("#name0"); settle(3600)
        check(pg.evaluate("document.activeElement.id") == "name0", "focus moved to %r" % pg.evaluate("document.activeElement.id"))
    case("UI-013", "Keyboard focus stays in a field across the background refresh", t)

    def t(check):
        pg.fill("#presetName", "Live set"); pg.click("#presetSave"); settle(400)
        check(pg.input_value("#presetList") == "Live set", "preset not selected in list")
        pg.fill("#deviceCount", "0"); pg.press("#deviceCount", "Tab"); settle()
        check(device_names() == [], "setup: devices not removed")
        pg.click("#presetLoad"); settle()
        check(device_names() == [A + "1", "אפיק תופים"] and units() == 2, "after loading: %r" % device_names())
        check(note().startswith("Loaded preset"), "note: " + note())
    case("UI-009", "Loading a saved preset recreates its devices at once", t)

    def t(check):
        pg.click("#presetDelete"); settle(400)
        check(pg.inner_text("#presetList").strip() == "None saved yet", "list: " + pg.inner_text("#presetList"))
        check(pg.is_disabled("#presetLoad"), "Load still enabled")
    case("UI-011", "Deleting a preset removes it from the list", t)

    def t(check):
        other = browser.new_page()
        other.goto(base); other.wait_for_selector(".unit")
        before = other.locator(".unit").count()
        pg.click("#add")
        try:
            other.wait_for_function("n => document.querySelectorAll('.unit').length === n", arg=before + 1, timeout=6000)
        except Exception:
            check(False, "second window still shows %d devices after 6 s" % other.locator(".unit").count())
        other.close()
        pg.locator(".unit .remove").last.click(); settle()
    case("UI-022", "A change made in one browser window shows up in another by itself", t)

    def t(check):
        pg.set_viewport_size({"width": 390, "height": 800}); settle(400)
        check(not pg.evaluate("document.documentElement.scrollWidth > window.innerWidth"), "page scrolls sideways")
        check(pg.evaluate(AMBER_PIXELS, 0) > 20, "meter not drawn at phone width")
        pg.set_viewport_size({"width": 1180, "height": 900})
    case("UI-015", "At phone width (390 px) nothing overflows sideways and meters still draw", t)

    def t(check):
        pg2 = browser.new_page()
        pg2.goto(missing); pg2.wait_for_selector("#installDriver")
        check("fault" in pg2.get_attribute("#lamp", "class"), "lamp class: " + pg2.get_attribute("#lamp", "class"))
        check(pg2.inner_text("#statusText") == "Driver not installed", "status: " + pg2.inner_text("#statusText"))
        check(pg2.is_visible("#installDriver"), "no install button")
        check(pg2.is_hidden("#add") and pg2.is_hidden("#deviceCountBox") and pg2.is_disabled("#audioSwitch"), "audio controls available without a driver")
        pg2.click("#midiSwitch"); pg2.wait_for_selector("#addPort:not([hidden])")      # MIDI must be fully usable on such a Mac
        pg2.click("#addPort"); pg2.wait_for_timeout(600)
        state = server_state(missing)["midi"]
        check(state["active"] and [x["name"] for x in state["ports"]] == [M + "1"], "MIDI without the audio driver: %r" % (state,))
        pg2.close()
    case("UI-016", "With no audio driver installed the panel offers to install it, and MIDI works regardless", t)

    # ---- the MIDI half
    def t(check):
        check(pg.get_attribute("#midiSwitch", "aria-checked") == "false" and pg.inner_text("#midiStatus") == "Off", "MIDI not off at start")
        check(pg.is_hidden("#addPort") and pg.is_hidden("#portCountBox"), "port controls visible while MIDI is off")
        pg.click("#midiSwitch"); pg.wait_for_selector("#addPort:not([hidden])")
        check(pg.get_attribute("#midiSwitch", "aria-checked") == "true" and server_state(base)["midi"]["active"], "MIDI did not switch on")
    case("UI-023", "MIDI is off until switched on; the switch takes effect at once", t)

    def t(check):
        pg.click("#addPort"); pg.click("#addPort"); settle(700)
        check(port_names() == [M + "1", M + "2"] and ports() == 2, "server has %r" % port_names())
        pg.fill("#pname1", "Clock out"); pg.press("#pname1", "Enter"); settle()
        check(port_names() == [M + "1", "Clock out"], "after rename: %r" % port_names())
        check(pg.inner_text("#midiStatus") == "2 ports live", "status: " + pg.inner_text("#midiStatus"))
    case("UI-024", "MIDI ports are created at once, numbered VirtualSafeMIDI#1, #2, ..., and can be renamed", t)

    def t(check):
        settle(1600)
        texts = pg.locator(".port .traffic").all_inner_texts()
        check(all(x.endswith("messages/s") for x in texts), "traffic readouts: %r" % texts)
    case("UI-025", "Each MIDI port shows its traffic", t)

    def t(check):
        pg.locator(".port .remove").first.click(); settle()
        check(port_names() == ["Clock out"] and ports() == 1, "server has %r" % port_names())
        check(note() == "Removed %s1." % M, "note: " + note())
    case("UI-026", "Removing a MIDI port takes it away at once", t)

    def t(check):
        n = units()
        pg.click("#audioSwitch"); settle(700)
        check(units() == 0 and pg.inner_text("#statusText") == "Off" and pg.is_hidden("#add") and pg.is_hidden("#deviceCountBox"), "audio controls still shown")
        check(server_state(base)["devices"] == [] and ports() == 1, "driver still has devices, or MIDI was disturbed")
        check("%d devices will come back" % n in pg.inner_text("#units"), "no word on the saved layout: " + pg.inner_text("#units")[:80])
        pg.click("#audioSwitch"); settle(700)
        check(units() == n and len(server_devices(base)) == n, "audio came back with %d devices, expected %d" % (units(), n))
    case("UI-027", "Audio can be switched off and on again without losing its devices or disturbing MIDI", t)

    def t(check):
        pg.fill("#presetName", "Studio"); pg.click("#presetSave"); settle(400)
        n = units()
        check("(%d audio, 1 MIDI)" % n in pg.inner_text("#presetList"), "preset label: " + pg.inner_text("#presetList"))
        pg.locator(".port .remove").first.click(); pg.locator(".unit .remove").first.click(); settle(700)
        check(ports() == 0 and units() == n - 1, "setup: removal did not happen")
        pg.click("#presetLoad"); settle(700)
        check(units() == n and port_names() == ["Clock out"] and len(server_devices(base)) == n, "preset did not restore both halves")
    case("UI-028", "A preset stores and restores audio devices and MIDI ports together", t)

    def t(check):
        pg.click("#portMore"); pg.click("#portMore"); settle(700)
        check(len(port_names()) == 3 and len(set(port_names())) == 3 and pg.input_value("#portCount") == "3", "server has %r" % port_names())
        pg.fill("#portCount", "1"); pg.press("#portCount", "Tab"); settle()
        check(port_names() == ["Clock out"] and note() == "Now 1 MIDI port.", "server has %r, note: %s" % (port_names(), note()))
    case("UI-031", "Setting the number of ports creates or removes that many at once", t)

    def t(check):
        pg.click("#midiSwitch"); settle(700)
        state = server_state(base)["midi"]
        check(ports() == 0 and state["active"] is False and len(state["ports"]) == 1, "state %r" % (state,))
        check("1 port will come back" in pg.inner_text("#ports"), "no word on the saved ports")
    case("UI-029", "MIDI can be switched off; its ports are kept for next time", t)

    def t(check):
        check(pg.is_visible("#keepBox") and not pg.is_checked("#keepAudio"), "Keep should be shown and unticked by default")
        pg.check("#keepAudio"); settle()
        check(server_state(base)["audio"]["keep"] is True, "server did not store Keep")
        check(note() == "Audio devices will stay in macOS when the app is closed.", "note: " + note())
        pg.reload(); pg.wait_for_selector(".unit")
        check(pg.is_checked("#keepAudio"), "Keep not shown as ticked after reloading the page")
        pg.uncheck("#keepAudio"); settle()
        check(server_state(base)["audio"]["keep"] is False and "come back when it starts" in note(), "unticking: " + note())
        pg.click("#audioSwitch"); settle(600)
        check(pg.is_hidden("#keepBox"), "Keep still offered while audio is off")
        pg.click("#audioSwitch"); settle(600)
        check(not errors, "script errors: %r" % errors)
    case("UI-032", "The Keep setting can be ticked and unticked, and shows what was chosen", t)

    browser.close()

failed = 0
for test_id, title, problems in results:
    if problems:
        failed += 1
        print("FAIL %s %s (%s)" % (test_id, title, "; ".join(problems)))
    else:
        print("PASS %s %s" % (test_id, title))
print("control panel interface: %d of %d cases passed" % (len(results) - failed, len(results)))
sys.exit(1 if failed else 0)
