#!/bin/bash
# Installs the audio driver: copies it into the system HAL plug-in folder and restarts
# Core Audio. All audio on the Mac drops out for a second or two while coreaudiod restarts.
# MIDI needs no install.
#
#   ./install.sh              build, then install (asks for your password through sudo)
#   ./install.sh --no-build   install what is already in build/ (for example after re-signing it)
#
# The control panel's install button does the same job without this script: it copies the
# built driver to a temporary folder first, because the administrator shell that macOS
# gives it is not allowed to read Downloads, Desktop or Documents.
set -euo pipefail
cd "$(dirname "$0")"

if [ "${1:-}" != "--no-build" ]; then
  ./build.sh driver
fi
[ -d build/VirtualSafeAudio.driver ] || { echo "Nothing to install: build/VirtualSafeAudio.driver is missing."; exit 1; }

# Already administrator? Then no sudo is needed.
SUDO="sudo"
if [ "$(id -u)" -eq 0 ]; then SUDO=""; fi

DEST="/Library/Audio/Plug-Ins/HAL"
$SUDO mkdir -p "$DEST"
$SUDO rm -rf "$DEST/VirtualSafeAudio.driver"
$SUDO cp -R build/VirtualSafeAudio.driver "$DEST/"
$SUDO chown -R root:wheel "$DEST/VirtualSafeAudio.driver"
$SUDO killall -9 coreaudiod || true

echo "Installed. 'VirtualSafeAudio' should now be listed in Audio MIDI Setup."
echo "If it is not there after a few seconds, restart the Mac once, then see README.md > Troubleshooting."
