#!/usr/bin/env python3
"""VirtualSafeAudioMIDI STP — runs the tests, keeps the results, writes the test plan.

    python3 stp/stp.py run                     run every automated test this machine can run,
                                               save results, regenerate the STP document
    python3 stp/stp.py run --after-uninstall   on the Mac, right after ./uninstall.sh
    python3 stp/stp.py pending                 list the manual tests that still have no result
    python3 stp/stp.py set AUD-010 pass        record a manual result (pass | fail | notrun)
    python3 stp/stp.py set AUD-012 fail "clicks at 32-sample buffer in Logic"
    python3 stp/stp.py report                  regenerate the STP document from stored results

Results live in stp/results.json, one entry per test ID. A run only overwrites the tests it
actually executed, so results from the Linux harness and from the Mac accumulate in one place.
Standard library only.
"""

import datetime
import http.client
import json
import os
import platform
import plistlib
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = os.path.join(ROOT, "stp", "results.json")
DOCUMENT = os.path.join(ROOT, "VIRTUALSAFEAUDIOMIDI-STP-v0.4.md")
HAL_BUNDLE = "/Library/Audio/Plug-Ins/HAL/VirtualSafeAudio.driver"
BUILT_BUNDLE = os.path.join(ROOT, "build", "VirtualSafeAudio.driver")
PLUGIN_TYPE_UUID = "443ABAB8-E7B3-491A-B985-BEB9187030DB"
IS_MAC = platform.system() == "Darwin"

sys.path.insert(0, os.path.join(ROOT, "gui"))
import virtualsafeaudiomidi_gui as gui  # noqa: E402

# ------------------------------------------------------------------ catalogue
#
# Tests the harnesses run are not listed here: their IDs and titles are read from the harness
# sources, so the plan can never drift from what is actually executed.
#
#   (id, how, title, procedure, expected)
#   how: static        checked by this script on any machine
#        sanitizer     a C harness rebuilt with AddressSanitizer + UBSan
#        mac           run by this script on the Mac
#        mac-uninstall run by this script on the Mac with --after-uninstall
#        manual        a person, on the Mac

CHAPTERS = [
    ("1", "INS", "Install and uninstall",
     "Building the driver, getting it into macOS, and getting it out again without leaving anything behind."),
    ("2", "CFG", "Devices and configuration",
     "Creating, renaming, resizing and removing virtual devices, and keeping that layout across restarts."),
    ("3", "AUD", "Audio loopback",
     "What is played into a device must come back out of it unchanged, on time, on the right channels."),
    ("4", "MTR", "Level meters",
     "Peak and VU levels measured inside the driver and shown in the panel."),
    ("5", "MID", "Virtual MIDI ports",
     "Ports that pass MIDI from one app to another, created and removed live, with nothing to install."),
    ("6", "API", "Control panel server",
     "The Python server between the browser, the audio driver and the MIDI helper: validation, switching each half on and off, presets, meter and traffic stream."),
    ("7", "UI", "Control panel interface",
     "The page itself: the two switches, editing, applying, presets, meters, MIDI traffic, layout."),
    ("8", "ROB", "Robustness",
     "Bad input, memory safety, rapid changes, and behaviour when things are pulled out from under it."),
]

CATALOGUE = [
    # ---- Chapter 1: install and uninstall
    ("INS-001", "static", "Build, install and uninstall scripts have no shell syntax errors", "", ""),
    ("INS-002", "static", "Bundle Info.plist is valid and consistent with the driver source and the panel (bundle ID, factory function, plug-in type)", "", ""),
    ("INS-003", "static", "All three scripts are executable", "", ""),
    ("INS-004", "static", "Install and uninstall act on the same bundle path", "", ""),
    ("INS-005", "mac", "Xcode command line tools are present",
     "`xcode-select -p` and `clang --version`", "Both exit 0"),
    ("INS-006", "mac", "Driver builds from source",
     "`./build.sh`", "Exit 0; `build/VirtualSafeAudio.driver` contains `Contents/Info.plist` and `Contents/MacOS/VirtualSafeAudio`"),
    ("INS-007", "mac", "Built driver runs on both Apple silicon and Intel",
     "`lipo -archs` on the built binary", "Lists `arm64` and `x86_64`"),
    ("INS-008", "mac", "Built bundle carries a valid signature",
     "`codesign --verify --strict` on the built bundle", "Exit 0"),
    ("INS-009", "mac", "Built binary exports the entry point macOS looks for",
     "`nm -gU` on the built binary", "`_VirtualSafeAudio_Create` is listed"),
    ("INS-010", "manual", "Installer completes",
     "In Terminal, from the project folder: `./install.sh`. Enter the admin password when asked.",
     "Ends with the line starting `Installed.`; no error lines. All audio drops out for a moment and comes back."),
    ("INS-011", "mac", "Driver bundle is in the system plug-in folder, owned by root",
     "Inspect `/Library/Audio/Plug-Ins/HAL/VirtualSafeAudio.driver`", "Exists; owner is root"),
    ("INS-012", "mac", "Core Audio is running after install",
     "`pgrep -x coreaudiod`", "A process ID is returned"),
    ("INS-013", "mac", "Every device the driver publishes is listed by macOS with the right channel counts",
     "Compare the driver's device list with `system_profiler SPAudioDataType`", "Each device appears once, inputs = outputs = configured channels"),
    ("INS-014", "manual", "First install shows the first device",
     "On a Mac where the driver was never installed, install it from the panel, then open Audio MIDI Setup.",
     "A device named `VirtualSafeAudio#1` is listed with 2 ins / 2 outs at 48 kHz. No restart was needed."),
    ("INS-015", "manual", "Other audio devices are unaffected by the install",
     "After install, play music through the built-in speakers or your interface. Check Audio MIDI Setup.",
     "Every device that was there before is still there and still plays."),
    ("INS-016", "manual", "Installing while audio is playing recovers by itself",
     "Start music in any app on the normal output, then run `./install.sh`.",
     "Audio stops for a few seconds at most and resumes (or resumes on pressing play) without restarting the app."),
    ("INS-017", "manual", "Installing over an existing install does not duplicate anything",
     "Run `./install.sh` a second time. Look in Audio MIDI Setup.",
     "Same devices as before, each listed once."),
    ("INS-018", "manual", "With Keep ticked, devices are there after a reboot with the panel not running",
     "Tick `Keep devices when the app is closed`. Restart the Mac. Do not start the panel. Open Audio MIDI Setup.",
     "All VirtualSafeAudio devices are listed as before the restart."),
    ("INS-019", "mac", "No Core Audio crash reports since the driver was installed",
     "Scan the DiagnosticReports folders for coreaudiod / Core Audio driver host reports newer than the installed bundle", "None found"),
    ("INS-020", "manual", "Uninstaller completes and the devices disappear",
     "`./uninstall.sh`, then look in Audio MIDI Setup. Then run `python3 stp/stp.py run --after-uninstall`.",
     "Ends with `VirtualSafeAudio driver removed.` No VirtualSafeAudio device is listed any more."),
    ("INS-021", "mac-uninstall", "Driver bundle is gone after uninstall",
     "Inspect `/Library/Audio/Plug-Ins/HAL/`", "No `VirtualSafeAudio.driver`"),
    ("INS-022", "mac-uninstall", "macOS lists no VirtualSafeAudio device after uninstall",
     "`system_profiler SPAudioDataType`", "No device with manufacturer VirtualSafeAudio"),
    ("INS-023", "mac-uninstall", "Core Audio is running after uninstall",
     "`pgrep -x coreaudiod`", "A process ID is returned"),
    ("INS-024", "manual", "Uninstalling while a virtual device is the system output falls back cleanly",
     "System Settings > Sound > Output: choose a VirtualSafeAudio device. Run `./uninstall.sh`.",
     "macOS switches to another output by itself. No hang, no beachball, sound works."),
    ("INS-025", "manual", "Uninstalling twice is harmless",
     "Run `./uninstall.sh` again with the driver already removed.", "Exits without an error."),
    ("INS-026", "manual", "Reinstalling brings back the previous device layout",
     "Create two extra devices in the panel, `./uninstall.sh`, then `./install.sh`.",
     "The same devices (names, channel counts) are back. Documented behaviour: Core Audio keeps the driver's settings."),
    ("INS-027", "manual", "Panel tells you when the driver is not installed",
     "With the driver uninstalled, start the panel and open it.",
     "The Audio section says `Driver not installed` with a red lamp and an `Install audio driver` button. The MIDI section is fully usable. After installing, the page recovers by itself within about 5 seconds."),
    ("INS-028", "static", "Start launcher has no shell syntax errors and is executable", "", ""),
    ("INS-029", "static", "Start launcher brings the control panel up and the panel answers (mock driver)", "", ""),
    ("INS-030", "static", "Starting the launcher a second time finds the running panel instead of starting another", "", ""),
    ("INS-039", "static", "Starting a new copy while a different version is still running offers to replace it, and does", "", ""),
    ("INS-040", "static", "With some other program on its port, the launcher says so instead of opening that program", "", ""),
    ("INS-041", "manual", "After an update, the version shown is the one just downloaded",
     "With an older version's panel still running, unzip a newer version and double-click its `START Mac.command`. Answer Return to the question.",
     "The launcher names the other copy's version and folder, replaces it, and the panel header shows the new version number."),
    ("INS-031", "manual", "The launcher can be opened after a fresh download",
     "Unzip a freshly downloaded copy and double-click `START Mac.command`. If macOS refuses, run `xattr -d com.apple.quarantine \"START Mac.command\"` in the project folder (or System Settings > Privacy & Security > Open Anyway) and double-click again.",
     "A Terminal window opens and shows the VirtualSafeAudio heading."),
    ("INS-032", "manual", "Starting on a Mac without the audio driver asks for nothing",
     "With the driver uninstalled, double-click `START Mac.command`.",
     "No questions and no password prompt. The panel opens in the browser; the Audio section offers the install button."),
    ("INS-033", "manual", "Double-click start with the driver already installed goes straight to the panel",
     "Double-click `START Mac.command`.", "The panel opens in the browser within a few seconds, Audio section connected."),
    ("INS-034", "manual", "Double-clicking again while the panel runs opens the existing panel",
     "With the panel running, double-click `START Mac.command` again.",
     "A browser tab opens on the running panel; the second Terminal window closes by itself; the first keeps running."),
    ("INS-035", "manual", "Closing the launcher window closes the app: audio devices and MIDI ports leave macOS",
     "With Keep unticked (the default), audio devices existing and MIDI switched on, close the launcher's Terminal window (or press control-C in it).",
     "Within a few seconds the virtual audio devices are gone from the macOS sound menu and the virtual MIDI ports from apps. The panel page shows that the server is not answering."),
    ("INS-036", "manual", "The audio driver can be installed from the panel",
     "With the driver uninstalled and the project folder inside Downloads (where a browser unzips it), open the panel and press `Install audio driver`. Enter the password in the macOS dialog that appears.",
     "All sound drops for a moment. Within about a minute the Audio section shows the lamp lit and one device, `VirtualSafeAudio#1`. No Terminal input was needed."),
    ("INS-037", "manual", "Cancelling the password dialog changes nothing",
     "With the driver uninstalled, press `Install audio driver`, then press Cancel in the password dialog.",
     "The panel says `The install was cancelled. Nothing was changed.` The button is available again. Nothing was installed; sound was not interrupted."),

    # ---- Chapter 2: devices and configuration
    ("CFG-013", "mac", "The panel's bridge finds the driver in Core Audio and reads its device list",
     "Read the driver's device-list property through the Python bridge", "A parseable list comes back"),
    ("CFG-014", "mac", "A new 8-channel device shows up in macOS",
     "Add `STP test device` (8 ch) through the bridge", "macOS lists it with 8 ins / 8 outs within 8 s"),
    ("CFG-015", "mac", "Renaming a device is reflected in macOS",
     "Rename it to `STP renamed`", "macOS lists the new name and no longer the old one"),
    ("CFG-016", "mac", "Changing the channel count is reflected in macOS",
     "Change it to 16 channels", "macOS lists it with 16 ins / 16 outs"),
    ("CFG-017", "mac", "A 64-channel device is published",
     "Change it to 64 channels", "macOS lists it with 64 ins / 64 outs"),
    ("CFG-018", "mac", "Removing a device removes it from macOS and leaves the others alone",
     "Remove the test device", "It is gone; every device from before the test is still listed"),
    ("CFG-019", "mac", "Sixteen devices can exist at once",
     "Add test devices until there are 16", "Driver reports 16; macOS lists all of them"),
    ("CFG-020", "mac", "The device layout from before the tests is restored",
     "Write the saved list back and read it again", "Identical to the list read in CFG-013"),
    ("CFG-027", "mac", "Adding, renaming, resizing and removing devices never restarts Core Audio",
     "Compare the process ID of coreaudiod before CFG-014 and after CFG-019", "Same process ID"),
    ("CFG-028", "manual", "A device added in the panel appears in an app that is already open",
     "Open a DAW's audio device menu (or QuickTime Player > New Audio Recording > the input menu). In the panel add a device. Reopen the menu without restarting the app.",
     "The new device is in the list within a few seconds. Remove it in the panel: it leaves the list the same way."),
    ("CFG-029", "manual", "Adding or removing one device does not disturb audio on another",
     "Loop a 1 kHz sine through device A and record it. While recording, add device B in the panel, then remove it.",
     "The recording from device A has no gap or click at the moments of the changes."),
    ("CFG-030", "manual", "The number of devices set in the panel is what macOS shows, at once",
     "With the macOS sound menu in view: set `Number of stereo devices` to 4, then to 2, then to 0. There is nothing to press afterwards.",
     "At 4: `VirtualSafeAudio#1` to `#4` are listed. At 2: `#3` and `#4` are gone. At 0: no VirtualSafeAudio device is listed. Each change shows within a second or two; nothing is restarted."),
    ("CFG-034", "manual", "Every device is stereo",
     "Create 3 devices. Open Audio MIDI Setup and select each one.",
     "Each shows 2 ins / 2 outs. The panel has no control that changes a device's channel count."),
    ("CFG-035", "manual", "A removed number is reused and apps recognise the device again",
     "With `#1`, `#2`, `#3` existing, point a DAW track at `VirtualSafeAudio#2`. Remove `#2` in the panel, then press `+`.",
     "The new device is called `VirtualSafeAudio#2` again and the DAW track reconnects to it without being reassigned."),
    ("CFG-021", "manual", "A rename shows up in macOS",
     "With two devices existing and audio running through `#1`, type a new name for `#2` in the panel and press Return. Open the macOS sound menu and Audio MIDI Setup.",
     "Within a few seconds both show the new name for that device. The audio running through `#1` has no gap. (The renamed device itself reconnects for a moment.)"),
    ("CFG-036", "manual", "An app using a device that is renamed finds it again",
     "Record from a virtual device in a DAW. Rename that device in the panel.",
     "The DAW reports the device gone for a moment and then has it back under the new name, or accepts it again after reselecting it. Nothing crashes."),
    ("CFG-022", "manual", "A Hebrew device name is shown correctly by macOS and by a DAW",
     "Give a device a Hebrew name in the panel (press Return). Look in Audio MIDI Setup and in your DAW's device list.",
     "Name is readable and complete in both."),
    ("CFG-023", "manual", "Device layout survives a Core Audio restart",
     "Set up 3 devices, one of them renamed. `sudo killall -9 coreaudiod`.",
     "After Core Audio comes back, the same 3 devices are listed."),
    ("CFG-024", "manual", "With Keep ticked, the device layout survives a reboot",
     "Same 3 devices, `Keep devices when the app is closed` ticked. Restart the Mac; do not start the panel.", "Same 3 devices are listed."),
    ("CFG-031", "manual", "Closing the app removes the audio devices; starting it brings the same ones back",
     "Keep unticked. Set up 3 devices, one of them renamed. Close the launcher window and look at the macOS sound menu. Start the app again and look once more.",
     "After closing: none of the three is listed. After starting: the same three with the same names, without touching the panel. A DAW that was using one finds it again."),
    ("CFG-032", "manual", "After a restart of the Mac the audio devices are absent until the app is started",
     "Keep unticked, devices existing. Restart the Mac normally. Look at the sound menu before starting the app, then start it.",
     "None listed before the app starts; all of them back after."),
    ("CFG-033", "manual", "With Keep ticked, closing the app leaves the audio devices in place",
     "Tick Keep. Run audio through a device into a recording app. Close the launcher window.",
     "The devices stay in the sound menu and the audio is not interrupted."),
    ("CFG-025", "manual", "Sample rate chosen in Audio MIDI Setup sticks and is remembered",
     "Set a device to 96 kHz in Audio MIDI Setup. Check the panel. Reboot.",
     "Panel shows 96 kHz for that device; still 96 kHz after the reboot."),

    # ---- Chapter 3: audio loopback
    ("AUD-010", "manual", "Basic loopback with real apps",
     "Music app output = VirtualSafeAudio. QuickTime Player > New Audio Recording, input = VirtualSafeAudio. Record 20 s, play it back on speakers.",
     "The recording contains the music, clean, both channels."),
    ("AUD-011", "manual", "Nothing playing records as digital silence",
     "Record 10 s from a virtual device in a DAW with nothing playing into it.",
     "Waveform is a flat line; DAW meter shows no signal at all (not noise)."),
    ("AUD-012", "manual", "Loopback is bit-transparent (null test)",
     "In a DAW: play a file out to the virtual device and record it back on a new track. Align, invert the recording, sum with the original.",
     "Sum is silent (below -120 dBFS)."),
    ("AUD-013", "manual", "Every sample rate works",
     "Repeat AUD-010 at 44.1, 48, 88.2, 96, 176.4 and 192 kHz (set in Audio MIDI Setup or the DAW).",
     "Clean audio, correct pitch and speed at each rate. Note any rate that fails."),
    ("AUD-014", "manual", "Small and large buffer sizes are free of clicks",
     "In a DAW, loop a 1 kHz sine through the device at buffer sizes 32, 64, 128, 256, 512, 1024, 2048. Record 30 s each.",
     "No clicks or gaps in any recording."),
    ("AUD-015", "manual", "Two apps playing into one device are mixed",
     "Play from two apps at once into the same virtual device, record from it.", "Both are audible in the recording."),
    ("AUD-016", "manual", "Two apps can record from one device at the same time",
     "Play into a device; record from it in QuickTime and in a DAW simultaneously.", "Both recordings contain the audio."),
    ("AUD-017", "manual", "Left and right stay where they are",
     "In a DAW send a tone to the left output of a device only and record both of its inputs. Repeat with the right.",
     "Left arrives on input 1 only, right on input 2 only."),
    ("AUD-018", "manual", "Works as the system output",
     "System Settings > Sound > Output = VirtualSafeAudio. Play a video in a browser and a system alert. Record from the device.",
     "Both are in the recording."),
    ("AUD-019", "manual", "Works inside a Multi-Output Device",
     "Audio MIDI Setup: create a Multi-Output Device with your speakers + VirtualSafeAudio. Play 10 minutes of music through it while recording from VirtualSafeAudio.",
     "You hear it and it records; no glitches or growing delay over the 10 minutes."),
    ("AUD-020", "manual", "Loopback resumes after sleep",
     "With loopback running, put the Mac to sleep for a minute and wake it.", "Audio passes again without reinstalling or restarting Core Audio."),
    ("AUD-021", "manual", "One-hour soak",
     "Loop a 1 kHz sine through a device and record for 60 minutes.",
     "No dropouts or clicks in the hour (scan the waveform / spectrogram)."),
    ("AUD-022", "manual", "Round-trip latency is measured and recorded",
     "In a DAW, send a click out to the device, record it back, measure the offset in samples at 48 kHz, buffer 256.",
     "Record the number in the result note. Informational for 0.1; expected to be a small constant, the same on every run."),
    ("AUD-023", "manual", "Two virtual devices do not leak into each other",
     "Two devices. Play into device A only; record from device B.", "Device B records silence."),

    # ---- Chapter 4: meters
    ("MTR-005", "mac", "Real audio played into a device moves its meter",
     "Play speech into a test device with `say -a` while reading the driver's meter property", "Peak on channel 1 rises above 0.01 (-40 dBFS)"),
    ("MTR-006", "mac", "The meter returns to zero after playback ends",
     "Read the meter 1.5 s after `say` has finished", "All values are 0"),
    ("MTR-007", "manual", "Panel meters follow the audio, on the right channels",
     "Play a file panned hard left into a device and watch the panel.", "The L row moves with the music; the R row stays dark."),
    ("MTR-008", "manual", "Meter reading is accurate against a reference tone",
     "Play a 1 kHz sine at -18 dBFS RMS into a device.", "The lit part of the row ends at the 21st or 22nd of its 30 segments (each segment is 2 dB, the last one is 0 dBFS)."),
    ("MTR-009", "manual", "Clipping is flagged",
     "Play a 0 dBFS square wave or tone briefly.", "The last (rightmost) segment of that row lights red and stays for about 1.5 s after the tone stops."),
    ("MTR-010", "manual", "Watching meters does not count as recording",
     "With only the panel open (no recording app), watch the menu bar and System Settings > Privacy > Microphone.",
     "No orange microphone indicator; no permission prompt; Terminal/Python not listed as having asked for the microphone."),
    ("MTR-013", "manual", "Sixteen devices show sixteen meters, each following its own device",
     "Set the number of devices to 16. Play into three of them from different apps.", "Sixteen L/R meters are shown; exactly the three in use move."),
    ("MTR-012", "manual", "Meters stay smooth and cheap over time",
     "Leave the panel open for 5 minutes with audio playing. Watch Activity Monitor.",
     "Meters do not stutter or freeze; the Python process and the browser tab stay at a few percent CPU."),

    # ---- Chapter 5: virtual MIDI ports
    ("MID-021", "mac", "MIDI helper and the MIDI test tool build from source",
     "`./build.sh midi`", "Exit 0; `build/vsamidi` and `build/miditest` exist"),
    ("MID-022", "mac", "A virtual port shows up in macOS as both a MIDI input and a MIDI output",
     "Start the helper with one port, `STP MIDI A`; list all MIDI endpoints with `build/miditest list`", "`STP MIDI A` is listed once as SRC and once as DST"),
    ("MID-023", "mac", "100 notes sent into a port all come back out, in order",
     "`build/miditest loop \"STP MIDI A\" 100`", "`sent=100 received=100 out_of_order=0`"),
    ("MID-024", "mac", "Adding a second port live leaves the first port's identity unchanged",
     "Add `STP MIDI B` while the helper runs; compare the unique IDs of `STP MIDI A` before and after", "Both ports listed; A has the same two unique IDs"),
    ("MID-025", "mac", "A renamed port shows its new name in macOS and keeps its identity",
     "Rename A to `STP MIDI renamed`", "New name listed with the same unique IDs; old name gone"),
    ("MID-026", "mac", "Stopping the helper removes its ports from macOS",
     "Stop the helper; list endpoints", "No endpoint whose name starts with `STP MIDI`"),
    ("MID-027", "manual", "First switch-on needs no password and no install",
     "On a Mac where MIDI was never switched on, switch MIDI on in the panel.",
     "Within about 10 seconds (the helper is built once) the lamp lights. No password dialog. Needs only the Xcode command line tools."),
    ("MID-028", "manual", "Ports appear in MIDI apps on both sides",
     "Switch MIDI on and add a port. Open a DAW's MIDI input list and its MIDI output list.",
     "The port is in both lists under the name given in the panel."),
    ("MID-029", "manual", "Notes pass from one app to another",
     "App A sends notes to the port (a DAW track, or a keyboard routed through it). App B listens on the port with a synth or a MIDI monitor.",
     "Every note arrives with the right pitch, velocity and channel; note-offs are not lost (no stuck notes)."),
    ("MID-030", "manual", "MIDI clock through a port keeps the receiver in time",
     "App A sends MIDI clock at 120 BPM to the port. App B syncs to it. Run 5 minutes.",
     "B shows 120 BPM (within what B shows when synced to A over the IAC Driver) and does not drift or stutter."),
    ("MID-031", "manual", "A large system exclusive message passes intact",
     "Send a SysEx dump of at least 1 KB (for example a patch dump) into the port and capture it on the other side with a MIDI monitor or SysEx tool.",
     "Same length, same bytes."),
    ("MID-032", "manual", "Adding or removing a port does not disturb traffic on another",
     "Keep clock running through port A into a synced app. In the panel add port B, then remove it.",
     "The synced app does not hiccup or lose sync at either moment."),
    ("MID-033", "manual", "The panel shows real traffic on the right port",
     "Send notes into one of two ports and watch the panel.", "That port's lamp flashes and its messages/s figure moves; the other port says `No traffic`."),
    ("MID-034", "manual", "A DAW finds the port again after the panel is restarted",
     "With a DAW track assigned to a virtual port, quit the panel (the DAW reports the port gone). Start the panel again.",
     "The port returns and the DAW reconnects the track by itself, without reassigning it."),
    ("MID-035", "manual", "MIDI works on a Mac without the audio driver",
     "With the audio driver uninstalled, switch MIDI on, add a port, run MID-029.", "Same result as MID-029."),
    ("MID-036", "manual", "No noticeable delay through a port",
     "Play a hardware keyboard into a DAW that forwards to a virtual port feeding a synth in a second app; compare the feel with the synth driven directly.",
     "No audible extra latency. If your DAW can measure MIDI round trip, record the figure in the note."),

    # ---- Chapter 6: control panel server
    ("API-023", "mac", "Panel server started against the real driver reports it as connected",
     "Start `gui/virtualsafeaudiomidi_gui.py` on a spare port and GET `/api/state`", "`connected` is true; devices match the driver's list"),
    ("API-024", "mac", "A device list posted to the panel server reaches the real driver",
     "POST a list with one extra device to `/api/config`, read the driver's list through the bridge", "The extra device is in the driver's list; then the original list is restored"),
    ("API-025", "mac", "Meter stream works against the real driver",
     "Read three events from `/api/meters`", "Each event has one entry per device"),
    ("API-026", "manual", "Panel reconnects by itself after Core Audio restarts",
     "With the panel open: `sudo killall -9 coreaudiod`.", "Lamp may go red briefly, then returns to connected without reloading the page."),
    ("API-027", "manual", "Port option works and a busy port gives a clear error",
     "`python3 gui/virtualsafeaudiomidi_gui.py --port 9000`, open it. Start a second copy on the same port.",
     "Panel is served on 9000. The second copy exits at once, saying the port is in use, and creates no second set of MIDI ports."),
    ("API-028", "manual", "Panel is local-only by default",
     "Start the panel with no options. From a phone on the same Wi-Fi, open `http://<mac-ip>:8767`.", "Does not load."),
    ("API-029", "manual", "Panel can be opened from another device when asked to",
     "Start with `--host 0.0.0.0`. From the phone, open `http://<mac-ip>:8767`.", "Panel loads, meters move, a device added from the phone appears on the Mac."),
    ("API-030", "manual", "Presets are stored where the documentation says",
     "Save a preset. Open `~/Library/Application Support/VirtualSafeAudioMIDI/presets.json`.", "File exists and contains the preset (audio devices and MIDI ports)."),
    ("API-036", "manual", "What was switched on is still switched on next time",
     "Switch MIDI on and audio off. Quit the panel (close the launcher window). Start it again.",
     "MIDI comes up on with the same ports; audio is still off, with its devices saved."),

    # ---- Chapter 7: control panel interface
    ("UI-017", "manual", "Panel works in Safari",
     "In Safari: change the number of devices, add and remove one, rename one, do the same for MIDI ports, save / load / delete a preset, watch meters.", "Everything works; layout is intact."),
    ("UI-018", "manual", "Panel works in Chrome", "Same steps in Chrome.", "Everything works; layout is intact."),
    ("UI-019", "manual", "Panel works in Firefox", "Same steps in Firefox.", "Everything works; layout is intact."),
    ("UI-020", "manual", "Panel is usable on a phone",
     "With `--host 0.0.0.0`, open the panel on a phone. Add a device and rename it.", "Controls are reachable and readable; nothing is cut off; the bottom bar does not cover the last row."),
    ("UI-021", "manual", "Panel can be driven from the keyboard alone",
     "Using only Tab, Shift+Tab, Space, Enter and typing: change the number of devices, rename one, switch MIDI on.", "Every control can be reached; focus is always visible."),

    # ---- Chapter 8: robustness
    ("ROB-003", "sanitizer", "Driver harness is clean under AddressSanitizer and UndefinedBehaviorSanitizer", "", ""),
    ("ROB-011", "sanitizer", "MIDI helper harness is clean under AddressSanitizer and UndefinedBehaviorSanitizer", "", ""),
    ("ROB-004", "mac", "Thirty device-list changes in a row leave the driver answering and Core Audio alive",
     "Add and remove a test device 15 times with no pauses, through the bridge", "Driver still answers; list equals the original; coreaudiod has the same process ID"),
    ("ROB-005", "mac", "No Core Audio crash reports were produced during this test run",
     "Scan the DiagnosticReports folders for reports newer than the start of the run", "None found"),
    ("ROB-006", "manual", "Removing a device while a DAW is recording from it crashes nothing",
     "Record from a virtual device in a DAW. Remove that device in the panel.", "DAW reports the device is gone; neither the DAW nor Core Audio crashes; other audio keeps working."),
    ("ROB-007", "manual", "Idle cost is negligible",
     "Driver installed, nothing using it, panel closed. Watch `coreaudiod` and the Core Audio driver service in Activity Monitor for a minute.",
     "Both at about 0 % CPU."),
    ("ROB-015", "manual", "Cost of sixteen devices carrying audio at once is reasonable",
     "Create 16 devices and run audio through as many as you can at 48 kHz, buffer 256, for a minute.", "No dropouts; driver service CPU stays in single digits on the Mac mini. Record the figure."),
    ("ROB-009", "manual", "Memory does not grow with repeated reconfiguration",
     "Note the driver service's memory in Activity Monitor. Add and remove a device 50 times in the panel. Note it again.",
     "Memory is back to roughly the starting figure (within a few MB)."),
    ("ROB-010", "manual", "Closing the browser tab affects nothing; with Keep ticked, neither does stopping the app",
     "With loopback running, close the browser tab. Then, with Keep ticked, stop the Python server with Ctrl+C.", "Audio through the virtual devices is uninterrupted both times."),
    ("ROB-014", "manual", "If the app is force-quit, the audio devices and MIDI ports are still removed",
     "Keep unticked, devices and ports existing. In another Terminal window: `pkill -9 -f \"virtualsafeaudiomidi_gui.py --port\"`.",
     "Within a few seconds the audio devices leave the sound menu and the MIDI ports leave apps. Starting the app again brings both back."),
]

HARNESSES = {
    "driver":  ("Driver logic harness", os.path.join(ROOT, "driver", "test", "test_driver.c"), r'CASE\("([A-Z]+-\d+)",\s*"([^"]+)"\)'),
    "midi":    ("MIDI helper harness", os.path.join(ROOT, "midi", "test", "test_midi.c"), r'CASE\("([A-Z]+-\d+)",\s*"([^"]+)"\)'),
    "panel":   ("Panel server harness", os.path.join(ROOT, "gui", "test_gui.py"), r'^(?:case\(|    \()"([A-Z]+-\d+)",\s*"([^"]+)"\)'),
    "browser": ("Browser harness", os.path.join(ROOT, "gui", "test_browser.py"), r'case\("([A-Z]+-\d+)",\s*"([^"]+)",\s*t\)'),
}
HOW_LABEL = {"static": "Static check", "sanitizer": "C harness, sanitizers", "driver": "Driver logic harness", "midi": "MIDI helper harness",
             "panel": "Panel server harness", "browser": "Browser harness",
             "mac": "Mac runner", "mac-uninstall": "Mac runner", "manual": "Manual"}
HERE_KINDS = ("static", "sanitizer", "driver", "midi", "panel", "browser")
MAC_AUTO_KINDS = ("mac", "mac-uninstall")


def all_cases():
    """Every test as a dict, harness cases included, sorted by chapter then number."""
    cases = [dict(id=i, how=h, title=t, procedure=p, expected=e) for i, h, t, p, e in CATALOGUE]
    for how, (_, path, pattern) in HARNESSES.items():
        with open(path, encoding="utf-8") as f:
            for test_id, title in re.findall(pattern, f.read(), re.M):
                cases.append(dict(id=test_id, how=how, title=title, procedure="", expected=""))
    ids = [c["id"] for c in cases]
    dupes = sorted({i for i in ids if ids.count(i) > 1})
    if dupes:
        sys.exit("Duplicate test IDs: " + ", ".join(dupes))
    order = {prefix: n for n, (_, prefix, _, _) in enumerate(CHAPTERS)}
    cases.sort(key=lambda c: (order[c["id"].split("-")[0]], int(c["id"].split("-")[1])))
    return cases


# ------------------------------------------------------------------ results store

def load_results():
    try:
        with open(RESULTS, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_results(results):
    with open(RESULTS, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=1, sort_keys=True)
        f.write("\n")


def environment():
    if os.environ.get("STP_ENV"):
        return os.environ["STP_ENV"]
    if IS_MAC:
        return "macOS %s (%s)" % (platform.mac_ver()[0], platform.machine())
    return "%s %s (%s)" % (platform.system(), platform.release(), platform.machine())


class Recorder:
    """Collects results for one run. Anything not recorded keeps its previous result."""

    def __init__(self, simulate=False):
        self.simulate = simulate
        self.items = {}

    def record(self, test_id, status, note=""):
        self.items[test_id] = {"status": status, "note": note.strip()[:300],
                               "date": datetime.date.today().isoformat(), "env": environment()}
        print("%-6s %s%s" % ({"pass": "PASS", "fail": "FAIL", "notrun": "SKIP"}[status], test_id, ("  " + note.strip()[:160]) if note else ""))

    def check(self, test_id, fn):
        """fn returns None/'' for a pass, or a string saying what is wrong."""
        try:
            problem = fn()
        except Exception as e:
            problem = "%s: %s" % (type(e).__name__, e)
        self.record(test_id, "fail" if problem else "pass", problem or "")
        return not problem


def sh(cmd, timeout=300, cwd=ROOT, env=None):
    p = subprocess.run(cmd, shell=isinstance(cmd, str), cwd=cwd, env=env, timeout=timeout,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    return p.returncode, p.stdout


def record_harness_output(rec, output, expected_ids, reason_if_missing):
    seen = set()
    for line in output.splitlines():
        m = re.match(r"(PASS|FAIL|SKIP) ([A-Z]+-\d+) (.*)", line)
        if m and m.group(2) in expected_ids:
            seen.add(m.group(2))
            note = ""
            if m.group(1) != "PASS":
                found = re.search(r"\((.*)\)\s*$", m.group(3))
                note = found.group(1) if found else m.group(3)
            rec.record(m.group(2), {"PASS": "pass", "FAIL": "fail", "SKIP": "notrun"}[m.group(1)], note)
    for test_id in sorted(expected_ids - seen):
        rec.record(test_id, "notrun", reason_if_missing)


# ------------------------------------------------------------------ suites that run anywhere

def run_static(rec):
    scripts = [os.path.join(ROOT, s) for s in ("build.sh", "install.sh", "uninstall.sh")]

    def syntax():
        bad = [os.path.basename(s) for s in scripts if sh(["bash", "-n", s])[0] != 0]
        return "syntax errors in " + ", ".join(bad) if bad else None

    def plist():
        with open(os.path.join(ROOT, "driver", "Info.plist"), "rb") as f:
            info = plistlib.load(f)
        with open(os.path.join(ROOT, "driver", "virtualsafeaudio.c"), encoding="utf-8") as f:
            source = f.read()
        with open(os.path.join(ROOT, "build.sh"), encoding="utf-8") as f:
            build = f.read()
        factories = info.get("CFPlugInFactories", {})
        problems = []
        if info.get("CFBundleIdentifier") != gui.BUNDLE_ID:
            problems.append("bundle ID differs from the panel's BUNDLE_ID")
        if len(factories) != 1:
            problems.append("expected exactly one factory")
        for uuid, function in factories.items():
            if not re.search(r"^void\*\s+%s\s*\(" % re.escape(function), source, re.M):
                problems.append("factory function %s not defined in the driver" % function)
            if info.get("CFPlugInTypes", {}).get(PLUGIN_TYPE_UUID) != [uuid]:
                problems.append("plug-in type does not point at the factory")
        if "Contents/MacOS/%s" % info.get("CFBundleExecutable") not in build:
            problems.append("CFBundleExecutable does not match the file build.sh produces")
        return "; ".join(problems) or None

    def executable():
        bad = [os.path.basename(s) for s in scripts if not os.access(s, os.X_OK)]
        return "not executable: " + ", ".join(bad) if bad else None

    def same_path():
        texts = [open(os.path.join(ROOT, s), encoding="utf-8").read() for s in ("install.sh", "uninstall.sh")]
        ok = all("/Library/Audio/Plug-Ins/HAL" in t and "VirtualSafeAudio.driver" in t for t in texts)
        return None if ok else "install.sh and uninstall.sh do not reference the same bundle path"

    rec.check("INS-001", syntax)
    rec.check("INS-002", plist)
    rec.check("INS-003", executable)
    rec.check("INS-004", same_path)
    run_launcher(rec)


def run_launcher(rec):
    """Starts the real launcher with the mock driver on a spare port, no browser, and checks it end to end."""
    launcher = os.path.join(ROOT, "START Mac.command")
    rec.check("INS-028", lambda: None if sh(["bash", "-n", launcher])[0] == 0 and os.access(launcher, os.X_OK)
              else "syntax error, or the file is not executable")

    port = 8793
    env = dict(os.environ, VSA_PORT=str(port), VSA_NO_OPEN="1")
    first = subprocess.Popen(["bash", launcher, "--mock", "--data-dir", tempfile.mkdtemp()], env=env, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, start_new_session=True)
    try:
        first.stdin.write("n\n")            # answers "Install it now?" on a Mac without the driver; ignored otherwise
        first.stdin.flush()

        def answers():
            for _ in range(40):
                try:
                    with urllib.request.urlopen("http://127.0.0.1:%d/api/state" % port, timeout=2) as r:
                        state = json.loads(r.read())
                    return None if state["mode"] == "mock" and state["connected"] else "unexpected state: %r" % state
                except OSError:
                    if first.poll() is not None:
                        return "launcher exited with code %d: %s" % (first.returncode, first.stdout.read().strip()[-200:])
                    time.sleep(0.25)
            return "panel did not answer within 10 s"
        if not rec.check("INS-029", answers):
            return rec.record("INS-030", "notrun", "the first start failed (INS-029)")

        def second():
            again = subprocess.run(["bash", launcher, "--mock"], env=env, input="n\n", timeout=30,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
            if again.returncode != 0:
                return "second start exited with code %d" % again.returncode
            if "already running" not in again.stdout:
                return "second start did not report the running panel: " + again.stdout.strip()[-160:]
            return None if first.poll() is None else "the first panel stopped"
        rec.check("INS-030", second)
    finally:
        try:
            os.killpg(first.pid, signal.SIGTERM)
        except OSError:
            pass

    def state_of(p):
        with urllib.request.urlopen("http://127.0.0.1:%d/api/state" % p, timeout=2) as r:
            return json.loads(r.read())

    def wait_for_version(p, version, seconds):
        deadline = time.time() + seconds
        while time.time() < deadline:
            try:
                if state_of(p).get("version") == version:
                    return True
            except (OSError, ValueError, http.client.HTTPException):      # includes a panel cut off in mid-answer
                pass
            time.sleep(0.25)
        return False

    def replaces_older_copy():
        port2 = 8794
        env2 = dict(os.environ, VSA_PORT=str(port2), VSA_NO_OPEN="1")
        old_code = ("import sys; sys.path.insert(0, %r); import virtualsafeaudiomidi_gui as g; g.VERSION = '0.0.1'; "
                    "sys.argv = ['panel', '--mock', '--port', '%d', '--data-dir', %r]; g.main()"
                    % (os.path.join(ROOT, "gui"), port2, tempfile.mkdtemp()))
        old = subprocess.Popen([sys.executable, "-c", old_code], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        new = None
        try:
            if not wait_for_version(port2, "0.0.1", 10):
                return "could not start the stand-in for an older panel"
            new = subprocess.Popen(["bash", launcher, "--mock", "--data-dir", tempfile.mkdtemp()], env=env2, stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, start_new_session=True)
            new.stdin.write("y\n")
            new.stdin.flush()
            if not wait_for_version(port2, gui.VERSION, 20):
                return "the new copy did not take over the port"
            return None if old.poll() is not None else "the older copy is still running"
        finally:
            old.kill()
            if new:
                try:
                    os.killpg(new.pid, signal.SIGTERM)
                except OSError:
                    pass
    rec.check("INS-039", replaces_older_copy)

    def refuses_foreign_program():
        port3 = 8795
        other = subprocess.Popen([sys.executable, "-m", "http.server", str(port3), "--bind", "127.0.0.1"], cwd=tempfile.mkdtemp(),
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(40):
                if gui.check_running(port3) == "foreign":
                    break
                time.sleep(0.25)
            else:
                return "could not start the stand-in for another program"
            run = subprocess.run(["bash", launcher, "--mock"], env=dict(os.environ, VSA_PORT=str(port3), VSA_NO_OPEN="1"), input="\n",
                                 timeout=30, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
            if "being used by another program" not in run.stdout:
                return "launcher said: " + run.stdout.strip()[-160:]
            return None if run.returncode != 0 else "launcher reported success"
        finally:
            other.kill()
    rec.check("INS-040", refuses_foreign_program)


def run_c_harness(rec, ids, sanitizer_id, test_dir, sources, includes):
    """Builds and runs one of the C harnesses (driver or MIDI helper), then once more under the sanitizers."""
    cc = shutil.which("gcc") or shutil.which("cc") or shutil.which("clang")
    base = [cc, "-std=c11", "-D_GNU_SOURCE", "-Wno-multichar"] + ["-I" + i for i in includes] + sources + ["-lm", "-lpthread"] if cc else None
    why = "no C compiler found" if not cc else ""
    out_dir = tempfile.mkdtemp()

    plain = os.path.join(out_dir, "harness")
    if cc and sh(base + ["-o", plain], cwd=test_dir)[0] != 0:
        why = "harness did not compile on this machine (it is written for Linux; see README)"
    if why:
        for test_id in sorted(ids | {sanitizer_id}):
            rec.record(test_id, "notrun", why)
        return
    rc, out = sh([plain], cwd=test_dir)
    record_harness_output(rec, out, ids, "not reached: an earlier case in the harness failed")

    san = os.path.join(out_dir, "harness_san")
    if sh(base + ["-g", "-fsanitize=address,undefined", "-o", san], cwd=test_dir)[0] != 0:
        return rec.record(sanitizer_id, "notrun", "compiler on this machine has no sanitizer support")
    rc, out = sh([san], cwd=test_dir, env=dict(os.environ, ASAN_OPTIONS="detect_leaks=0"))
    bad = [l for l in out.splitlines() if "runtime error" in l or "AddressSanitizer" in l or l.startswith("FAIL")]
    rec.record(sanitizer_id, "fail" if (rc != 0 or bad) else "pass", bad[0] if bad else ("exit code %d" % rc if rc else ""))


def run_python_harness(rec, script, ids, needs=None):
    if needs:
        try:
            __import__(needs)
        except ImportError:
            for test_id in sorted(ids):
                rec.record(test_id, "notrun", "needs the Python package '%s' on this machine" % needs)
            return
    rc, out = sh([sys.executable, script], timeout=600)
    record_harness_output(rec, out, ids, "harness stopped before this case: " + (out.strip().splitlines() or ["no output"])[-1][:120])


# ------------------------------------------------------------------ Mac runner

TEST_UID = "stp-test"


def system_devices():
    """Audio devices as macOS reports them: [{name, in, out, maker}]."""
    rc, out = sh(["system_profiler", "SPAudioDataType", "-json"], timeout=60)
    found = []

    def walk(node):
        if isinstance(node, dict):
            if "_name" in node and any(k.startswith("coreaudio_device_") or k.startswith("coreaudio_input") or k.startswith("coreaudio_output") for k in node):
                found.append({"name": node["_name"],
                              "in": int(node.get("coreaudio_device_input", 0) or 0),
                              "out": int(node.get("coreaudio_device_output", 0) or 0),
                              "maker": str(node.get("coreaudio_device_manufacturer", ""))})
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)
    walk(json.loads(out[out.index("{"):]))
    return found


def crash_reports_since(timestamp):
    hits = []
    for folder in ("/Library/Logs/DiagnosticReports", os.path.expanduser("~/Library/Logs/DiagnosticReports")):
        try:
            names = os.listdir(folder)
        except OSError:
            continue
        for name in names:
            low = name.lower()
            if ("coreaudiod" in low or "core-audio-driver" in low or "core audio driver" in low) and \
                    os.path.getmtime(os.path.join(folder, name)) > timestamp:
                hits.append(name)
    return hits


class MacContext:
    """What the Mac tests touch. The simulated variant lets the test flow itself be checked off-Mac."""

    def __init__(self, simulate):
        self.simulate = simulate
        self.backend = gui.MockBackend() if simulate else gui.CoreAudioBackend()

    def devices(self):
        return gui.parse_config(self.backend.get_config())

    def listed(self):
        if self.simulate:
            return [{"name": d["name"], "in": d["channels"], "out": d["channels"], "maker": "VirtualSafeAudio"} for d in self.devices()]
        return system_devices()

    def coreaudiod_pid(self):
        if self.simulate:
            return "1"
        return sh(["pgrep", "-x", "coreaudiod"])[1].strip()

    def wait_for(self, predicate, timeout=8.0):
        deadline = time.time() + (0.2 if self.simulate else timeout)
        while True:
            listed = self.listed()
            if predicate(listed):
                return True, listed
            if time.time() > deadline:
                return False, listed
            time.sleep(1.0)


def describe(listed):
    return ", ".join("%s (%d in/%d out)" % (d["name"], d["in"], d["out"]) for d in listed if d["maker"] == "VirtualSafeAudio") or "no VirtualSafeAudio devices"


def run_mac_build(rec):
    binary = os.path.join(BUILT_BUNDLE, "Contents", "MacOS", "VirtualSafeAudio")
    rec.check("INS-005", lambda: None if sh("xcode-select -p")[0] == 0 and sh("clang --version")[0] == 0
              else "command line tools missing: run xcode-select --install")

    def build():
        rc, out = sh("./build.sh")
        if rc != 0:
            return "build.sh failed: " + " / ".join(out.strip().splitlines()[-3:])
        missing = [p for p in (os.path.join(BUILT_BUNDLE, "Contents", "Info.plist"), binary) if not os.path.exists(p)]
        return "missing after build: " + ", ".join(missing) if missing else None
    if not rec.check("INS-006", build):
        for test_id in ("INS-007", "INS-008", "INS-009"):
            rec.record(test_id, "notrun", "build failed (INS-006)")
        return

    def archs():
        found = sh(["lipo", "-archs", binary])[1].split()
        return None if {"arm64", "x86_64"} <= set(found) else "architectures: " + " ".join(found)
    rec.check("INS-007", archs)
    rec.check("INS-008", lambda: None if sh(["codesign", "--verify", "--strict", BUILT_BUNDLE])[0] == 0
              else sh(["codesign", "--verify", "--strict", BUILT_BUNDLE])[1].strip())
    rec.check("INS-009", lambda: None if "_VirtualSafeAudio_Create" in sh(["nm", "-gU", binary])[1] else "symbol not exported")


def run_mac_installed(rec, ctx, started):
    installed_ids = ["INS-011", "INS-012", "INS-013", "INS-019", "CFG-013", "CFG-014", "CFG-015", "CFG-016", "CFG-017", "CFG-018",
                     "CFG-019", "CFG-020", "CFG-027", "MTR-005", "MTR-006", "API-023", "API-024", "API-025", "ROB-004", "ROB-005"]
    if not ctx.simulate and not os.path.isdir(HAL_BUNDLE):
        for test_id in installed_ids:
            rec.record(test_id, "notrun", "driver is not installed: run ./install.sh (INS-010) and run this again")
        return

    if not ctx.simulate:
        rec.check("INS-011", lambda: None if os.stat(HAL_BUNDLE).st_uid == 0 else "bundle is not owned by root")
        rec.check("INS-012", lambda: None if ctx.coreaudiod_pid() else "coreaudiod is not running")

    # everything below talks to the driver; without the bridge none of it can run
    original_text = [None]

    def bridge():
        original_text[0] = ctx.backend.get_config()
        gui.parse_config(original_text[0])
    if not rec.check("CFG-013", bridge):
        for test_id in installed_ids:
            if test_id not in rec.items:
                rec.record(test_id, "notrun", "the bridge to the driver failed (CFG-013)")
        return
    original = gui.parse_config(original_text[0])
    original_lines = sorted(original_text[0].strip().splitlines())

    def apply(extra):
        ctx.backend.set_config(gui.format_config(original + extra))

    def test_device(name, channels):
        return [{"uid": TEST_UID, "name": name, "channels": channels, "sampleRate": 48000}]

    def has(name, channels):
        return lambda listed: any(d["name"] == name and d["in"] == channels and d["out"] == channels for d in listed)

    try:
        if not ctx.simulate:
            def configured_are_listed():
                ok, listed = ctx.wait_for(lambda l: all(has(d["name"], d["channels"])(l) for d in original))
                return None if ok else "driver has %s; macOS lists %s" % (
                    ", ".join("%s (%d ch)" % (d["name"], d["channels"]) for d in original) or "no devices", describe(listed))
            rec.check("INS-013", configured_are_listed)
            installed_at = os.path.getmtime(HAL_BUNDLE)
            rec.check("INS-019", lambda: ("found: " + ", ".join(crash_reports_since(installed_at))) if crash_reports_since(installed_at) else None)

        if len(original) >= gui.MAX_DEVICES:
            for test_id in ("CFG-014", "CFG-015", "CFG-016", "CFG-017", "CFG-018", "CFG-019", "CFG-027", "MTR-005", "MTR-006", "API-024", "ROB-004"):
                rec.record(test_id, "notrun", "all 16 device slots are in use; remove one device and run again")
        else:
            def step(test_id, name, channels):
                def run():
                    apply(test_device(name, channels))
                    ok, listed = ctx.wait_for(has(name, channels))
                    return None if ok else "macOS lists: " + describe(listed)
                return rec.check(test_id, run)

            pid_before = ctx.coreaudiod_pid()
            step("CFG-014", "STP test device", 8)

            def renamed():
                apply(test_device("STP renamed", 8))
                ok, listed = ctx.wait_for(lambda l: has("STP renamed", 8)(l) and not any(d["name"] == "STP test device" for d in l))
                return None if ok else "macOS lists: " + describe(listed)
            rec.check("CFG-015", renamed)
            step("CFG-016", "STP renamed", 16)
            step("CFG-017", "STP renamed", 64)

            def removed():
                apply([])
                ok, listed = ctx.wait_for(lambda l: not any(d["name"] == "STP renamed" for d in l) and
                                          all(has(d["name"], d["channels"])(l) for d in original))
                return None if ok else "macOS lists: " + describe(listed)
            rec.check("CFG-018", removed)

            def sixteen():
                extra = [{"uid": "stp-fill-%d" % i, "name": "STP fill %d" % i, "channels": 2, "sampleRate": 48000}
                         for i in range(gui.MAX_DEVICES - len(original))]
                apply(extra)
                count = len(ctx.devices())
                ok, listed = ctx.wait_for(lambda l: all(any(d["name"] == e["name"] for d in l) for e in extra), timeout=15)
                apply([])
                if count != gui.MAX_DEVICES:
                    return "driver reports %d devices" % count
                return None if ok else "macOS lists: " + describe(listed)
            rec.check("CFG-019", sixteen)
            rec.check("CFG-027", lambda: None if pid_before and ctx.coreaudiod_pid() == pid_before
                      else "coreaudiod process ID changed from %s to %s" % (pid_before, ctx.coreaudiod_pid()))

            if not ctx.simulate:
                run_mac_meters(rec, ctx, apply, test_device)
                run_mac_panel(rec, ctx, original)

            def rapid():
                pid = ctx.coreaudiod_pid()
                for _ in range(15):
                    apply(test_device("STP flip", 2))
                    apply([])
                time.sleep(0 if ctx.simulate else 2)
                if sorted(ctx.backend.get_config().strip().splitlines()) != original_lines:
                    return "device list differs from the original after the changes"
                return None if ctx.coreaudiod_pid() == pid else "coreaudiod restarted (was %s, now %s)" % (pid, ctx.coreaudiod_pid())
            rec.check("ROB-004", rapid)
    finally:
        def restored():
            ctx.backend.set_config(original_text[0])
            time.sleep(0 if ctx.simulate else 1)
            now = sorted(ctx.backend.get_config().strip().splitlines())
            return None if now == original_lines else "driver now has: %r" % now
        rec.check("CFG-020", restored)

    if not ctx.simulate:
        rec.check("ROB-005", lambda: ("found: " + ", ".join(crash_reports_since(started))) if crash_reports_since(started) else None)


def run_mac_meters(rec, ctx, apply, test_device):
    name = "STP meter device"
    apply(test_device(name, 2))
    ok, _ = ctx.wait_for(lambda l: any(d["name"] == name for d in l))
    if not ok:
        rec.record("MTR-005", "notrun", "test device did not appear in macOS")
        rec.record("MTR-006", "notrun", "test device did not appear in macOS")
        return apply([])

    def peak_now():
        values = gui.parse_meters(ctx.backend.get_meters()).get(TEST_UID, [])
        return max(values[0::2]) if values else 0.0

    speech = subprocess.Popen(["say", "-a", name, "one two three four five six seven eight nine ten"],
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)

    def moved():
        best, deadline = 0.0, time.time() + 12
        while time.time() < deadline and (speech.poll() is None or best == 0.0):
            best = max(best, peak_now())
            if speech.poll() is not None:
                break
            time.sleep(0.05)
        out = speech.communicate(timeout=30)[0]
        if speech.returncode != 0:
            return "`say -a` failed: " + out.strip()[:150]
        return None if best > 0.01 else "highest peak seen: %.4f" % best
    rec.check("MTR-005", moved)

    def back_to_zero():
        time.sleep(1.5)
        values = gui.parse_meters(ctx.backend.get_meters()).get(TEST_UID, [])
        return None if values and max(values) == 0 else "values after stop: %r" % values[:4]
    rec.check("MTR-006", back_to_zero)
    apply([])


def run_mac_panel(rec, ctx, original):
    port = 8791
    base = "http://127.0.0.1:%d" % port
    server = subprocess.Popen([sys.executable, os.path.join(ROOT, "gui", "virtualsafeaudiomidi_gui.py"), "--keep-audio", "--port", str(port),
                               "--data-dir", tempfile.mkdtemp()], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    def get(path):
        with urllib.request.urlopen(base + path, timeout=5) as r:
            return json.loads(r.read())
    try:
        def connected():
            for _ in range(20):
                try:
                    state = get("/api/state")
                    break
                except OSError:
                    time.sleep(0.25)
            else:
                return "server did not answer on port %d" % port
            if not state["connected"]:
                return "not connected: %s" % state["error"]
            return None if [d["uid"] for d in state["devices"]] == [d["uid"] for d in ctx.devices()] else "device lists differ"
        if not rec.check("API-023", connected):
            rec.record("API-024", "notrun", "panel server is not connected to the driver (API-023)")
            rec.record("API-025", "notrun", "panel server is not connected to the driver (API-023)")
            return

        def post(devices):
            req = urllib.request.Request(base + "/api/config", data=json.dumps({"devices": devices}).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10) as r:
                return json.loads(r.read())

        def through_panel():
            try:
                post(original + [{"uid": "stp-http", "name": "STP via panel"}])
                text = ctx.backend.get_config()
                return None if "stp-http\t2\t" in text else "driver list is: %r" % text
            finally:
                post(original)
        rec.check("API-024", through_panel)

        def stream():
            uids = sorted(d["uid"] for d in ctx.devices())
            with urllib.request.urlopen(base + "/api/meters", timeout=5) as r:
                events = []
                while len(events) < 3:
                    line = r.readline().decode()
                    if line.startswith("data: "):
                        events.append(json.loads(line[6:]))
            return None if all(sorted(e) == uids for e in events) else "event keys: %r" % sorted(events[-1])
        rec.check("API-025", stream)
    finally:
        server.terminate()


def run_mac_midi(rec):
    """Virtual MIDI ports on the real Mac: build the helper, run it with test ports, and look at
    them from the outside with build/miditest, the way another MIDI app would see them."""
    later = ["MID-022", "MID-023", "MID-024", "MID-025", "MID-026"]
    tool = os.path.join(ROOT, "build", "miditest")

    def build():
        rc, out = sh("./build.sh midi")
        if rc != 0:
            return "build.sh midi failed: " + " / ".join(out.strip().splitlines()[-3:])
        missing = [p for p in (os.path.join(ROOT, "build", "vsamidi"), tool) if not os.path.exists(p)]
        return "missing after build: " + ", ".join(missing) if missing else None
    if not rec.check("MID-021", build):
        for test_id in later:
            rec.record(test_id, "notrun", "build failed (MID-021)")
        return

    def listing():
        """[(SRC|DST, unique id, name)] for every MIDI endpoint macOS knows."""
        rows = [line.split("\t", 2) for line in sh([tool, "list"])[1].splitlines()]
        return [tuple(r) for r in rows if len(r) == 3]

    def sides(name):
        return {kind: uid for kind, uid, n in listing() if n == name}

    a = {"uid": "stp-midi-a", "name": "STP MIDI A"}
    b = {"uid": "stp-midi-b", "name": "STP MIDI B"}
    helper = gui.MidiHelper()
    try:
        def appears():
            helper.start()
            helper.set_ports([a])
            time.sleep(0.5)
            found = sides("STP MIDI A")
            return None if sorted(found) == ["DST", "SRC"] else "macOS lists it as: %r" % sorted(found)
        if not rec.check("MID-022", appears):
            for test_id in later[1:]:
                rec.record(test_id, "notrun", "the test port did not appear (MID-022)")
            return

        def loop():
            rc, out = sh([tool, "loop", "STP MIDI A", "100"], timeout=60)
            return None if rc == 0 and "received=100 out_of_order=0" in out else out.strip()[-160:]
        rec.check("MID-023", loop)

        identity = sides("STP MIDI A")

        def added():
            helper.set_ports([a, b])
            time.sleep(0.5)
            if sorted(sides("STP MIDI B")) != ["DST", "SRC"]:
                return "second port not listed on both sides"
            return None if sides("STP MIDI A") == identity else "first port's unique IDs changed: %r -> %r" % (identity, sides("STP MIDI A"))
        rec.check("MID-024", added)

        def renamed():
            helper.set_ports([dict(a, name="STP MIDI renamed"), b])
            time.sleep(0.5)
            if sides("STP MIDI A"):
                return "the old name is still listed"
            return None if sides("STP MIDI renamed") == identity else "after rename: %r, before: %r" % (sides("STP MIDI renamed"), identity)
        rec.check("MID-025", renamed)
    except gui.MidiError as e:
        for test_id in later:
            if test_id not in rec.items:
                rec.record(test_id, "fail", str(e))
    finally:
        helper.stop()

    def gone():
        time.sleep(0.5)
        left = sorted({n for _, _, n in listing() if n.startswith("STP MIDI")})
        return "still listed: " + ", ".join(left) if left else None
    if "MID-026" not in rec.items:
        rec.check("MID-026", gone)


def run_mac_uninstalled(rec):
    rec.check("INS-021", lambda: "bundle is still there" if os.path.exists(HAL_BUNDLE) else None)

    def none_listed():
        time.sleep(3)
        mine = [d["name"] for d in system_devices() if d["maker"] == "VirtualSafeAudio"]
        return "still listed: " + ", ".join(mine) if mine else None
    rec.check("INS-022", none_listed)
    rec.check("INS-023", lambda: None if sh(["pgrep", "-x", "coreaudiod"])[1].strip() else "coreaudiod is not running")


# ------------------------------------------------------------------ the document

MARK = {"pass": "✅ PASS", "fail": "❌ FAIL", "notrun": "⬜ NOT RUN"}


def cell(text):
    return str(text).replace("|", "\\|").replace("\n", " ")


def result_cell(results, test_id):
    r = results.get(test_id)
    if not r or r["status"] == "notrun":
        return MARK["notrun"]
    return MARK[r["status"]] + ((" " + cell(r["note"])) if r["status"] == "fail" and r["note"] else "")


def tally(cases, results):
    counts = {"total": len(cases), "pass": 0, "fail": 0, "notrun": 0}
    for c in cases:
        counts[results.get(c["id"], {}).get("status", "notrun")] += 1
    return counts


def write_document(results):
    cases = all_cases()
    today = datetime.date.today().isoformat()
    total = tally(cases, results)
    here = [c for c in cases if c["how"] in HERE_KINDS]
    mac_auto = [c for c in cases if c["how"] in MAC_AUTO_KINDS]
    manual = [c for c in cases if c["how"] == "manual"]
    L = []
    add = L.append

    add("# VirtualSafeAudioMIDI — Software Test Plan")
    add("")
    add("| | |")
    add("|---|---|")
    add("| Product | VirtualSafeAudioMIDI %s (audio driver, MIDI helper, control panel) |" % gui.VERSION)
    add("| Document | STP v0.4, generated %s by `stp/stp.py` |" % today)
    add("| Tests | %d in %d chapters |" % (total["total"], len(CHAPTERS)))
    add("| Status | %d pass, %d fail, %d not run |" % (total["pass"], total["fail"], total["notrun"]))
    add("")
    add("## About this plan")
    add("")
    add("Tests are split by who can run them:")
    add("")
    add("| Kind | Count | Where it runs | How |")
    add("|---|---|---|---|")
    add("| Automated | %d | Any machine (Linux for the two C harnesses) | `python3 stp/stp.py run` |" % len(here))
    add("| Mac runner | %d | Your Mac, driver installed | the same command, run on the Mac |" % len(mac_auto))
    add("| Manual | %d | Your Mac, by hand | follow the procedure, then `python3 stp/stp.py set <ID> pass` or `fail \"what happened\"` |" % len(manual))
    add("")
    add("The automated tests exercise the real driver source, the real MIDI helper source and the real panel code, but against "
        "stand-ins for macOS: mock Core Audio headers for the driver, a pretend CoreMIDI for the helper, a mock driver for "
        "the panel. They prove the logic. They cannot prove that macOS loads the driver, that real MIDI passes through the "
        "ports, that apps accept either, or how it sounds. Those are the Mac runner and manual tests, and until they are run "
        "the product is untested where it matters most.")
    add("")
    add("Result marks: ✅ PASS, ❌ FAIL (with a note), ⬜ NOT RUN. Results are stored in `stp/results.json`; "
        "this document is regenerated from them, so do not edit results here by hand.")
    add("")
    add("The app makes stereo devices only. The driver underneath can carry up to 64 channels per device, and the Mac runner "
        "still exercises that directly (CFG-014 to CFG-017) with its own test device, because a driver that handles the larger "
        "case correctly is a safer base for the stereo one.")
    add("")
    add("Order on the Mac: `python3 stp/stp.py run` (build checks) → INS-010 install by hand → `python3 stp/stp.py run` again "
        "(everything that needs the driver) → manual tests, chapter by chapter (`python3 stp/stp.py pending` lists what is left) → "
        "INS-020 uninstall → `python3 stp/stp.py run --after-uninstall`. The Mac runner adds and removes its own test devices "
        "and MIDI ports (names starting `STP`) and puts your device layout back when it finishes; it does not touch your existing "
        "devices or ports. The MIDI part of the runner (MID-021 to MID-026) needs no driver and runs even before the install.")
    add("")

    for number, prefix, title, blurb in CHAPTERS:
        chapter = [c for c in cases if c["id"].startswith(prefix + "-")]
        counts = tally(chapter, results)
        add("## Chapter %s — %s" % (number, title))
        add("")
        add("%s %d tests: %d pass, %d fail, %d not run." % (blurb, counts["total"], counts["pass"], counts["fail"], counts["notrun"]))
        add("")
        auto = [c for c in chapter if c["how"] in HERE_KINDS]
        mac = [c for c in chapter if c["how"] not in HERE_KINDS]
        if auto:
            add("### %s.1 Automated" % number)
            add("")
            add("| ID | Test | Run by | Result |")
            add("|---|---|---|---|")
            for c in auto:
                add("| %s | %s | %s | %s |" % (c["id"], cell(c["title"]), HOW_LABEL[c["how"]], result_cell(results, c["id"])))
            add("")
        if mac:
            add("### %s.%d On the Mac" % (number, 2 if auto else 1))
            add("")
            add("| ID | Test | Procedure | Expected | Run by | Result |")
            add("|---|---|---|---|---|---|")
            for c in mac:
                add("| %s | %s | %s | %s | %s | %s |" % (c["id"], cell(c["title"]), cell(c["procedure"]), cell(c["expected"]),
                                                         HOW_LABEL[c["how"]], result_cell(results, c["id"])))
            add("")

    number = str(len(CHAPTERS) + 1)
    add("## Chapter %s — Results" % number)
    add("")
    add("### %s.1 By chapter" % number)
    add("")
    add("| Chapter | Total | ✅ Pass | ❌ Fail | ⬜ Not run |")
    add("|---|---|---|---|---|")
    for n, prefix, title, _ in CHAPTERS:
        k = tally([c for c in cases if c["id"].startswith(prefix + "-")], results)
        add("| %s. %s | %d | %d | %d | %d |" % (n, title, k["total"], k["pass"], k["fail"], k["notrun"]))
    add("| **Total** | **%d** | **%d** | **%d** | **%d** |" % (total["total"], total["pass"], total["fail"], total["notrun"]))
    add("")
    add("### %s.2 By who runs it" % number)
    add("")
    add("| Kind | Total | ✅ Pass | ❌ Fail | ⬜ Not run |")
    add("|---|---|---|---|---|")
    for label, group in (("Automated", here), ("Mac runner", mac_auto), ("Manual", manual)):
        k = tally(group, results)
        add("| %s | %d | %d | %d | %d |" % (label, k["total"], k["pass"], k["fail"], k["notrun"]))
    add("")
    executed = total["pass"] + total["fail"]
    add("**Executed:** %d of %d (%.1f%%).  " % (executed, total["total"], 100.0 * executed / total["total"]))
    add("**Pass rate of executed tests:** %s.  " % ("%.1f%% (%d of %d)" % (100.0 * total["pass"] / executed, total["pass"], executed) if executed else "nothing executed yet"))
    add("**Waiting for the Mac:** %d runner tests and %d manual tests." % (tally(mac_auto, results)["notrun"], tally(manual, results)["notrun"]))
    add("")
    add("### %s.3 Failures" % number)
    add("")
    failures = [c for c in cases if results.get(c["id"], {}).get("status") == "fail"]
    if failures:
        add("| ID | Test | What happened | Where | Date |")
        add("|---|---|---|---|---|")
        for c in failures:
            r = results[c["id"]]
            add("| %s | %s | %s | %s | %s |" % (c["id"], cell(c["title"]), cell(r["note"] or "no note recorded"), cell(r["env"]), r["date"]))
    else:
        add("None recorded.")
    add("")
    add("### %s.4 Run log" % number)
    add("")
    runs = {}
    for c in cases:
        r = results.get(c["id"])
        if r and r["status"] != "notrun":
            key = (r["date"], r["env"], "Manual" if c["how"] == "manual" else "Automated")
            runs.setdefault(key, {"pass": 0, "fail": 0})[r["status"]] += 1
    if runs:
        add("| Date | Environment | Kind | Executed | ✅ Pass | ❌ Fail |")
        add("|---|---|---|---|---|---|")
        for (date, env, kind), k in sorted(runs.items()):
            add("| %s | %s | %s | %d | %d | %d |" % (date, cell(env), kind, k["pass"] + k["fail"], k["pass"], k["fail"]))
    else:
        add("No runs recorded yet.")
    add("")
    add("### %s.5 Not run, and why" % number)
    add("")
    add("Every ⬜ in this document needs a real Mac: the driver has to be compiled against Apple's SDK, signed, loaded by "
        "`coreaudiod`, and used by real applications; the MIDI helper has to open real CoreMIDI ports that real apps connect to. The environment the automated tests were written "
        "and run in is a Linux container with no network access, no macOS, and no audio hardware, so none of that can "
        "happen there. The Mac runner exists so that as much as possible of that gap is one command on your side rather "
        "than a checklist.")
    add("")
    skipped = [c for c in cases if results.get(c["id"], {}).get("status") == "notrun" and results[c["id"]].get("note")]
    if skipped:
        add("Tests that were attempted and skipped, with the reason:")
        add("")
        add("| ID | Reason | Where | Date |")
        add("|---|---|---|---|")
        for c in skipped:
            r = results[c["id"]]
            add("| %s | %s | %s | %s |" % (c["id"], cell(r["note"]), cell(r["env"]), r["date"]))
        add("")

    with open(DOCUMENT, "w", encoding="utf-8") as f:
        f.write("\n".join(L).rstrip() + "\n")
    return total


# ------------------------------------------------------------------ commands

def cmd_run(args):
    simulate = "--simulate" in args
    rec = Recorder(simulate)
    cases = all_cases()
    ids = lambda how: {c["id"] for c in cases if c["how"] == how}
    started = time.time()

    if not simulate:
        run_static(rec)
        if IS_MAC:
            print("The C harnesses are built against stand-in headers and run on Linux; keeping their stored results.")
        else:
            run_c_harness(rec, ids("driver"), "ROB-003", os.path.join(ROOT, "driver", "test"), ["test_driver.c"], ["stubs"])
            run_c_harness(rec, ids("midi"), "ROB-011", os.path.join(ROOT, "midi", "test"),
                          ["test_midi.c", "mock_coremidi.c"], ["stubs", "../../driver/test/stubs"])
        run_python_harness(rec, os.path.join(ROOT, "gui", "test_gui.py"), ids("panel"))
        run_python_harness(rec, os.path.join(ROOT, "gui", "test_browser.py"), ids("browser"), needs="playwright")

    if simulate:
        print("Simulated Mac run against the mock driver. Checks the runner's own flow; nothing is saved.")
        run_mac_installed(rec, MacContext(simulate=True), started)
    elif IS_MAC:
        if "--after-uninstall" in args:
            run_mac_uninstalled(rec)
        else:
            run_mac_build(rec)
            run_mac_installed(rec, MacContext(simulate=False), started)
            run_mac_midi(rec)
    else:
        print("Not on macOS: Mac runner tests left as they were.")

    counts = {s: sum(1 for r in rec.items.values() if r["status"] == s) for s in ("pass", "fail", "notrun")}
    print("\nThis run: %d pass, %d fail, %d skipped." % (counts["pass"], counts["fail"], counts["notrun"]))
    if simulate:
        return 1 if counts["fail"] else 0

    results = load_results()
    for test_id, entry in rec.items.items():
        # a skip never erases a real result recorded earlier, possibly on another machine
        if entry["status"] == "notrun" and results.get(test_id, {}).get("status") in ("pass", "fail"):
            continue
        results[test_id] = entry
    save_results(results)
    total = write_document(results)
    print("Overall: %d pass, %d fail, %d not run. Wrote %s" % (total["pass"], total["fail"], total["notrun"], os.path.basename(DOCUMENT)))
    return 1 if counts["fail"] else 0


def cmd_set(args):
    if len(args) < 2 or args[1] not in ("pass", "fail", "notrun"):
        sys.exit('usage: stp.py set <ID> pass|fail|notrun ["note"]')
    test_id = args[0].upper()
    case = next((c for c in all_cases() if c["id"] == test_id), None)
    if not case:
        sys.exit("No test with ID %s." % test_id)
    if case["how"] != "manual":
        sys.exit("%s is an automated test; its result comes from `stp.py run`." % test_id)
    note = " ".join(args[2:])
    if args[1] == "fail" and not note:
        sys.exit("A failed test needs a note saying what happened.")
    results = load_results()
    results[test_id] = {"status": args[1], "note": note, "date": datetime.date.today().isoformat(), "env": environment()}
    save_results(results)
    total = write_document(results)
    print("%s %s: %s. Overall: %d pass, %d fail, %d not run." % (MARK[args[1]], test_id, case["title"], total["pass"], total["fail"], total["notrun"]))
    return 0


def cmd_pending(args):
    results = load_results()
    left = [c for c in all_cases() if c["how"] == "manual" and results.get(c["id"], {}).get("status", "notrun") == "notrun"]
    for c in left:
        print("%s  %s\n    Do:     %s\n    Expect: %s\n" % (c["id"], c["title"], c["procedure"], c["expected"]))
    print("%d manual tests without a result." % len(left))
    return 0


def main():
    args = sys.argv[1:]
    command = args[0] if args else ""
    if command == "run":
        sys.exit(cmd_run(args[1:]))
    if command == "set":
        sys.exit(cmd_set(args[1:]))
    if command == "pending":
        sys.exit(cmd_pending(args[1:]))
    if command == "report":
        total = write_document(load_results())
        print("Wrote %s: %d pass, %d fail, %d not run." % (os.path.basename(DOCUMENT), total["pass"], total["fail"], total["notrun"]))
        sys.exit(0)
    print(__doc__)
    sys.exit(0 if command in ("", "help", "-h", "--help") else 2)


if __name__ == "__main__":
    main()
