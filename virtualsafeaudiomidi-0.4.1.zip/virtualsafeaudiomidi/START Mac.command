#!/bin/bash
# START Mac.command — double-click this in Finder to start VirtualSafeAudioMIDI.
#
# What it does, in order:
#   1. checks that Python 3 is really there
#   2. looks at what is already answering on the panel's port:
#        this same copy of the panel      -> just opens it in the browser
#        another copy or an older version -> says so and offers to replace it
#        some other program               -> says so and stops
#   3. otherwise starts the control panel and opens it
#
# It asks for nothing and installs nothing. What to use is chosen in the panel: audio and
# MIDI each have their own switch, and the audio driver has an install button there.
#
# Closing this window closes the app:
#   MIDI    the virtual MIDI ports go away. They exist only while the panel runs with MIDI on.
#   audio   the virtual audio devices leave macOS too, and come back at the next start,
#           unless "Keep devices when the app is closed" is ticked in the panel.
#
# Options, when run from Terminal:
#   ./START\ Mac.command --host 0.0.0.0     let other machines on your network open the panel
#   VSA_PORT=9000 ./START\ Mac.command      use another port
#   VSA_NO_OPEN=1 ./START\ Mac.command      do not open a browser tab

cd "$(dirname "$0")" || exit 1

PORT="${VSA_PORT:-8767}"
URL="http://127.0.0.1:$PORT"

# Close this window when the panel stops cleanly. macOS otherwise leaves it sitting on
# "[Process completed]", which looks like something went wrong. A window that stopped
# because of an error is left open on purpose: that is when there is something to read.
close_my_window() {
  [ -n "${VSA_NO_OPEN:-}" ] && return 0
  command -v osascript >/dev/null 2>&1 || return 0
  osascript >/dev/null 2>&1 <<'APPLESCRIPT'
tell application "Terminal"
  try
    close (first window whose frontmost is true) saving no
  end try
end tell
APPLESCRIPT
}

stop_with_message() {
  echo
  echo "  Press return to close this window."
  read -r _
  exit 1
}

have_developer_tools() { xcode-select -p >/dev/null 2>&1; }

# On a Mac, /usr/bin/python3 exists even when nothing is installed: it is a stub that pops
# up the developer-tools installer. So "is python3 on the PATH" is not enough.
have_python() {
  local where
  where="$(command -v python3)" || return 1
  if [ "$(uname)" = "Darwin" ] && [ "$where" = "/usr/bin/python3" ] && ! have_developer_tools; then
    return 1
  fi
  return 0
}

echo
echo "  VirtualSafeAudioMIDI"

if ! have_python; then
  echo
  echo "  Python 3 is not installed."
  echo "  Run this in Terminal, wait for it to finish, then start again:"
  echo
  echo "      xcode-select --install"
  stop_with_message
fi

VERSION="$(python3 gui/virtualsafeaudiomidi_gui.py --version 2>/dev/null)"
echo "  version $VERSION"
echo

# ---- what is on our port already?
# Without this check, starting a freshly downloaded version while an old one is still running
# would quietly open the OLD panel, and nothing you had just fixed would seem to be fixed.
RUNNING="$(python3 gui/virtualsafeaudiomidi_gui.py --port "$PORT" --check-running 2>/dev/null)"
case "$RUNNING" in
  same)
    echo "  The control panel is already running at $URL"
    if [ -z "${VSA_NO_OPEN:-}" ] && command -v open >/dev/null 2>&1; then open "$URL"; fi
    close_my_window
    exit 0
    ;;
  other*)
    IFS=$'\t' read -r _ other_version other_folder other_pid <<<"$RUNNING"
    echo "  A different copy of the control panel is already running:"
    echo "      version $other_version, from $other_folder"
    echo "  This copy is version $VERSION, in $PWD"
    echo
    echo "  Stopping the other copy also removes its virtual MIDI ports until this one is up."
    printf "  Stop the other copy and start this one instead? [Y/n] "
    read -r answer
    case "$answer" in
      n|N|no|No|NO)
        echo
        echo "  Left as it is. The panel in your browser is still the other copy."
        stop_with_message
        ;;
    esac
    if [ -n "$other_pid" ]; then kill "$other_pid" 2>/dev/null; else pkill -f virtualsafeaudiomidi_gui.py 2>/dev/null; fi
    for _ in 1 2 3 4 5 6 7 8 9 10; do
      [ "$(python3 gui/virtualsafeaudiomidi_gui.py --port "$PORT" --check-running 2>/dev/null)" = "none" ] && break
      sleep 0.5
    done
    echo
    ;;
  foreign)
    echo "  Port $PORT is being used by another program, so the control panel cannot start there."
    echo "  Start it on another port from Terminal, for example:"
    echo
    echo "      VSA_PORT=8768 ./START\\ Mac.command"
    stop_with_message
    ;;
esac

echo "  Control panel:  $URL"
echo "  To stop it:     close this window, or press control-C"
echo "  Stopping it removes the virtual MIDI ports, and the virtual audio devices too"
echo "  unless \"Keep devices when the app is closed\" is ticked in the panel."
echo

ARGS=(--port "$PORT")
[ -z "${VSA_NO_OPEN:-}" ] && ARGS+=(--open)

python3 gui/virtualsafeaudiomidi_gui.py "${ARGS[@]}" "$@"
status=$?

if [ $status -ne 0 ] && [ $status -ne 130 ]; then
  echo
  echo "  The control panel stopped with an error (code $status)."
  stop_with_message
else
  close_my_window
fi
