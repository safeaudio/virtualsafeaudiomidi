#!/bin/bash
# Builds what VirtualSafeAudioMIDI needs. Requires the Xcode command line tools:
#     xcode-select --install
#
#   ./build.sh            everything
#   ./build.sh driver     only the audio driver   -> build/VirtualSafeAudio.driver
#   ./build.sh midi       only the MIDI helper    -> build/vsamidi (and build/miditest, used by the tests)
set -euo pipefail
cd "$(dirname "$0")"

ARCH=(-arch arm64 -arch x86_64 -mmacosx-version-min=11.0)     # universal: Apple silicon + Intel
WARN=(-Wall -Wextra -Wno-unused-parameter)

build_driver() {
  local out=build/VirtualSafeAudio.driver
  rm -rf "$out"
  mkdir -p "$out/Contents/MacOS"
  clang -bundle -O2 -std=c11 "${WARN[@]}" "${ARCH[@]}" \
        -framework CoreAudio -framework CoreFoundation \
        -o "$out/Contents/MacOS/VirtualSafeAudio" driver/virtualsafeaudio.c
  cp driver/Info.plist "$out/Contents/Info.plist"
  # A project unzipped from a download carries macOS's "downloaded from the internet" mark on
  # every file, and cp carries it along. The built driver must not have it.
  xattr -cr "$out" 2>/dev/null || true
  # Ad-hoc signature: fine for a driver you build and run on your own Mac.
  # To hand the driver to other people, sign with a Developer ID and notarize instead.
  codesign --force --sign - "$out"
  echo "Built $out"
}

build_midi() {
  mkdir -p build
  # The helper uses CoreMIDI's classic packet calls, which Apple marks as deprecated in
  # favour of the MIDI 2.0 ones. They still work; the flag only silences the notice.
  for tool in vsamidi miditest; do
    clang -O2 -std=c11 "${WARN[@]}" -Wno-deprecated-declarations "${ARCH[@]}" \
          -framework CoreMIDI -framework CoreFoundation \
          -o "build/$tool" "midi/$tool.c"
  done
  echo "Built build/vsamidi"
}

case "${1:-all}" in
  driver) build_driver ;;
  midi)   build_midi ;;
  all)    build_driver; build_midi ;;
  *)      echo "usage: ./build.sh [all|driver|midi]"; exit 2 ;;
esac
