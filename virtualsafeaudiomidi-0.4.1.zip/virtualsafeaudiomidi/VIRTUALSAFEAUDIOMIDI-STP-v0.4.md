# VirtualSafeAudioMIDI — Software Test Plan

| | |
|---|---|
| Product | VirtualSafeAudioMIDI 0.4.1 (audio driver, MIDI helper, control panel) |
| Document | STP v0.4, generated 2026-10-01 by `stp/stp.py` |
| Tests | 234 in 8 chapters |
| Status | 120 pass, 0 fail, 114 not run |

## About this plan

Tests are split by who can run them:

| Kind | Count | Where it runs | How |
|---|---|---|---|
| Automated | 120 | Any machine (Linux for the two C harnesses) | `python3 stp/stp.py run` |
| Mac runner | 34 | Your Mac, driver installed | the same command, run on the Mac |
| Manual | 80 | Your Mac, by hand | follow the procedure, then `python3 stp/stp.py set <ID> pass` or `fail "what happened"` |

The automated tests exercise the real driver source, the real MIDI helper source and the real panel code, but against stand-ins for macOS: mock Core Audio headers for the driver, a pretend CoreMIDI for the helper, a mock driver for the panel. They prove the logic. They cannot prove that macOS loads the driver, that real MIDI passes through the ports, that apps accept either, or how it sounds. Those are the Mac runner and manual tests, and until they are run the product is untested where it matters most.

Result marks: ✅ PASS, ❌ FAIL (with a note), ⬜ NOT RUN. Results are stored in `stp/results.json`; this document is regenerated from them, so do not edit results here by hand.

The app makes stereo devices only. The driver underneath can carry up to 64 channels per device, and the Mac runner still exercises that directly (CFG-014 to CFG-017) with its own test device, because a driver that handles the larger case correctly is a safer base for the stereo one.

Order on the Mac: `python3 stp/stp.py run` (build checks) → INS-010 install by hand → `python3 stp/stp.py run` again (everything that needs the driver) → manual tests, chapter by chapter (`python3 stp/stp.py pending` lists what is left) → INS-020 uninstall → `python3 stp/stp.py run --after-uninstall`. The Mac runner adds and removes its own test devices and MIDI ports (names starting `STP`) and puts your device layout back when it finishes; it does not touch your existing devices or ports. The MIDI part of the runner (MID-021 to MID-026) needs no driver and runs even before the install.

## Chapter 1 — Install and uninstall

Building the driver, getting it into macOS, and getting it out again without leaving anything behind. 41 tests: 10 pass, 0 fail, 31 not run.

### 1.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| INS-001 | Build, install and uninstall scripts have no shell syntax errors | Static check | ✅ PASS |
| INS-002 | Bundle Info.plist is valid and consistent with the driver source and the panel (bundle ID, factory function, plug-in type) | Static check | ✅ PASS |
| INS-003 | All three scripts are executable | Static check | ✅ PASS |
| INS-004 | Install and uninstall act on the same bundle path | Static check | ✅ PASS |
| INS-028 | Start launcher has no shell syntax errors and is executable | Static check | ✅ PASS |
| INS-029 | Start launcher brings the control panel up and the panel answers (mock driver) | Static check | ✅ PASS |
| INS-030 | Starting the launcher a second time finds the running panel instead of starting another | Static check | ✅ PASS |
| INS-038 | The administrator step of the panel's install reads only a staged copy, never the project folder | Panel server harness | ✅ PASS |
| INS-039 | Starting a new copy while a different version is still running offers to replace it, and does | Static check | ✅ PASS |
| INS-040 | With some other program on its port, the launcher says so instead of opening that program | Static check | ✅ PASS |

### 1.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| INS-005 | Xcode command line tools are present | `xcode-select -p` and `clang --version` | Both exit 0 | Mac runner | ⬜ NOT RUN |
| INS-006 | Driver builds from source | `./build.sh` | Exit 0; `build/VirtualSafeAudio.driver` contains `Contents/Info.plist` and `Contents/MacOS/VirtualSafeAudio` | Mac runner | ⬜ NOT RUN |
| INS-007 | Built driver runs on both Apple silicon and Intel | `lipo -archs` on the built binary | Lists `arm64` and `x86_64` | Mac runner | ⬜ NOT RUN |
| INS-008 | Built bundle carries a valid signature | `codesign --verify --strict` on the built bundle | Exit 0 | Mac runner | ⬜ NOT RUN |
| INS-009 | Built binary exports the entry point macOS looks for | `nm -gU` on the built binary | `_VirtualSafeAudio_Create` is listed | Mac runner | ⬜ NOT RUN |
| INS-010 | Installer completes | In Terminal, from the project folder: `./install.sh`. Enter the admin password when asked. | Ends with the line starting `Installed.`; no error lines. All audio drops out for a moment and comes back. | Manual | ⬜ NOT RUN |
| INS-011 | Driver bundle is in the system plug-in folder, owned by root | Inspect `/Library/Audio/Plug-Ins/HAL/VirtualSafeAudio.driver` | Exists; owner is root | Mac runner | ⬜ NOT RUN |
| INS-012 | Core Audio is running after install | `pgrep -x coreaudiod` | A process ID is returned | Mac runner | ⬜ NOT RUN |
| INS-013 | Every device the driver publishes is listed by macOS with the right channel counts | Compare the driver's device list with `system_profiler SPAudioDataType` | Each device appears once, inputs = outputs = configured channels | Mac runner | ⬜ NOT RUN |
| INS-014 | First install shows the first device | On a Mac where the driver was never installed, install it from the panel, then open Audio MIDI Setup. | A device named `VirtualSafeAudio#1` is listed with 2 ins / 2 outs at 48 kHz. No restart was needed. | Manual | ⬜ NOT RUN |
| INS-015 | Other audio devices are unaffected by the install | After install, play music through the built-in speakers or your interface. Check Audio MIDI Setup. | Every device that was there before is still there and still plays. | Manual | ⬜ NOT RUN |
| INS-016 | Installing while audio is playing recovers by itself | Start music in any app on the normal output, then run `./install.sh`. | Audio stops for a few seconds at most and resumes (or resumes on pressing play) without restarting the app. | Manual | ⬜ NOT RUN |
| INS-017 | Installing over an existing install does not duplicate anything | Run `./install.sh` a second time. Look in Audio MIDI Setup. | Same devices as before, each listed once. | Manual | ⬜ NOT RUN |
| INS-018 | With Keep ticked, devices are there after a reboot with the panel not running | Tick `Keep devices when the app is closed`. Restart the Mac. Do not start the panel. Open Audio MIDI Setup. | All VirtualSafeAudio devices are listed as before the restart. | Manual | ⬜ NOT RUN |
| INS-019 | No Core Audio crash reports since the driver was installed | Scan the DiagnosticReports folders for coreaudiod / Core Audio driver host reports newer than the installed bundle | None found | Mac runner | ⬜ NOT RUN |
| INS-020 | Uninstaller completes and the devices disappear | `./uninstall.sh`, then look in Audio MIDI Setup. Then run `python3 stp/stp.py run --after-uninstall`. | Ends with `VirtualSafeAudio driver removed.` No VirtualSafeAudio device is listed any more. | Manual | ⬜ NOT RUN |
| INS-021 | Driver bundle is gone after uninstall | Inspect `/Library/Audio/Plug-Ins/HAL/` | No `VirtualSafeAudio.driver` | Mac runner | ⬜ NOT RUN |
| INS-022 | macOS lists no VirtualSafeAudio device after uninstall | `system_profiler SPAudioDataType` | No device with manufacturer VirtualSafeAudio | Mac runner | ⬜ NOT RUN |
| INS-023 | Core Audio is running after uninstall | `pgrep -x coreaudiod` | A process ID is returned | Mac runner | ⬜ NOT RUN |
| INS-024 | Uninstalling while a virtual device is the system output falls back cleanly | System Settings > Sound > Output: choose a VirtualSafeAudio device. Run `./uninstall.sh`. | macOS switches to another output by itself. No hang, no beachball, sound works. | Manual | ⬜ NOT RUN |
| INS-025 | Uninstalling twice is harmless | Run `./uninstall.sh` again with the driver already removed. | Exits without an error. | Manual | ⬜ NOT RUN |
| INS-026 | Reinstalling brings back the previous device layout | Create two extra devices in the panel, `./uninstall.sh`, then `./install.sh`. | The same devices (names, channel counts) are back. Documented behaviour: Core Audio keeps the driver's settings. | Manual | ⬜ NOT RUN |
| INS-027 | Panel tells you when the driver is not installed | With the driver uninstalled, start the panel and open it. | The Audio section says `Driver not installed` with a red lamp and an `Install audio driver` button. The MIDI section is fully usable. After installing, the page recovers by itself within about 5 seconds. | Manual | ⬜ NOT RUN |
| INS-031 | The launcher can be opened after a fresh download | Unzip a freshly downloaded copy and double-click `START Mac.command`. If macOS refuses, run `xattr -d com.apple.quarantine "START Mac.command"` in the project folder (or System Settings > Privacy & Security > Open Anyway) and double-click again. | A Terminal window opens and shows the VirtualSafeAudio heading. | Manual | ⬜ NOT RUN |
| INS-032 | Starting on a Mac without the audio driver asks for nothing | With the driver uninstalled, double-click `START Mac.command`. | No questions and no password prompt. The panel opens in the browser; the Audio section offers the install button. | Manual | ⬜ NOT RUN |
| INS-033 | Double-click start with the driver already installed goes straight to the panel | Double-click `START Mac.command`. | The panel opens in the browser within a few seconds, Audio section connected. | Manual | ⬜ NOT RUN |
| INS-034 | Double-clicking again while the panel runs opens the existing panel | With the panel running, double-click `START Mac.command` again. | A browser tab opens on the running panel; the second Terminal window closes by itself; the first keeps running. | Manual | ⬜ NOT RUN |
| INS-035 | Closing the launcher window closes the app: audio devices and MIDI ports leave macOS | With Keep unticked (the default), audio devices existing and MIDI switched on, close the launcher's Terminal window (or press control-C in it). | Within a few seconds the virtual audio devices are gone from the macOS sound menu and the virtual MIDI ports from apps. The panel page shows that the server is not answering. | Manual | ⬜ NOT RUN |
| INS-036 | The audio driver can be installed from the panel | With the driver uninstalled and the project folder inside Downloads (where a browser unzips it), open the panel and press `Install audio driver`. Enter the password in the macOS dialog that appears. | All sound drops for a moment. Within about a minute the Audio section shows the lamp lit and one device, `VirtualSafeAudio#1`. No Terminal input was needed. | Manual | ⬜ NOT RUN |
| INS-037 | Cancelling the password dialog changes nothing | With the driver uninstalled, press `Install audio driver`, then press Cancel in the password dialog. | The panel says `The install was cancelled. Nothing was changed.` The button is available again. Nothing was installed; sound was not interrupted. | Manual | ⬜ NOT RUN |
| INS-041 | After an update, the version shown is the one just downloaded | With an older version's panel still running, unzip a newer version and double-click its `START Mac.command`. Answer Return to the question. | The launcher names the other copy's version and folder, replaces it, and the panel header shows the new version number. | Manual | ⬜ NOT RUN |

## Chapter 2 — Devices and configuration

Creating, renaming, resizing and removing virtual devices, and keeping that layout across restarts. 35 tests: 12 pass, 0 fail, 23 not run.

### 2.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| CFG-001 | First start with nothing stored creates one stereo device | Driver logic harness | ✅ PASS |
| CFG-002 | A device is found by its UID; an unknown UID finds nothing | Driver logic harness | ✅ PASS |
| CFG-003 | Property sizes are reported correctly (formats, streams per scope) | Driver logic harness | ✅ PASS |
| CFG-004 | Unknown properties and unknown objects are refused | Driver logic harness | ✅ PASS |
| CFG-005 | Device list is writable, meters are read-only | Driver logic harness | ✅ PASS |
| CFG-006 | Rename keeps the device running: same object, name change announced, saved | Driver logic harness | ✅ PASS |
| CFG-007 | Adding a device leaves existing devices untouched; new one has the requested format | Driver logic harness | ✅ PASS |
| CFG-008 | Channel-count change republishes the device; the old object stops answering | Driver logic harness | ✅ PASS |
| CFG-009 | Sample-rate change is requested through Core Audio and saved | Driver logic harness | ✅ PASS |
| CFG-010 | An unsupported sample rate is rejected | Driver logic harness | ✅ PASS |
| CFG-011 | An empty device list is accepted (no devices published) | Driver logic harness | ✅ PASS |
| CFG-012 | The saved device list comes back after Core Audio restarts | Driver logic harness | ✅ PASS |

### 2.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| CFG-013 | The panel's bridge finds the driver in Core Audio and reads its device list | Read the driver's device-list property through the Python bridge | A parseable list comes back | Mac runner | ⬜ NOT RUN |
| CFG-014 | A new 8-channel device shows up in macOS | Add `STP test device` (8 ch) through the bridge | macOS lists it with 8 ins / 8 outs within 8 s | Mac runner | ⬜ NOT RUN |
| CFG-015 | Renaming a device is reflected in macOS | Rename it to `STP renamed` | macOS lists the new name and no longer the old one | Mac runner | ⬜ NOT RUN |
| CFG-016 | Changing the channel count is reflected in macOS | Change it to 16 channels | macOS lists it with 16 ins / 16 outs | Mac runner | ⬜ NOT RUN |
| CFG-017 | A 64-channel device is published | Change it to 64 channels | macOS lists it with 64 ins / 64 outs | Mac runner | ⬜ NOT RUN |
| CFG-018 | Removing a device removes it from macOS and leaves the others alone | Remove the test device | It is gone; every device from before the test is still listed | Mac runner | ⬜ NOT RUN |
| CFG-019 | Sixteen devices can exist at once | Add test devices until there are 16 | Driver reports 16; macOS lists all of them | Mac runner | ⬜ NOT RUN |
| CFG-020 | The device layout from before the tests is restored | Write the saved list back and read it again | Identical to the list read in CFG-013 | Mac runner | ⬜ NOT RUN |
| CFG-021 | A rename shows up in macOS | With two devices existing and audio running through `#1`, type a new name for `#2` in the panel and press Return. Open the macOS sound menu and Audio MIDI Setup. | Within a few seconds both show the new name for that device. The audio running through `#1` has no gap. (The renamed device itself reconnects for a moment.) | Manual | ⬜ NOT RUN |
| CFG-022 | A Hebrew device name is shown correctly by macOS and by a DAW | Give a device a Hebrew name in the panel (press Return). Look in Audio MIDI Setup and in your DAW's device list. | Name is readable and complete in both. | Manual | ⬜ NOT RUN |
| CFG-023 | Device layout survives a Core Audio restart | Set up 3 devices, one of them renamed. `sudo killall -9 coreaudiod`. | After Core Audio comes back, the same 3 devices are listed. | Manual | ⬜ NOT RUN |
| CFG-024 | With Keep ticked, the device layout survives a reboot | Same 3 devices, `Keep devices when the app is closed` ticked. Restart the Mac; do not start the panel. | Same 3 devices are listed. | Manual | ⬜ NOT RUN |
| CFG-025 | Sample rate chosen in Audio MIDI Setup sticks and is remembered | Set a device to 96 kHz in Audio MIDI Setup. Check the panel. Reboot. | Panel shows 96 kHz for that device; still 96 kHz after the reboot. | Manual | ⬜ NOT RUN |
| CFG-027 | Adding, renaming, resizing and removing devices never restarts Core Audio | Compare the process ID of coreaudiod before CFG-014 and after CFG-019 | Same process ID | Mac runner | ⬜ NOT RUN |
| CFG-028 | A device added in the panel appears in an app that is already open | Open a DAW's audio device menu (or QuickTime Player > New Audio Recording > the input menu). In the panel add a device. Reopen the menu without restarting the app. | The new device is in the list within a few seconds. Remove it in the panel: it leaves the list the same way. | Manual | ⬜ NOT RUN |
| CFG-029 | Adding or removing one device does not disturb audio on another | Loop a 1 kHz sine through device A and record it. While recording, add device B in the panel, then remove it. | The recording from device A has no gap or click at the moments of the changes. | Manual | ⬜ NOT RUN |
| CFG-030 | The number of devices set in the panel is what macOS shows, at once | With the macOS sound menu in view: set `Number of stereo devices` to 4, then to 2, then to 0. There is nothing to press afterwards. | At 4: `VirtualSafeAudio#1` to `#4` are listed. At 2: `#3` and `#4` are gone. At 0: no VirtualSafeAudio device is listed. Each change shows within a second or two; nothing is restarted. | Manual | ⬜ NOT RUN |
| CFG-031 | Closing the app removes the audio devices; starting it brings the same ones back | Keep unticked. Set up 3 devices, one of them renamed. Close the launcher window and look at the macOS sound menu. Start the app again and look once more. | After closing: none of the three is listed. After starting: the same three with the same names, without touching the panel. A DAW that was using one finds it again. | Manual | ⬜ NOT RUN |
| CFG-032 | After a restart of the Mac the audio devices are absent until the app is started | Keep unticked, devices existing. Restart the Mac normally. Look at the sound menu before starting the app, then start it. | None listed before the app starts; all of them back after. | Manual | ⬜ NOT RUN |
| CFG-033 | With Keep ticked, closing the app leaves the audio devices in place | Tick Keep. Run audio through a device into a recording app. Close the launcher window. | The devices stay in the sound menu and the audio is not interrupted. | Manual | ⬜ NOT RUN |
| CFG-034 | Every device is stereo | Create 3 devices. Open Audio MIDI Setup and select each one. | Each shows 2 ins / 2 outs. The panel has no control that changes a device's channel count. | Manual | ⬜ NOT RUN |
| CFG-035 | A removed number is reused and apps recognise the device again | With `#1`, `#2`, `#3` existing, point a DAW track at `VirtualSafeAudio#2`. Remove `#2` in the panel, then press `+`. | The new device is called `VirtualSafeAudio#2` again and the DAW track reconnects to it without being reassigned. | Manual | ⬜ NOT RUN |
| CFG-036 | An app using a device that is renamed finds it again | Record from a virtual device in a DAW. Rename that device in the panel. | The DAW reports the device gone for a moment and then has it back under the new name, or accepts it again after reselecting it. Nothing crashes. | Manual | ⬜ NOT RUN |

## Chapter 3 — Audio loopback

What is played into a device must come back out of it unchanged, on time, on the right channels. 23 tests: 9 pass, 0 fail, 14 not run.

### 3.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| AUD-001 | Recording before anything has played returns silence | Driver logic harness | ✅ PASS |
| AUD-002 | Audio played into a device is recorded back sample-exact | Driver logic harness | ✅ PASS |
| AUD-003 | Recording ahead of playback, or across a half-played span, returns silence | Driver logic harness | ✅ PASS |
| AUD-004 | Continuous stream over five buffer wrap-arounds stays sample-exact | Driver logic harness | ✅ PASS |
| AUD-005 | Audio older than the buffer holds is returned as silence, not stale data | Driver logic harness | ✅ PASS |
| AUD-006 | A short playback dropout reads as silence; audio on both sides survives | Driver logic harness | ✅ PASS |
| AUD-007 | After the timeline restarts, earlier audio does not leak through | Driver logic harness | ✅ PASS |
| AUD-008 | Eight-channel loopback keeps every channel in its own lane | Driver logic harness | ✅ PASS |
| AUD-009 | Device clock advances exactly one period per period of host time | Driver logic harness | ✅ PASS |

### 3.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| AUD-010 | Basic loopback with real apps | Music app output = VirtualSafeAudio. QuickTime Player > New Audio Recording, input = VirtualSafeAudio. Record 20 s, play it back on speakers. | The recording contains the music, clean, both channels. | Manual | ⬜ NOT RUN |
| AUD-011 | Nothing playing records as digital silence | Record 10 s from a virtual device in a DAW with nothing playing into it. | Waveform is a flat line; DAW meter shows no signal at all (not noise). | Manual | ⬜ NOT RUN |
| AUD-012 | Loopback is bit-transparent (null test) | In a DAW: play a file out to the virtual device and record it back on a new track. Align, invert the recording, sum with the original. | Sum is silent (below -120 dBFS). | Manual | ⬜ NOT RUN |
| AUD-013 | Every sample rate works | Repeat AUD-010 at 44.1, 48, 88.2, 96, 176.4 and 192 kHz (set in Audio MIDI Setup or the DAW). | Clean audio, correct pitch and speed at each rate. Note any rate that fails. | Manual | ⬜ NOT RUN |
| AUD-014 | Small and large buffer sizes are free of clicks | In a DAW, loop a 1 kHz sine through the device at buffer sizes 32, 64, 128, 256, 512, 1024, 2048. Record 30 s each. | No clicks or gaps in any recording. | Manual | ⬜ NOT RUN |
| AUD-015 | Two apps playing into one device are mixed | Play from two apps at once into the same virtual device, record from it. | Both are audible in the recording. | Manual | ⬜ NOT RUN |
| AUD-016 | Two apps can record from one device at the same time | Play into a device; record from it in QuickTime and in a DAW simultaneously. | Both recordings contain the audio. | Manual | ⬜ NOT RUN |
| AUD-017 | Left and right stay where they are | In a DAW send a tone to the left output of a device only and record both of its inputs. Repeat with the right. | Left arrives on input 1 only, right on input 2 only. | Manual | ⬜ NOT RUN |
| AUD-018 | Works as the system output | System Settings > Sound > Output = VirtualSafeAudio. Play a video in a browser and a system alert. Record from the device. | Both are in the recording. | Manual | ⬜ NOT RUN |
| AUD-019 | Works inside a Multi-Output Device | Audio MIDI Setup: create a Multi-Output Device with your speakers + VirtualSafeAudio. Play 10 minutes of music through it while recording from VirtualSafeAudio. | You hear it and it records; no glitches or growing delay over the 10 minutes. | Manual | ⬜ NOT RUN |
| AUD-020 | Loopback resumes after sleep | With loopback running, put the Mac to sleep for a minute and wake it. | Audio passes again without reinstalling or restarting Core Audio. | Manual | ⬜ NOT RUN |
| AUD-021 | One-hour soak | Loop a 1 kHz sine through a device and record for 60 minutes. | No dropouts or clicks in the hour (scan the waveform / spectrogram). | Manual | ⬜ NOT RUN |
| AUD-022 | Round-trip latency is measured and recorded | In a DAW, send a click out to the device, record it back, measure the offset in samples at 48 kHz, buffer 256. | Record the number in the result note. Informational for 0.1; expected to be a small constant, the same on every run. | Manual | ⬜ NOT RUN |
| AUD-023 | Two virtual devices do not leak into each other | Two devices. Play into device A only; record from device B. | Device B records silence. | Manual | ⬜ NOT RUN |

## Chapter 4 — Level meters

Peak and VU levels measured inside the driver and shown in the panel. 12 tests: 4 pass, 0 fail, 8 not run.

### 4.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| MTR-001 | Full-scale sine reads a peak of 1.0 (0 dBFS) | Driver logic harness | ✅ PASS |
| MTR-002 | Full-scale sine reads an RMS of 0.707 (-3 dBFS) within 0.01 | Driver logic harness | ✅ PASS |
| MTR-003 | A silent channel falls back while its neighbour is loud | Driver logic harness | ✅ PASS |
| MTR-004 | Meters read zero once playback has stopped | Driver logic harness | ✅ PASS |

### 4.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| MTR-005 | Real audio played into a device moves its meter | Play speech into a test device with `say -a` while reading the driver's meter property | Peak on channel 1 rises above 0.01 (-40 dBFS) | Mac runner | ⬜ NOT RUN |
| MTR-006 | The meter returns to zero after playback ends | Read the meter 1.5 s after `say` has finished | All values are 0 | Mac runner | ⬜ NOT RUN |
| MTR-007 | Panel meters follow the audio, on the right channels | Play a file panned hard left into a device and watch the panel. | The L row moves with the music; the R row stays dark. | Manual | ⬜ NOT RUN |
| MTR-008 | Meter reading is accurate against a reference tone | Play a 1 kHz sine at -18 dBFS RMS into a device. | The lit part of the row ends at the 21st or 22nd of its 30 segments (each segment is 2 dB, the last one is 0 dBFS). | Manual | ⬜ NOT RUN |
| MTR-009 | Clipping is flagged | Play a 0 dBFS square wave or tone briefly. | The last (rightmost) segment of that row lights red and stays for about 1.5 s after the tone stops. | Manual | ⬜ NOT RUN |
| MTR-010 | Watching meters does not count as recording | With only the panel open (no recording app), watch the menu bar and System Settings > Privacy > Microphone. | No orange microphone indicator; no permission prompt; Terminal/Python not listed as having asked for the microphone. | Manual | ⬜ NOT RUN |
| MTR-012 | Meters stay smooth and cheap over time | Leave the panel open for 5 minutes with audio playing. Watch Activity Monitor. | Meters do not stutter or freeze; the Python process and the browser tab stay at a few percent CPU. | Manual | ⬜ NOT RUN |
| MTR-013 | Sixteen devices show sixteen meters, each following its own device | Set the number of devices to 16. Play into three of them from different apps. | Sixteen L/R meters are shown; exactly the three in use move. | Manual | ⬜ NOT RUN |

## Chapter 5 — Virtual MIDI ports

Ports that pass MIDI from one app to another, created and removed live, with nothing to install. 36 tests: 20 pass, 0 fail, 16 not run.

### 5.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| MID-001 | Each port is published as one input and one output with the same name | MIDI helper harness | ✅ PASS |
| MID-002 | MIDI sent into a port comes out of the same port unchanged | MIDI helper harness | ✅ PASS |
| MID-003 | Ports do not leak into each other | MIDI helper harness | ✅ PASS |
| MID-004 | A long message (system exclusive, 200 bytes) passes through intact | MIDI helper harness | ✅ PASS |
| MID-005 | Traffic is counted per port | MIDI helper harness | ✅ PASS |
| MID-006 | Renaming a port keeps the same endpoints; only the name changes | MIDI helper harness | ✅ PASS |
| MID-007 | Adding a port leaves the existing ports untouched | MIDI helper harness | ✅ PASS |
| MID-008 | Removing a port takes away both of its sides and nothing else | MIDI helper harness | ✅ PASS |
| MID-009 | A port keeps the same unique IDs every time it is created, different for its two sides | MIDI helper harness | ✅ PASS |
| MID-010 | Junk lines are ignored, a repeated port is created once, and no more than 16 ports exist | MIDI helper harness | ✅ PASS |
| MID-011 | An empty list removes every port | MIDI helper harness | ✅ PASS |
| MID-012 | Switching MIDI on starts the helper and creates the saved ports | Panel server harness | ✅ PASS |
| MID-013 | A changed port list reaches the running helper without restarting it | Panel server harness | ✅ PASS |
| MID-014 | MIDI passing through a port is reported to the panel as traffic | Panel server harness | ✅ PASS |
| MID-015 | Switching MIDI off stops the helper | Panel server harness | ✅ PASS |
| MID-016 | The MIDI on/off choice and the port list are remembered when the panel restarts | Panel server harness | ✅ PASS |
| MID-017 | Invalid MIDI port lists are rejected (wrong type, duplicate ID, duplicate name, 17 ports) | Panel server harness | ✅ PASS |
| MID-018 | If the helper cannot start, the panel says why, MIDI stays off and audio carries on | Panel server harness | ✅ PASS |
| MID-019 | MIDI works with no audio driver present | Panel server harness | ✅ PASS |
| MID-020 | If the helper dies, the panel reports it instead of pretending the ports exist | Panel server harness | ✅ PASS |

### 5.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| MID-021 | MIDI helper and the MIDI test tool build from source | `./build.sh midi` | Exit 0; `build/vsamidi` and `build/miditest` exist | Mac runner | ⬜ NOT RUN |
| MID-022 | A virtual port shows up in macOS as both a MIDI input and a MIDI output | Start the helper with one port, `STP MIDI A`; list all MIDI endpoints with `build/miditest list` | `STP MIDI A` is listed once as SRC and once as DST | Mac runner | ⬜ NOT RUN |
| MID-023 | 100 notes sent into a port all come back out, in order | `build/miditest loop "STP MIDI A" 100` | `sent=100 received=100 out_of_order=0` | Mac runner | ⬜ NOT RUN |
| MID-024 | Adding a second port live leaves the first port's identity unchanged | Add `STP MIDI B` while the helper runs; compare the unique IDs of `STP MIDI A` before and after | Both ports listed; A has the same two unique IDs | Mac runner | ⬜ NOT RUN |
| MID-025 | A renamed port shows its new name in macOS and keeps its identity | Rename A to `STP MIDI renamed` | New name listed with the same unique IDs; old name gone | Mac runner | ⬜ NOT RUN |
| MID-026 | Stopping the helper removes its ports from macOS | Stop the helper; list endpoints | No endpoint whose name starts with `STP MIDI` | Mac runner | ⬜ NOT RUN |
| MID-027 | First switch-on needs no password and no install | On a Mac where MIDI was never switched on, switch MIDI on in the panel. | Within about 10 seconds (the helper is built once) the lamp lights. No password dialog. Needs only the Xcode command line tools. | Manual | ⬜ NOT RUN |
| MID-028 | Ports appear in MIDI apps on both sides | Switch MIDI on and add a port. Open a DAW's MIDI input list and its MIDI output list. | The port is in both lists under the name given in the panel. | Manual | ⬜ NOT RUN |
| MID-029 | Notes pass from one app to another | App A sends notes to the port (a DAW track, or a keyboard routed through it). App B listens on the port with a synth or a MIDI monitor. | Every note arrives with the right pitch, velocity and channel; note-offs are not lost (no stuck notes). | Manual | ⬜ NOT RUN |
| MID-030 | MIDI clock through a port keeps the receiver in time | App A sends MIDI clock at 120 BPM to the port. App B syncs to it. Run 5 minutes. | B shows 120 BPM (within what B shows when synced to A over the IAC Driver) and does not drift or stutter. | Manual | ⬜ NOT RUN |
| MID-031 | A large system exclusive message passes intact | Send a SysEx dump of at least 1 KB (for example a patch dump) into the port and capture it on the other side with a MIDI monitor or SysEx tool. | Same length, same bytes. | Manual | ⬜ NOT RUN |
| MID-032 | Adding or removing a port does not disturb traffic on another | Keep clock running through port A into a synced app. In the panel add port B, then remove it. | The synced app does not hiccup or lose sync at either moment. | Manual | ⬜ NOT RUN |
| MID-033 | The panel shows real traffic on the right port | Send notes into one of two ports and watch the panel. | That port's lamp flashes and its messages/s figure moves; the other port says `No traffic`. | Manual | ⬜ NOT RUN |
| MID-034 | A DAW finds the port again after the panel is restarted | With a DAW track assigned to a virtual port, quit the panel (the DAW reports the port gone). Start the panel again. | The port returns and the DAW reconnects the track by itself, without reassigning it. | Manual | ⬜ NOT RUN |
| MID-035 | MIDI works on a Mac without the audio driver | With the audio driver uninstalled, switch MIDI on, add a port, run MID-029. | Same result as MID-029. | Manual | ⬜ NOT RUN |
| MID-036 | No noticeable delay through a port | Play a hardware keyboard into a DAW that forwards to a virtual port feeding a synth in a second app; compare the feel with the synth driven directly. | No audible extra latency. If your DAW can measure MIDI round trip, record the figure in the note. | Manual | ⬜ NOT RUN |

## Chapter 6 — Control panel server

The Python server between the browser, the audio driver and the MIDI helper: validation, switching each half on and off, presets, meter and traffic stream. 44 tests: 35 pass, 0 fail, 9 not run.

### 6.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| API-001 | Device list text format round-trips, including a Hebrew name | Panel server harness | ✅ PASS |
| API-002 | Malformed lines in the driver's device list are skipped | Panel server harness | ✅ PASS |
| API-003 | Meter text from the driver is parsed per device | Panel server harness | ✅ PASS |
| API-004 | An edited device keeps its ID and sample rate; control characters are stripped from the name | Panel server harness | ✅ PASS |
| API-005 | A new device is stereo at 48 kHz and takes the lowest free number as its name and its ID | Panel server harness | ✅ PASS |
| API-006 | An invalid device ID from the browser is replaced, not passed to the driver | Panel server harness | ✅ PASS |
| API-007 | A preset's sample rate is used when its device does not exist yet | Panel server harness | ✅ PASS |
| API-008 | A very long non-ASCII name is shortened to fit the driver's name buffer | Panel server harness | ✅ PASS |
| API-009 | An empty device list is accepted | Panel server harness | ✅ PASS |
| API-010 | Invalid device lists are rejected (wrong type, duplicate ID, duplicate name, 17 devices); a channel count from the browser is ignored | Panel server harness | ✅ PASS |
| API-011 | GET /api/state returns devices, mode, limits and presets | Panel server harness | ✅ PASS |
| API-012 | GET / serves the control panel page | Panel server harness | ✅ PASS |
| API-013 | POST /api/config applies a device list and the driver receives exactly that list | Panel server harness | ✅ PASS |
| API-014 | An invalid device list returns 400 with a readable message and leaves the driver untouched | Panel server harness | ✅ PASS |
| API-015 | A POST that is not JSON is refused (blocks cross-site form posts) | Panel server harness | ✅ PASS |
| API-016 | An unknown address returns 404 | Panel server harness | ✅ PASS |
| API-017 | Saving a preset stores the devices with their IDs on disk | Panel server harness | ✅ PASS |
| API-018 | A preset without a name is refused | Panel server harness | ✅ PASS |
| API-019 | Presets are still there after the panel server restarts | Panel server harness | ✅ PASS |
| API-020 | Deleting a preset removes it | Panel server harness | ✅ PASS |
| API-021 | Meter stream delivers events with peak and RMS for every channel, all within 0..1 | Panel server harness | ✅ PASS |
| API-022 | With no driver installed the server reports it plainly and keeps running | Panel server harness | ✅ PASS |
| API-031 | Switching audio off tells the driver to publish nothing and remembers the layout | Panel server harness | ✅ PASS |
| API-032 | Audio devices cannot be edited while audio is off | Panel server harness | ✅ PASS |
| API-033 | The audio on/off choice is remembered when the panel restarts | Panel server harness | ✅ PASS |
| API-034 | Switching audio on again brings back exactly the devices that were there | Panel server harness | ✅ PASS |
| API-035 | A preset holds audio devices and MIDI ports together; a version 0.1 preset still loads | Panel server harness | ✅ PASS |
| API-037 | The guard removes the audio devices when its panel goes away in follow mode, and only then | Panel server harness | ✅ PASS |
| API-038 | By default audio follows the app: devices leave when the panel closes and the same ones return at the next start | Panel server harness | ✅ PASS |
| API-039 | With Keep switched on the devices are left alone, and the choice is remembered | Panel server harness | ✅ PASS |
| API-040 | Audio that was switched off, or a layout emptied on purpose, is not brought back at the next start | Panel server harness | ✅ PASS |
| API-041 | A guard that acts late (an older copy being replaced) cannot wipe the layout: the running panel puts it back | Panel server harness | ✅ PASS |
| API-042 | Devices found in the driver are brought in line: the app's own become stereo and the driver's first-run device becomes #1; others are left alone | Panel server harness | ✅ PASS |
| API-043 | Numbering: new devices take the lowest free number, so a removed number is reused; renamed devices do not block it | Panel server harness | ✅ PASS |
| API-044 | A renamed device is taken out and put back under the same identity, so that macOS shows the new name; others are untouched | Panel server harness | ✅ PASS |

### 6.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| API-023 | Panel server started against the real driver reports it as connected | Start `gui/virtualsafeaudiomidi_gui.py` on a spare port and GET `/api/state` | `connected` is true; devices match the driver's list | Mac runner | ⬜ NOT RUN |
| API-024 | A device list posted to the panel server reaches the real driver | POST a list with one extra device to `/api/config`, read the driver's list through the bridge | The extra device is in the driver's list; then the original list is restored | Mac runner | ⬜ NOT RUN |
| API-025 | Meter stream works against the real driver | Read three events from `/api/meters` | Each event has one entry per device | Mac runner | ⬜ NOT RUN |
| API-026 | Panel reconnects by itself after Core Audio restarts | With the panel open: `sudo killall -9 coreaudiod`. | Lamp may go red briefly, then returns to connected without reloading the page. | Manual | ⬜ NOT RUN |
| API-027 | Port option works and a busy port gives a clear error | `python3 gui/virtualsafeaudiomidi_gui.py --port 9000`, open it. Start a second copy on the same port. | Panel is served on 9000. The second copy exits at once, saying the port is in use, and creates no second set of MIDI ports. | Manual | ⬜ NOT RUN |
| API-028 | Panel is local-only by default | Start the panel with no options. From a phone on the same Wi-Fi, open `http://<mac-ip>:8767`. | Does not load. | Manual | ⬜ NOT RUN |
| API-029 | Panel can be opened from another device when asked to | Start with `--host 0.0.0.0`. From the phone, open `http://<mac-ip>:8767`. | Panel loads, meters move, a device added from the phone appears on the Mac. | Manual | ⬜ NOT RUN |
| API-030 | Presets are stored where the documentation says | Save a preset. Open `~/Library/Application Support/VirtualSafeAudioMIDI/presets.json`. | File exists and contains the preset (audio devices and MIDI ports). | Manual | ⬜ NOT RUN |
| API-036 | What was switched on is still switched on next time | Switch MIDI on and audio off. Quit the panel (close the launcher window). Start it again. | MIDI comes up on with the same ports; audio is still off, with its devices saved. | Manual | ⬜ NOT RUN |

## Chapter 7 — Control panel interface

The page itself: the two switches, editing, applying, presets, meters, MIDI traffic, layout. 29 tests: 24 pass, 0 fail, 5 not run.

### 7.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| UI-001 | Panel loads with no script errors, shows its version and one row per device | Browser harness | ✅ PASS |
| UI-002 | Every device shows a stereo (left/right) meter with lit segments when it has signal | Browser harness | ✅ PASS |
| UI-009 | Loading a saved preset recreates its devices at once | Browser harness | ✅ PASS |
| UI-010 | Removing a device takes it out of the driver at once | Browser harness | ✅ PASS |
| UI-011 | Deleting a preset removes it from the list | Browser harness | ✅ PASS |
| UI-012 | A device can be renamed, in Hebrew, and keeps its identity | Browser harness | ✅ PASS |
| UI-013 | Keyboard focus stays in a field across the background refresh | Browser harness | ✅ PASS |
| UI-014 | No more than 16 devices can exist | Browser harness | ✅ PASS |
| UI-015 | At phone width (390 px) nothing overflows sideways and meters still draw | Browser harness | ✅ PASS |
| UI-016 | With no audio driver installed the panel offers to install it, and MIDI works regardless | Browser harness | ✅ PASS |
| UI-022 | A change made in one browser window shows up in another by itself | Browser harness | ✅ PASS |
| UI-023 | MIDI is off until switched on; the switch takes effect at once | Browser harness | ✅ PASS |
| UI-024 | MIDI ports are created at once, numbered VirtualSafeMIDI#1, #2, ..., and can be renamed | Browser harness | ✅ PASS |
| UI-025 | Each MIDI port shows its traffic | Browser harness | ✅ PASS |
| UI-026 | Removing a MIDI port takes it away at once | Browser harness | ✅ PASS |
| UI-027 | Audio can be switched off and on again without losing its devices or disturbing MIDI | Browser harness | ✅ PASS |
| UI-028 | A preset stores and restores audio devices and MIDI ports together | Browser harness | ✅ PASS |
| UI-029 | MIDI can be switched off; its ports are kept for next time | Browser harness | ✅ PASS |
| UI-030 | Setting the number of devices creates or removes that many at once, down to none | Browser harness | ✅ PASS |
| UI-031 | Setting the number of ports creates or removes that many at once | Browser harness | ✅ PASS |
| UI-032 | The Keep setting can be ticked and unticked, and shows what was chosen | Browser harness | ✅ PASS |
| UI-033 | Devices are named VirtualSafeAudio#1, #2, ...; a removed number is reused, with the same identity | Browser harness | ✅ PASS |
| UI-034 | Adding a device creates it in the driver at once, stereo, with no Apply step | Browser harness | ✅ PASS |
| UI-035 | A duplicate or empty name is refused and the old name stays | Browser harness | ✅ PASS |

### 7.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| UI-017 | Panel works in Safari | In Safari: change the number of devices, add and remove one, rename one, do the same for MIDI ports, save / load / delete a preset, watch meters. | Everything works; layout is intact. | Manual | ⬜ NOT RUN |
| UI-018 | Panel works in Chrome | Same steps in Chrome. | Everything works; layout is intact. | Manual | ⬜ NOT RUN |
| UI-019 | Panel works in Firefox | Same steps in Firefox. | Everything works; layout is intact. | Manual | ⬜ NOT RUN |
| UI-020 | Panel is usable on a phone | With `--host 0.0.0.0`, open the panel on a phone. Add a device and rename it. | Controls are reachable and readable; nothing is cut off; the bottom bar does not cover the last row. | Manual | ⬜ NOT RUN |
| UI-021 | Panel can be driven from the keyboard alone | Using only Tab, Shift+Tab, Space, Enter and typing: change the number of devices, rename one, switch MIDI on. | Every control can be reached; focus is always visible. | Manual | ⬜ NOT RUN |

## Chapter 8 — Robustness

Bad input, memory safety, rapid changes, and behaviour when things are pulled out from under it. 14 tests: 6 pass, 0 fail, 8 not run.

### 8.1 Automated

| ID | Test | Run by | Result |
|---|---|---|---|
| ROB-001 | Malformed device list is cleaned up: channels clamped, bad rate defaulted, duplicates and junk dropped | Driver logic harness | ✅ PASS |
| ROB-002 | A list of more than 16 devices is capped at 16 | Driver logic harness | ✅ PASS |
| ROB-003 | Driver harness is clean under AddressSanitizer and UndefinedBehaviorSanitizer | C harness, sanitizers | ✅ PASS |
| ROB-011 | MIDI helper harness is clean under AddressSanitizer and UndefinedBehaviorSanitizer | C harness, sanitizers | ✅ PASS |
| ROB-012 | If the panel is killed outright, the MIDI helper exits by itself and leaves no orphan | Panel server harness | ✅ PASS |
| ROB-013 | If the panel is killed outright, its audio guard still gets its turn | Panel server harness | ✅ PASS |

### 8.2 On the Mac

| ID | Test | Procedure | Expected | Run by | Result |
|---|---|---|---|---|---|
| ROB-004 | Thirty device-list changes in a row leave the driver answering and Core Audio alive | Add and remove a test device 15 times with no pauses, through the bridge | Driver still answers; list equals the original; coreaudiod has the same process ID | Mac runner | ⬜ NOT RUN |
| ROB-005 | No Core Audio crash reports were produced during this test run | Scan the DiagnosticReports folders for reports newer than the start of the run | None found | Mac runner | ⬜ NOT RUN |
| ROB-006 | Removing a device while a DAW is recording from it crashes nothing | Record from a virtual device in a DAW. Remove that device in the panel. | DAW reports the device is gone; neither the DAW nor Core Audio crashes; other audio keeps working. | Manual | ⬜ NOT RUN |
| ROB-007 | Idle cost is negligible | Driver installed, nothing using it, panel closed. Watch `coreaudiod` and the Core Audio driver service in Activity Monitor for a minute. | Both at about 0 % CPU. | Manual | ⬜ NOT RUN |
| ROB-009 | Memory does not grow with repeated reconfiguration | Note the driver service's memory in Activity Monitor. Add and remove a device 50 times in the panel. Note it again. | Memory is back to roughly the starting figure (within a few MB). | Manual | ⬜ NOT RUN |
| ROB-010 | Closing the browser tab affects nothing; with Keep ticked, neither does stopping the app | With loopback running, close the browser tab. Then, with Keep ticked, stop the Python server with Ctrl+C. | Audio through the virtual devices is uninterrupted both times. | Manual | ⬜ NOT RUN |
| ROB-014 | If the app is force-quit, the audio devices and MIDI ports are still removed | Keep unticked, devices and ports existing. In another Terminal window: `pkill -9 -f "virtualsafeaudiomidi_gui.py --port"`. | Within a few seconds the audio devices leave the sound menu and the MIDI ports leave apps. Starting the app again brings both back. | Manual | ⬜ NOT RUN |
| ROB-015 | Cost of sixteen devices carrying audio at once is reasonable | Create 16 devices and run audio through as many as you can at 48 kHz, buffer 256, for a minute. | No dropouts; driver service CPU stays in single digits on the Mac mini. Record the figure. | Manual | ⬜ NOT RUN |

## Chapter 9 — Results

### 9.1 By chapter

| Chapter | Total | ✅ Pass | ❌ Fail | ⬜ Not run |
|---|---|---|---|---|
| 1. Install and uninstall | 41 | 10 | 0 | 31 |
| 2. Devices and configuration | 35 | 12 | 0 | 23 |
| 3. Audio loopback | 23 | 9 | 0 | 14 |
| 4. Level meters | 12 | 4 | 0 | 8 |
| 5. Virtual MIDI ports | 36 | 20 | 0 | 16 |
| 6. Control panel server | 44 | 35 | 0 | 9 |
| 7. Control panel interface | 29 | 24 | 0 | 5 |
| 8. Robustness | 14 | 6 | 0 | 8 |
| **Total** | **234** | **120** | **0** | **114** |

### 9.2 By who runs it

| Kind | Total | ✅ Pass | ❌ Fail | ⬜ Not run |
|---|---|---|---|---|
| Automated | 120 | 120 | 0 | 0 |
| Mac runner | 34 | 0 | 0 | 34 |
| Manual | 80 | 0 | 0 | 80 |

**Executed:** 120 of 234 (51.3%).  
**Pass rate of executed tests:** 100.0% (120 of 120).  
**Waiting for the Mac:** 34 runner tests and 80 manual tests.

### 9.3 Failures

None recorded.

### 9.4 Run log

| Date | Environment | Kind | Executed | ✅ Pass | ❌ Fail |
|---|---|---|---|---|---|
| 2026-10-01 | Linux container (Claude sandbox) | Automated | 120 | 120 | 0 |

### 9.5 Not run, and why

Every ⬜ in this document needs a real Mac: the driver has to be compiled against Apple's SDK, signed, loaded by `coreaudiod`, and used by real applications; the MIDI helper has to open real CoreMIDI ports that real apps connect to. The environment the automated tests were written and run in is a Linux container with no network access, no macOS, and no audio hardware, so none of that can happen there. The Mac runner exists so that as much as possible of that gap is one command on your side rather than a checklist.

Tests that were attempted and skipped, with the reason:

| ID | Reason | Where | Date |
|---|---|---|---|
| INS-036 | Failed in 0.2: the administrator step could not read install.sh inside Downloads (Operation not permitted). Fixed in 0.2.1, covered by INS-038. Needs retest. | Zvi's Mac, project in ~/Downloads, version 0.2 | 2026-10-01 |
| CFG-021 | Failed in 0.4.0: a device renamed in the panel kept its old name in the macOS device list. Fixed in 0.4.1 (the renamed device is re-published), covered by API-044. Needs retest. | Zvi's Mac, version 0.4.0 | 2026-10-01 |
