#!/bin/bash
set -euo pipefail
sudo rm -rf "/Library/Audio/Plug-Ins/HAL/VirtualSafeAudio.driver"
sudo killall -9 coreaudiod || true
echo "VirtualSafeAudio driver removed."
